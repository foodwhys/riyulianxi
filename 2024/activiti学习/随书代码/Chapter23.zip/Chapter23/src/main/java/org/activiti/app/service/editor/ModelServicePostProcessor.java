package org.activiti.app.service.editor;

import com.bpm.example.demo2.converter.CustomBpmnJsonConverter;
import org.activiti.app.service.api.ModelService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class ModelServicePostProcessor implements BeanPostProcessor {

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

    //实例化、依赖注入完毕，在调用显示的初始化之前完成一些定制的初始化任务
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof ModelService) {
            ((ModelServiceImpl)bean).bpmnJsonConverter = new CustomBpmnJsonConverter();
        }
        return bean;
    }
}

