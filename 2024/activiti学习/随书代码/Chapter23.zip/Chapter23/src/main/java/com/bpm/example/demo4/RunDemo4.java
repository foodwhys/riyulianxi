package com.bpm.example.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo4.event.CustomActivitiEventType;
import com.bpm.example.demo4.event.impl.ActivitiTaskUrgingEventImpl;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.delegate.event.impl.ActivitiEventSupport;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunDemo4 extends ActivitiEngineUtil {

    @Test
    public void runCustomEventDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/CustomEventProcess.bpmn20.xml");

        //启动流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个用户任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //办理完成第一个用户任务
        taskService.complete(firstTask.getId());
        //查询第二个用户任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();

        //查询BpmnModel
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processDefinition.getId());
        //获取ActivitiEventSupport
        ActivitiEventSupport activitiEventSupport = ((ActivitiEventSupport)bpmnModel.getEventSupport());
        //触发自定义事件
        activitiEventSupport.dispatchEvent(new ActivitiTaskUrgingEventImpl((TaskEntity) secondTask,
                ActivitiEventType.CUSTOM,
                CustomActivitiEventType.TASK_URGING));
        //关闭流程引擎
        engine.close();
    }
}
