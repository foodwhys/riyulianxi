package com.bpm.example.demo4.listener;

import com.bpm.example.demo4.event.ActivitiTaskUrgingEvent;
import com.bpm.example.demo4.event.CustomActivitiEventType;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
@Slf4j
public class TaskUrgingEventListener implements ActivitiEventListener {

    public void onEvent(ActivitiEvent event) {
        ActivitiEventType eventType = event.getType();
        if (eventType.equals(ActivitiEventType.CUSTOM)) {
            if (event instanceof ActivitiTaskUrgingEvent) {
                ActivitiTaskUrgingEvent activitiTaskUrgingEvent = (ActivitiTaskUrgingEvent) event;
                Object entityObject = activitiTaskUrgingEvent.getEntity();
                if (activitiTaskUrgingEvent.getCustomActivitiEventType().equals(CustomActivitiEventType.TASK_URGING)) {
                    TaskEntity task = (TaskEntity)entityObject;
                    taskUrging(task);
                }
            }
        }
    }

    private void taskUrging(TaskEntity task) {
        log.info("{}被催办了！", task.getName());
    }

    public boolean isFailOnException() {
        return false;
    }

}