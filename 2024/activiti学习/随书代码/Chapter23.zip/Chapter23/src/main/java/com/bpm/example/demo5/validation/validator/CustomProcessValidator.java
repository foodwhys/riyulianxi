package com.bpm.example.demo5.validation.validator;

import org.activiti.validation.ProcessValidatorImpl;
import org.activiti.validation.validator.ValidatorSet;
import org.activiti.validation.validator.ValidatorSetFactory;

public class CustomProcessValidator extends ProcessValidatorImpl {

    public CustomProcessValidator() {
        //加入Activiti默认校验规则
        this.addValidatorSet((new ValidatorSetFactory()).createActivitiExecutableProcessValidatorSet());
        //加入自定义校验规则
        ValidatorSet customValidatorSet = new ValidatorSet("custom-validtor");
        customValidatorSet.addValidator(new CustomValidator());
        this.addValidatorSet(customValidatorSet);
    }
}