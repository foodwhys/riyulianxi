package com.bpm.example.demo3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.List;

@Slf4j
public class RunDemo3 extends ActivitiEngineUtil {

    SimplePropertyPreFilter identityLinkFilter = new SimplePropertyPreFilter(IdentityLink.class,"taskId","type","userId");

    @Test
    public void runCustomActivityBehaviorDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.custom-activitybehavior.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/CustomActivityBehaviorProcess.bpmn20.xml");

        //设置当前操作用户
        identityService.setAuthenticatedUserId("liuxiaopeng");
        //启动流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个用户任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第一个用户任务taskId：{}，name：{}，assignee：{}", firstTask.getId(), firstTask.getName(), firstTask.getAssignee());
        //办理完成第一个用户任务
        taskService.complete(firstTask.getId());
        //设置当前操作用户
        identityService.setAuthenticatedUserId("hebo");
        //查询第二个用户任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第二个用户任务taskId：{}，name：{}，assignee：{}", secondTask.getId(), secondTask.getName(), secondTask.getAssignee());

        List<IdentityLink> identityLinks = taskService.getIdentityLinksForTask(secondTask.getId());
        log.info("候选（候选）人：{}", JSON.toJSONString(identityLinks, identityLinkFilter));
        //办理完成第二个用户任务
        taskService.complete(secondTask.getId());

        //关闭流程引擎
        engine.close();
    }
}
