package com.bpm.example.demo4.event.impl;

import com.bpm.example.demo4.event.ActivitiTaskUrgingEvent;
import com.bpm.example.demo4.event.CustomActivitiEventType;
import lombok.Data;
import lombok.Getter;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.delegate.event.impl.ActivitiEventImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntity;

public class ActivitiTaskUrgingEventImpl extends ActivitiEventImpl implements ActivitiTaskUrgingEvent {

    @Getter
    protected Object entity;
    @Getter
    protected CustomActivitiEventType customActivitiEventType;

    public ActivitiTaskUrgingEventImpl(TaskEntity entity, ActivitiEventType type,
                                       CustomActivitiEventType customActivitiEventType) {
        super(type);
        this.entity = entity;
        this.customActivitiEventType = customActivitiEventType;
    }
}