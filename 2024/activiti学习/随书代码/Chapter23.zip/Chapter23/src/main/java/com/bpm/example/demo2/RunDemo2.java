package com.bpm.example.demo2;

import com.bpm.example.demo2.converter.CustomBpmnJsonConverter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.ExtensionElement;
import org.activiti.bpmn.model.UserTask;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunDemo2 {

    @Test
    public void runCustomJsonConverterDemo() throws Exception {

        //读取Activiti-Modeler保存的Json
        InputStream processModelJsonInputStream = RunDemo2.class.getClassLoader().getResourceAsStream("model-json/model.json");
        ObjectMapper mapper = new ObjectMapper();
        JsonNode processJsonNode = mapper.readTree(processModelJsonInputStream);
        //获取流程模型的Json
        JsonNode modelJsonNode = processJsonNode.get("model");
        //使用自定义转换类由Json转换为BpmnModel对象
        BpmnJsonConverter bpmnJsonConverter = new CustomBpmnJsonConverter();
        BpmnModel bpmnModel = bpmnJsonConverter.convertToBpmnModel(modelJsonNode);
        //查询用户任务对象并打印属性
        UserTask userTask = (UserTask)bpmnModel.getFlowElement("userTask1");
        Map<String, List<ExtensionElement>> extensionElements = userTask.getExtensionElements();
        List<ExtensionElement> allowurgingExtension = extensionElements.get("allowurging");
        if (CollectionUtils.isNotEmpty(allowurgingExtension)) {
            log.info("扩展属性allowurging值为：{}", allowurgingExtension.get(0).getElementText());
        }
    }
}
