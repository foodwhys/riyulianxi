package com.bpm.example.demo1.cfg;

import lombok.Data;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.interceptor.CommandInterceptor;
import org.activiti.spring.SpringTransactionInterceptor;
import org.springframework.transaction.PlatformTransactionManager;

@Data
public class CustomProcessEngineConfiguration extends ProcessEngineConfigurationImpl {

    //自定义扩展属性1：事务管理器
    protected PlatformTransactionManager customTransactionManager;

    //自定义扩展属性2：引擎类型
    protected String engineType;

    @Override
    public CommandInterceptor createTransactionInterceptor() {
        if (customTransactionManager == null) {
            throw new ActivitiException("customTransactionManager is required property for CustomProcessEngineConfiguration.");
        }
        return new SpringTransactionInterceptor(customTransactionManager);
    }

}

