package com.bpm.example.demo4.event;

public enum CustomActivitiEventType {
    //催办
    TASK_URGING;
}
