package com.bpm.example.demo4.event;

import org.activiti.engine.delegate.event.ActivitiEvent;

public abstract interface ActivitiTaskUrgingEvent extends ActivitiEvent {

    public Object getEntity();

    public CustomActivitiEventType getCustomActivitiEventType();

}

