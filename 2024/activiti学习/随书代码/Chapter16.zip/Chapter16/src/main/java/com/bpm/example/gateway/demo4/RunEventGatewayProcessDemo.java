package com.bpm.example.gateway.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class RunEventGatewayProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runEventGatewayProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.job.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/EventGatewayProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询并办理第一个任务
        Task task1 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        taskService.complete(task1.getId());
        //查询执行实例
        List<Execution> executionList = runtimeService.createExecutionQuery().processInstanceId(processInstance.getId()).onlyChildExecutions().list();
        log.info("第一个任务办理后，当前流程所处节点为：{}", executionList.stream().map(Execution::getActivityId).collect(Collectors.joining(",")));
        //等待5分钟
        Thread.sleep(1000 * 60 * 5);
        //触发信号
        runtimeService.signalEventReceived("alert");
        Task task2 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("触发信号后，当前流程所处用户任务名称：{}", task2.getName());
        //办理任务
        taskService.complete(task2.getId());

        //关闭流程引擎
        closeEngine();
    }
}