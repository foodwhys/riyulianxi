package com.bpm.example.gateway.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class RunParallelGatewayProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runParallelGatewayProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/InclusiveGatewayProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        TaskQuery taskQuery = taskService.createTaskQuery();
        //查询请假申请任务
        Task applyTask = taskQuery.processInstanceId(processInstance.getId()).singleResult();
        log.info("流程发起后，第一个用户任务名称为：{}", applyTask.getName());
        //设置leaveDays变量值
        Map variables = new HashMap<>();
        variables.put("leaveDays", 5);
        //完成请假申请任务
        taskService.complete(applyTask.getId(), variables);
        List<Task> taskList1 = taskQuery.list();
        //查询任务个数
        log.info("第一个任务办理后，当前流程的任务个数为{}，分别为：{}", taskList1.size(), taskList1.stream().map(Task::getName).collect(Collectors.joining(",")));
        //办理任务
        taskList1.stream().forEach(task -> {
            taskService.complete(task.getId());
            log.info("办理完成用户任务：{}", task.getName());
        });
        List<Task> taskList2 = taskQuery.list();
        //查询任务个数
        log.info("办理完前{}个任务后，流程当前任务个数为{}，分别为：{}", taskList1.size(), taskList2.size(), taskList2.stream().map(Task::getName).collect(Collectors.joining("，")));
        //办理任务
        taskList2.stream().forEach(task -> {
            taskService.complete(task.getId());
            log.info("办理完成用户任务：{}", task.getName());
        });
        //查询剩余任务个数
        log.info("最后剩余的用户任务数为{}", taskQuery.list().size());

        //关闭流程引擎
        closeEngine();
    }
}