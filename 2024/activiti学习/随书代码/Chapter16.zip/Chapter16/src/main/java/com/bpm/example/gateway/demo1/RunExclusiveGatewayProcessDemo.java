package com.bpm.example.gateway.demo1;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunExclusiveGatewayProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runExclusiveGatewayProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ExclusiveGatewayProcess.bpmn20.xml");

        //设置variable1变量值
        Map<String, Object> variables1= new HashMap<String, Object>();
        variables1.put("variable1", 1);
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables1);
        //查询任务
        Task task1 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("流程发起后，第一个用户任务的名称：{}", task1.getName());
        Map<String, Object> variables2= new HashMap<String, Object>();
        //设置variable2变量值
        variables2.put("variable2", 2);
        //完成任务
        taskService.complete(task1.getId(), variables2);
        //查询任务
        Task task2 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第一个任务提交后，流程当前所在的用户任务的名称：{}", task2.getName());
        //完成任务
        taskService.complete(task2.getId());

        //关闭流程引擎
        closeEngine();
    }
}