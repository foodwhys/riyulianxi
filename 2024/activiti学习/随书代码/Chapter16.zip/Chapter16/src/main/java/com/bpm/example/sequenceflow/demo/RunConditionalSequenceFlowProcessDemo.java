package com.bpm.example.sequenceflow.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunConditionalSequenceFlowProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runConditionalSequenceFlowProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ConditionalSequenceFlowProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询采购申请任务
        Task userApplyTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //设置totalPrice变量值
        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("totalPrice", 15000);
        //完成采购申请任务
        taskService.complete(userApplyTask.getId(), variables);
        //查询审批任务
        Task approveTask = taskService.createTaskQuery().singleResult();
        log.info("审批任务taskId：{}，节点名称：{}", approveTask.getId(), approveTask.getName());
        //完成审批任务
        taskService.complete(approveTask.getId());

        //关闭流程引擎
        closeEngine();
    }
}