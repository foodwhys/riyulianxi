package com.bpm.example.tasklistener.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.tasklistener.demo.bean.MyTaskListenerBean;
import com.bpm.example.tasklistener.demo.listener.MyTaskListener2;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunTaskListenerProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runTaskListenerProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/TaskListenerProcess.bpmn20.xml");

        //初始化流程变量
        MyTaskListenerBean myTaskListenerBean = new MyTaskListenerBean();
        MyTaskListener2 myTaskListener2= new MyTaskListener2();
        Map variables1 = new HashMap();
        variables1.put("myTaskListenerBean", myTaskListenerBean);
        variables1.put("myTaskListener2", myTaskListener2);
        //启动流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables1);
        //查询任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //设置任务办理人
        task.setAssignee("liuxiaopeng");
        //办理任务
        taskService.complete(task.getId());

        //关闭流程引擎
        closeEngine();
    }
}
