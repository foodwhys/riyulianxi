package com.bpm.example.eventlistener.demo.listener;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.event.ActivitiActivityEvent;
import org.activiti.engine.delegate.event.ActivitiEntityEvent;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.runtime.ProcessInstance;

@Slf4j
public class GlobalEventListener implements ActivitiEventListener {

    public void onEvent(ActivitiEvent event) {
        ActivitiEventType eventType = event.getType();
        switch (eventType) {
            case ENGINE_CREATED:
                //流程引擎创建
                exectueEngineEvent(event, eventType);
                break;
            case ENGINE_CLOSED:
                //流程引擎销毁
                exectueEngineEvent(event, eventType);
                break;
            case PROCESS_STARTED:
                //流程实例发起
                exectueProcessEvent(event, eventType);
                break;
            case PROCESS_COMPLETED:
                //流程实例结束
                exectueProcessEvent(event, eventType);
                break;
            case ACTIVITY_STARTED:
                //一个节点创建
                exectueActitityEvent(event, eventType);
                break;
            case ACTIVITY_COMPLETED:
                //一个节点结束
                exectueActitityEvent(event, eventType);
                break;
            case TASK_CREATED:
                //一个用户任务创建
                exectueTaskEvent(event, eventType);
                break;
            case TASK_ASSIGNED:
                //一个用户任务分配办理人
                exectueTaskEvent(event, eventType);
                break;
            case TASK_COMPLETED:
                //一个用户任务办理完成
                exectueTaskEvent(event, eventType);
                break;
            default:
                break;
        }
    }

    public boolean isFailOnException() {
        return false;
    }

    private void exectueActitityEvent(ActivitiEvent event, ActivitiEventType eventType) {
        ActivitiActivityEvent activitiActivityEvent = (ActivitiActivityEvent) event;
        log.info("Id为{}的流程活动的{}事件触发", activitiActivityEvent.getActivityId(), eventType.name());
    }

    private void exectueEngineEvent(ActivitiEvent event, ActivitiEventType eventType) {
        log.info("流程引擎的{}事件触发", eventType.name());
    }

    private void exectueProcessEvent(ActivitiEvent event, ActivitiEventType eventType) {
        ActivitiEntityEvent activitiEntityEvent = (ActivitiEntityEvent) event;
        Object entityObject = activitiEntityEvent.getEntity();
        ProcessInstance processInstance = (ProcessInstance) entityObject;
        log.info("processInstanceId为{}的流程实例的{}事件触发", processInstance.getProcessInstanceId(), eventType.name());
    }

    private void exectueTaskEvent(ActivitiEvent event, ActivitiEventType eventType) {
        ActivitiEntityEvent activitiEntityEvent = (ActivitiEntityEvent) event;
        Object entityObject = activitiEntityEvent.getEntity();
        TaskEntity taskEntity = (TaskEntity) entityObject;
        log.info("Id为{}的用户任务的{}事件触发", taskEntity.getTaskDefinitionKey(), eventType.name());
    }
}