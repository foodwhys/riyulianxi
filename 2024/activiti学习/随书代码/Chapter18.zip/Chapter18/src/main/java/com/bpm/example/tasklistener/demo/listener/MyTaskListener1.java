package com.bpm.example.tasklistener.demo.listener;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

@Slf4j
public class MyTaskListener1 implements TaskListener {

    public void notify(DelegateTask delegateTask) {
        //获取任务节点定义key
        String taskDefinitionKey = delegateTask.getTaskDefinitionKey();
        //获取事件名称
        String eventName = delegateTask.getEventName();
        log.info("通过class指定的监听器：Id为{}用户任务的{}事件触发", taskDefinitionKey, eventName);
    }
}
