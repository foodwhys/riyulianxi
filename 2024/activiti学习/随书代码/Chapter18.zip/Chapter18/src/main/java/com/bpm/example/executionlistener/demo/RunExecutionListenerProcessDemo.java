package com.bpm.example.executionlistener.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.executionlistener.demo.bean.MyProcessExecutionListenerBean;
import com.bpm.example.executionlistener.demo.listener.MySequenceFlowExecutionListener;
import com.bpm.example.executionlistener.demo.listener.MyUserTaskExecutionListener;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunExecutionListenerProcessDemo extends ActivitiEngineUtil {

    static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");

    @Test
    public void runExecutionListenerProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ExecutionListenerProcess.bpmn20.xml");

        //将监听器bean放入到流程变量中
        MyProcessExecutionListenerBean myProcessExecutionListenerBean = new MyProcessExecutionListenerBean();
        MySequenceFlowExecutionListener mySequenceFlowExecutionListenerBean = new MySequenceFlowExecutionListener();
        MyUserTaskExecutionListener myUserTaskExecutionListenerBean = new MyUserTaskExecutionListener();
        Map variables1 = new HashMap();
        variables1.put("nowTime1", simpleDateFormat.format(new Date()));
        variables1.put("myProcessExecutionListenerBean", myProcessExecutionListenerBean);
        variables1.put("mySequenceFlowExecutionListenerBean", mySequenceFlowExecutionListenerBean);
        variables1.put("myUserTaskExecutionListenerBean", myUserTaskExecutionListenerBean);
        //启动流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(),variables1);
        //查询任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        Map variables2 = new HashMap();
        variables2.put("nowTime2", simpleDateFormat.format(new Date()));
        //办理任务
        taskService.complete(task.getId(), variables2);
        //查询并打印流程变量
        List<HistoricVariableInstance> historicVariableInstances = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).list();
        historicVariableInstances.stream().forEach((historicVariableInstance) -> log.info("流程变量名：{}，变量值：{}", historicVariableInstance.getVariableName(), historicVariableInstance.getValue()));

        //关闭流程引擎
        closeEngine();
    }
}
