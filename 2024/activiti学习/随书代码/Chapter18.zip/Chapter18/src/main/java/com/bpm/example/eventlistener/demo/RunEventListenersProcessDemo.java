package com.bpm.example.eventlistener.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunEventListenersProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runEventListenersProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.eventlistener.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/EventListenersProcess.bpmn20.xml");

        //启动流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //办理任务
        taskService.complete(task.getId());

        //关闭流程引擎
        closeEngine();
    }
}