package com.bpm.example.intermediateevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunTimerIntermediateCatchingEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runTimerIntermediateCatchingEventProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.job.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/TimerIntermediateCatchingEventProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第一个任务为：{}", firstTask.getName());
        //完成第一个任务
        taskService.complete(firstTask.getId());

        //暂停6分钟
        log.info("暂停6分钟");
        Thread.sleep(1000 * 60 * 6);

        //查询第二个任务节点
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第二个任务为：{}", secondTask.getName());

        //关闭流程引擎
        closeEngine();
    }
}