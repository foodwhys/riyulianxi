package com.bpm.example.intermediateevent.demo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunCompensateIntermediateThrowingEventProcessDemo extends ActivitiEngineUtil {

    static SimplePropertyPreFilter executionFilter = new SimplePropertyPreFilter(Execution.class,
            "id","parentId","businessKey","processInstanceId","rootProcessInstanceId",
            "superExecutionId","scope","activityId");

    @Test
    public void runCompensateIntermediateThrowingEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/CompensateIntermediateThrowingEventProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询执行实例
        List<Execution> executionList1 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getId()).list();
        log.info("主流程发起后，执行实例数为：{}，分别为：{}", executionList1.size(), JSON.toJSONString(executionList1, executionFilter));

        //查询“预报名”任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).taskName("预报名").singleResult();
        //设置流程变量
        Map variables1 = new HashMap<>();
        variables1.put("applicant", "zhangsan");
        //完成“预报名”任务
        taskService.complete(firstTask.getId(), variables1);
        log.info("办理完成名称为：{}的用户任务", firstTask.getName());

        //查询执行实例
        List<Execution> executionList2 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getId()).list();
        log.info("子流程发起后，执行实例数为：{}，分别为：{}", executionList2.size(), JSON.toJSONString(executionList2, executionFilter));

        //查询“正式报名”任务
        Task secondTask = taskService.createTaskQuery().taskName("正式报名").processInstanceId(processInstance.getId()).singleResult();
        //完成“正式报名”任务
        taskService.complete(secondTask.getId());
        log.info("办理完成名称为：{}的用户任务", secondTask.getName());

        //查询“报名审核”任务
        Task thirdTask = taskService.createTaskQuery().taskName("报名审核").processInstanceId(processInstance.getId()).singleResult();
        //完成“报名审核”任务
        taskService.complete(thirdTask.getId());
        log.info("办理完成名称为：{}的用户任务", thirdTask.getName());

        //查询执行实例
        List<Execution> executionList3 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getId()).list();
        log.info("子流程结束后，执行实例数为：{}，分别为：{}", executionList3.size(), JSON.toJSONString(executionList3, executionFilter));

        //查询“银行卡支付”任务
        Task fourthTask = taskService.createTaskQuery().taskName("银行卡支付").processInstanceId(processInstance.getId()).singleResult();
        log.info("即将办理名称为：{}的用户任务", fourthTask.getName());

        //设置流程变量
        Map variables3 = new HashMap<>();
        variables3.put("applicationFee", 1000);
        //完成第二个任务（流程结束）
        taskService.complete(fourthTask.getId(), variables3);

        //查询执行实例
        List<Execution> executionList4 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getId()).list();
        log.info("流程结束后，执行实例数为：{}，执行实例信息为：{}", executionList4.size(), JSON.toJSONString(executionList4, executionFilter));

        //关闭流程引擎
        closeEngine();
    }
}