package com.bpm.example.boundaryevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.List;

@Slf4j
public class RunSignalBoundaryInterrputingEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runSignalBoundaryInterrputingEventProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SignalBoundaryInterrputingEventProcess.bpmn20.xml");

        //启动两个流程实例
        ProcessInstance processInstance1 = runtimeService.startProcessInstanceById(processDefinition.getId());
        log.info("第1个流程实例的编号为：{}", processInstance1.getId());
        ProcessInstance processInstance2 = runtimeService.startProcessInstanceById(processDefinition.getId());
        log.info("第2个流程实例的编号为：{}", processInstance2.getId());

        //将实例一进行到确认合同
        Task processInstance1Task = taskService.createTaskQuery().processInstanceId(processInstance1.getId()).singleResult();
        taskService.complete(processInstance1Task.getId());
        processInstance1Task = taskService.createTaskQuery().processInstanceId(processInstance1.getId()).singleResult();
        log.info("第1个流程实例当前所在用户任务为：{}", processInstance1Task.getName());

        //将实例二进行到确认合同
        Task processInstance2Task = taskService.createTaskQuery().processInstanceId(processInstance2.getId()).singleResult();
        taskService.complete(processInstance2Task.getId());
        processInstance2Task = taskService.createTaskQuery().processInstanceId(processInstance2.getId()).singleResult();
        log.info("第2个流程实例当前所在用户任务为：{}", processInstance2Task.getName());

        //发送合同变更信号
        runtimeService.signalEventReceived("修改合同");
        log.info("发送合同变更信号完成");

        //根据流程定义查询任务
        List<Task> tasks = taskService.createTaskQuery().processDefinitionId(processDefinition.getId()).list();
        for(Task task : tasks) {
            log.info("编号为{}的流程实例当前所在用户任务为：{}", task.getProcessInstanceId(), task.getName());
        }

        //关闭流程引擎
        closeEngine();
    }
}