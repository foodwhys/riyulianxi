package com.bpm.example.boundaryevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunErrorBoundaryInterrputingEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runErrorBoundaryInterrputingEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ErrorBoundaryInterrputingEventProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询提交材料任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第一个用户任务为：{}", firstTask.getName());
        Map variables  = new HashMap<>();
        variables.put("healthCodeStatus", "red");
        //完成第一个任务
        taskService.complete(firstTask.getId(), variables);

        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第二个用户任务为: {}", secondTask.getName());
        //完成第二个任务
        taskService.complete(secondTask.getId());

        //关闭流程引擎
        closeEngine();
    }
}