package com.bpm.example.intermediateevent.demo.delegate;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

@Slf4j
public class CancelPredictionService implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        log.info("执行补偿，取消预报名完成！");
    }
}
