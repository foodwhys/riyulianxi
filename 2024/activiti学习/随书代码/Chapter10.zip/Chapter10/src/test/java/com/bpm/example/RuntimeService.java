package com.bpm.example;


import org.activiti.bpmn.model.FlowNode;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.impl.persistence.entity.VariableInstance;
import org.activiti.engine.runtime.DataObject;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ExecutionQuery;
import org.activiti.engine.runtime.NativeExecutionQuery;
import org.activiti.engine.runtime.NativeProcessInstanceQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceBuilder;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.activiti.engine.task.Event;
import org.activiti.engine.task.IdentityLink;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface RuntimeService {

    //流程实例builder
    ProcessInstanceBuilder createProcessInstanceBuilder();

    /*******发起流程实例******/
    ProcessInstance startProcessInstanceByKey(String processDefinitionKey);

    ProcessInstance startProcessInstanceByKey(String processDefinitionKey, String businessKey);

    ProcessInstance startProcessInstanceByKey(String processDefinitionKey, Map<String, Object> variables);

    ProcessInstance startProcessInstanceByKey(String processDefinitionKey, String businessKey, Map<String, Object> variables);

    ProcessInstance startProcessInstanceByKeyAndTenantId(String processDefinitionKey, String tenantId);

    ProcessInstance startProcessInstanceByKeyAndTenantId(String processDefinitionKey, String businessKey, String tenantId);

    ProcessInstance startProcessInstanceByKeyAndTenantId(String processDefinitionKey, Map<String, Object> variables, String tenantId);

    ProcessInstance startProcessInstanceByKeyAndTenantId(String processDefinitionKey, String businessKey, Map<String, Object> variables, String tenantId);

    ProcessInstance startProcessInstanceById(String processDefinitionId);

    ProcessInstance startProcessInstanceById(String processDefinitionId, String businessKey);

    ProcessInstance startProcessInstanceById(String processDefinitionId, Map<String, Object> variables);

    ProcessInstance startProcessInstanceById(String processDefinitionId, String businessKey, Map<String, Object> variables);

    ProcessInstance startProcessInstanceByMessage(String messageName);

    ProcessInstance startProcessInstanceByMessageAndTenantId(String messageName, String tenantId);

    ProcessInstance startProcessInstanceByMessage(String messageName, String businessKey);

    ProcessInstance startProcessInstanceByMessageAndTenantId(String messageName, String businessKey, String tenantId);

    ProcessInstance startProcessInstanceByMessage(String messageName, Map<String, Object> processVariables);

    ProcessInstance startProcessInstanceByMessageAndTenantId(String messageName, Map<String, Object> processVariables, String tenantId);

    ProcessInstance startProcessInstanceByMessage(String messageName, String businessKey, Map<String, Object> processVariables);

    ProcessInstance startProcessInstanceByMessageAndTenantId(String messageName, String businessKey, Map<String, Object> processVariables, String tenantId);

    /*****删除流程实例*********/
    void deleteProcessInstance(String processInstanceId, String deleteReason);


    List<String> getActiveActivityIds(String executionId);

    /*******唤醒等待的流程*****/
    void trigger(String executionId);

    void trigger(String executionId, Map<String, Object> processVariables);

    void trigger(String executionId, Map<String, Object> processVariables, Map<String, Object> transientVariables);

    /******更新businessKey*****/
    void updateBusinessKey(String processInstanceId, String businessKey);

    //人员身份与流程的关系管理Identity Links

    void addUserIdentityLink(String processInstanceId, String userId, String identityLinkType);


    void addGroupIdentityLink(String processInstanceId, String groupId, String identityLinkType);


    void addParticipantUser(String processInstanceId, String userId);


    void addParticipantGroup(String processInstanceId, String groupId);


    void deleteParticipantUser(String processInstanceId, String userId);


    void deleteParticipantGroup(String processInstanceId, String groupId);


    void deleteUserIdentityLink(String processInstanceId, String userId, String identityLinkType);


    void deleteGroupIdentityLink(String processInstanceId, String groupId, String identityLinkType);


    List<IdentityLink> getIdentityLinksForProcessInstance(String instanceId);

    // 流程变量获取Variables
    // ////////////////////////////////////////////////////////////////////

    Map<String, Object> getVariables(String executionId);

    Map<String, VariableInstance> getVariableInstances(String executionId);

    List<VariableInstance> getVariableInstancesByExecutionIds(Set<String> executionIds);

    Map<String, Object> getVariablesLocal(String executionId);

    Map<String, VariableInstance> getVariableInstancesLocal(String executionId);

    Map<String, Object> getVariables(String executionId, Collection<String> variableNames);

    Map<String, VariableInstance> getVariableInstances(String executionId, Collection<String> variableNames);

    Map<String, Object> getVariablesLocal(String executionId, Collection<String> variableNames);

    Map<String, VariableInstance> getVariableInstancesLocal(String executionId, Collection<String> variableNames);

    Object getVariable(String executionId, String variableName);

    VariableInstance getVariableInstance(String executionId, String variableName);

    <T> T getVariable(String executionId, String variableName, Class<T> variableClass);

    boolean hasVariable(String executionId, String variableName);

    Object getVariableLocal(String executionId, String variableName);

    VariableInstance getVariableInstanceLocal(String executionId, String variableName);

    <T> T getVariableLocal(String executionId, String variableName, Class<T> variableClass);

    boolean hasVariableLocal(String executionId, String variableName);

    void setVariable(String executionId, String variableName, Object value);

    void setVariableLocal(String executionId, String variableName, Object value);

    void setVariables(String executionId, Map<String, ? extends Object> variables);

    void setVariablesLocal(String executionId, Map<String, ? extends Object> variables);

    void removeVariable(String executionId, String variableName);

    void removeVariableLocal(String executionId, String variableName);

    void removeVariables(String executionId, Collection<String> variableNames);

    void removeVariablesLocal(String executionId, Collection<String> variableNames);

    ////////DataObject
    Map<String, DataObject> getDataObjects(String executionId);

    Map<String, DataObject> getDataObjects(String executionId, String locale, boolean withLocalizationFallback);

    Map<String, DataObject> getDataObjectsLocal(String executionId);

    Map<String, DataObject> getDataObjectsLocal(String executionId, String locale, boolean withLocalizationFallback);

    Map<String, DataObject> getDataObjects(String executionId, Collection<String> dataObjectNames);

    Map<String, DataObject> getDataObjects(String executionId, Collection<String> dataObjectNames, String locale, boolean withLocalizationFallback);

    Map<String, DataObject> getDataObjectsLocal(String executionId, Collection<String> dataObjects);

    Map<String, DataObject> getDataObjectsLocal(String executionId, Collection<String> dataObjectNames, String locale, boolean withLocalizationFallback);

    DataObject getDataObject(String executionId, String dataObject);

    DataObject getDataObject(String executionId, String dataObjectName, String locale, boolean withLocalizationFallback);

    DataObject getDataObjectLocal(String executionId, String dataObjectName);

    DataObject getDataObjectLocal(String executionId, String dataObjectName, String locale, boolean withLocalizationFallback);


    // 查询 ////////////////////////////////////////////////////////


    ExecutionQuery createExecutionQuery();

    NativeExecutionQuery createNativeExecutionQuery();

    ProcessInstanceQuery createProcessInstanceQuery();

    NativeProcessInstanceQuery createNativeProcessInstanceQuery();

    // 流程实例状态 Process instance state //////////////////////////////////////////

    void suspendProcessInstanceById(String processInstanceId);

    void activateProcessInstanceById(String processInstanceId);

    // 事件 Events
    void signalEventReceived(String signalName);

    void signalEventReceivedWithTenantId(String signalName, String tenantId);

    void signalEventReceivedAsync(String signalName);

    void signalEventReceivedAsyncWithTenantId(String signalName, String tenantId);

    void signalEventReceived(String signalName, Map<String, Object> processVariables);

    void signalEventReceivedWithTenantId(String signalName, Map<String, Object> processVariables, String tenantId);

    void signalEventReceived(String signalName, String executionId);

    void signalEventReceived(String signalName, String executionId, Map<String, Object> processVariables);

    void signalEventReceivedAsync(String signalName, String executionId);

    void messageEventReceived(String messageName, String executionId);

    void messageEventReceived(String messageName, String executionId, Map<String, Object> processVariables);

    void messageEventReceivedAsync(String messageName, String executionId);

    void addEventListener(ActivitiEventListener listenerToAdd);

    void addEventListener(ActivitiEventListener listenerToAdd, ActivitiEventType... types);

    void removeEventListener(ActivitiEventListener listenerToRemove);

    void dispatchEvent(ActivitiEvent event);


    void setProcessInstanceName(String processInstanceId, String name);


    List<FlowNode> getEnabledActivitiesFromAdhocSubProcess(String executionId);


    Execution executeActivityInAdhocSubProcess(String executionId, String activityId);

    void completeAdhocSubProcess(String executionId);


    List<Event> getProcessInstanceEvents(String processInstanceId);

}
