package com.bpm.example;

import org.activiti.engine.query.Query;
import org.activiti.engine.repository.ProcessDefinition;

import java.util.Set;

public interface ProcessDefinitionQuery extends Query<ProcessDefinitionQuery, ProcessDefinition> {

    //根据流程定义id查询
    ProcessDefinitionQuery processDefinitionId(String processDefinitionId);

    //根据一组流程定义id批量查询
    ProcessDefinitionQuery processDefinitionIds(Set<String> processDefinitionIds);

    //根据流程分类查询
    ProcessDefinitionQuery processDefinitionCategory(String processDefinitionCategory);

    //根据流程分类模糊查询
    ProcessDefinitionQuery processDefinitionCategoryLike(String processDefinitionCategoryLike);

    //根据流程分类查询不属于该分类的流程定义
    ProcessDefinitionQuery processDefinitionCategoryNotEquals(String categoryNotEquals);

    //根据流程名称查询
    ProcessDefinitionQuery processDefinitionName(String processDefinitionName);

    //根据流程名称模糊查询
    ProcessDefinitionQuery processDefinitionNameLike(String processDefinitionNameLike);

    //根据部署id查询
    ProcessDefinitionQuery deploymentId(String deploymentId);

    //根据一组部署id批量查询
    ProcessDefinitionQuery deploymentIds(Set<String> deploymentIds);

    //根据流程定义key查询
    ProcessDefinitionQuery processDefinitionKey(String processDefinitionKey);

    //根据流程定义key模糊查询
    ProcessDefinitionQuery processDefinitionKeyLike(String processDefinitionKeyLike);

    //根据流程定义版本查询，需要和流程定义key条件联合查询
    ProcessDefinitionQuery processDefinitionVersion(Integer processDefinitionVersion);

    //查询版本号大于指定版本的流程定义
    ProcessDefinitionQuery processDefinitionVersionGreaterThan(Integer processDefinitionVersion);

    //查询版本号大于等于指定版本的流程定义
    ProcessDefinitionQuery processDefinitionVersionGreaterThanOrEquals(Integer processDefinitionVersion);

    //查询版本号小于指定版本的流程定义
    ProcessDefinitionQuery processDefinitionVersionLowerThan(Integer processDefinitionVersion);

    //查询版本号小于等于指定版本的流程定义
    ProcessDefinitionQuery processDefinitionVersionLowerThanOrEquals(Integer processDefinitionVersion);

    //查询最新版本的流程定义
    ProcessDefinitionQuery latestVersion();

    //根据资源名称查询
    ProcessDefinitionQuery processDefinitionResourceName(String resourceName);

    //根据资源名称模糊查询
    ProcessDefinitionQuery processDefinitionResourceNameLike(String resourceNameLike);

    //根据固定发起人查询
    ProcessDefinitionQuery startableByUser(String userId);

    //查询挂起状态的流程定义
    ProcessDefinitionQuery suspended();

    //查询激活状态的流程定义
    ProcessDefinitionQuery active();

    //根据租户id查询
    ProcessDefinitionQuery processDefinitionTenantId(String tenantId);

    //根据租户id模糊查询
    ProcessDefinitionQuery processDefinitionTenantIdLike(String tenantIdLike);

    //查询没有租户id的流程定义
    ProcessDefinitionQuery processDefinitionWithoutTenantId();

    //查询具有指定消息名称的启动消息事件的流程定义
    ProcessDefinitionQuery messageEventSubscriptionName(String messageName);

    ////////////////////////////排序//////////////////////////////////

    //按流程定义分类排序，需要指定升序或降序
    ProcessDefinitionQuery orderByProcessDefinitionCategory();

    //按流程定义key排序，需要指定升序或降序
    ProcessDefinitionQuery orderByProcessDefinitionKey();

    //按流程定义id排序，需要指定升序或降序
    ProcessDefinitionQuery orderByProcessDefinitionId();

    //按流程定义版本排序，需要指定升序或降序
    ProcessDefinitionQuery orderByProcessDefinitionVersion();

    //按流程定义名称排序，需要指定升序或降序
    ProcessDefinitionQuery orderByProcessDefinitionName();

    //按部署id排序，需要指定升序或降序
    ProcessDefinitionQuery orderByDeploymentId();

    //按租户id排序，需要指定升序或降序
    ProcessDefinitionQuery orderByTenantId();

}
