package com.bpm.example;

import org.activiti.engine.query.Query;
import org.activiti.engine.repository.Deployment;

public interface DeploymentQuery extends Query<DeploymentQuery, Deployment> {

    //根据部署id查询
    DeploymentQuery deploymentId(String deploymentId);

    //根据部署名称查询
    DeploymentQuery deploymentName(String name);

    //根据部署名称模糊查询
    DeploymentQuery deploymentNameLike(String nameLike);

    //根据部署分类查询
    DeploymentQuery deploymentCategory(String category);

    //根据部署分类模糊查询
    DeploymentQuery deploymentCategoryLike(String categoryLike);

    //根据部署分类查询不属于该分类的部署
    DeploymentQuery deploymentCategoryNotEquals(String categoryNotEquals);

    //根据部署key查询
    DeploymentQuery deploymentKey(String key);

    //根据部署key模糊查询
    DeploymentQuery deploymentKeyLike(String keyLike);

    //根据租户id查询
    DeploymentQuery deploymentTenantId(String tenantId);

    //根据租户id模糊查询
    DeploymentQuery deploymentTenantIdLike(String tenantIdLike);

    //查询没有租户id的部署
    DeploymentQuery deploymentWithoutTenantId();

    //根据流程定义key查询
    DeploymentQuery processDefinitionKey(String key);

    //根据流程定义key模糊查询
    DeploymentQuery processDefinitionKeyLike(String keyLike);

    //查找最新的部署记录，需要和部署key条件联合查询
    DeploymentQuery latest();

    /////////////////////////////排序/////////////////////////////

    //按照部署id排序，需要指定升序或降序.
    DeploymentQuery orderByDeploymentId();

    //按照部署名称排序，需要指定升序或降序.
    DeploymentQuery orderByDeploymentName();

    //按照部署时间排序，需要指定升序或降序.
    DeploymentQuery orderByDeploymenTime();

    //按照租户id排序，需要指定升序或降序.
    DeploymentQuery orderByTenantId();
}