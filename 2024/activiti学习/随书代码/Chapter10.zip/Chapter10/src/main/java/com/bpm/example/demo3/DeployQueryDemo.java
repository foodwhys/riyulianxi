package com.bpm.example.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
import org.activiti.engine.impl.persistence.entity.ResourceEntity;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.junit.Test;

import java.util.Map;

@Slf4j
public class DeployQueryDemo extends ActivitiEngineUtil {
    @Test
    public void deploy() {
        //加载Activiti配置文件并初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        Deployment deployment = repositoryService.createDeployment()
                //设置部署基本属性
                .key("HolidayRequest")
                .name("请假申请")
                .category("HR")
                .tenantId("HR")
                //添加classpath下的流程定义资源
                .addClasspathResource("processes/HolidayRequest.bpmn20.xml")
                //执行部署
                .deploy();
        log.info("部署记录：deployment_id={}, deployment_name={}", deployment.getId(), deployment.getName());
        //查询流程资源
        log.info("部署资源:");
        if (deployment instanceof DeploymentEntity) {
            DeploymentEntity entity = (DeploymentEntity) deployment;
            Map<String, ResourceEntity> resourceEntityMap = entity.getResources();
            for (Map.Entry<String, ResourceEntity> resourceEntity : resourceEntityMap.entrySet()) {
                ResourceEntity entityValue = resourceEntity.getValue();
                log.info("    resource_name={}, deployment_id={}", entityValue.getName(), entityValue.getDeploymentId());
            }
        }
        //查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                //指定流程定义key
                .processDefinitionKey("HolidayRequest")
                //指定激活状态
                .active()
                //查找最新版本
                .latestVersion()
                //返回单个记录
                .singleResult();
        log.info("流程定义:processDefinition_id={}, processDefinition_key={}",processDefinition.getId(),processDefinition.getName());
        //关闭流程引擎
        closeEngine();
    }
}
