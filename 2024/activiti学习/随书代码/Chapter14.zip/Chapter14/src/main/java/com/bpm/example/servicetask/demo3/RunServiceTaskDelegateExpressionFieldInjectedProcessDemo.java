package com.bpm.example.servicetask.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.servicetask.demo3.delegate.CalculationDelegateExpressionFieldInjectedJavaDelegate;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunServiceTaskDelegateExpressionFieldInjectedProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runServiceTaskDelegateExpressionFieldInjectedProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ServiceTaskDelegateExpressionFieldInjectedProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //初始化流程变量
        Map variables = new HashMap();
        variables.put("unitPrice", 100.0);
        variables.put("quantity", 4);
        variables.put("description", "此次采购了4个单价100元的办公耗材");
        CalculationDelegateExpressionFieldInjectedJavaDelegate calculationDelegateExpressionFieldInjectedJavaDelegate = new CalculationDelegateExpressionFieldInjectedJavaDelegate();
        variables.put("calculationDelegateExpressionFieldInjectedJavaDelegate", calculationDelegateExpressionFieldInjectedJavaDelegate);
        //办理第一个任务
        taskService.complete(task.getId(), variables);

        //查询历史流程变量
        HistoricVariableInstance historicVariableInstance = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).variableName("totalAmount").singleResult();
        log.info("totalAmount的值为：{}", historicVariableInstance.getValue());

        //关闭流程引擎
        closeEngine();
    }
}