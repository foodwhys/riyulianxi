package com.bpm.example.servicetask.demo1.delegate;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;

@Slf4j
public class CalculationStringFieldInjectedJavaDelegate implements JavaDelegate {
    @Setter
    private Expression unitPrice;
    @Setter
    private Expression quantity;
    @Setter
    private Expression description;

    public void execute(DelegateExecution execution) {
        //读取注入的unitPrice字段值
        double unitPriceNum = Double.valueOf((String) unitPrice.getValue(execution));
        //读取注入的quantity字段值
        int quantityNum = Integer.valueOf((String) quantity.getValue(execution));
        //读取注入的description字段值
        String descriptionStr = (String) description.getValue(execution);
        double totalAmount = unitPriceNum * quantityNum;
        log.info("单价：{}，数量：{}，总价：{}", unitPriceNum, quantityNum, totalAmount);
        log.info("描述信息：{}", descriptionStr);
        //将totalAmount放入流程变量中
        execution.setVariable("totalAmount", totalAmount);
    }
}