package com.bpm.example.servicetask.demo1;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;

@Slf4j
public class RunServiceTaskStringFieldInjectedProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runServiceTaskStringFieldInjectedProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ServiceTaskStringFieldInjectedProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询历史流程变量
        HistoricVariableInstance historicVariableInstance = historyService.createHistoricVariableInstanceQuery()
                .processInstanceId(processInstance.getId())
                .variableName("totalAmount")
                .singleResult();
        log.info("totalAmount的值为：{}", historicVariableInstance.getValue());

        //关闭流程引擎
        closeEngine();
    }
}