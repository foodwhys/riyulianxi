package com.bpm.example.servicetask.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunServiceTaskThrowsExceptionProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runServiceTaskThrowsExceptionProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ServiceTaskThrowsExceptionProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第一个用户任务为：" + firstTask.getName());
        //初始化流程变量
        Map variables = new HashMap();
        variables.put("applyNum", 10);
        variables.put("description", "申请领用10台电脑");
        //办理第一个任务
        taskService.complete(firstTask.getId(), variables);

        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第二个用户任务为：" + secondTask.getName());

        //关闭流程引擎
        closeEngine();
    }
}