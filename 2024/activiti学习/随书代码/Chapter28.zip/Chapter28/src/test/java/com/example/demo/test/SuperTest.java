package com.example.demo.test;

public class SuperTest {
}
