package com.example.demo.mq;

import org.activiti.engine.ManagementService;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@RocketMQMessageListener(
        topic = JobProducer.JOB_TOPIC,
        consumerGroup = "job_consumer_group",
        consumeMode = ConsumeMode.ORDERLY
)
public class JobConsumer implements RocketMQListener<JobMessage> {
    private Logger log = LoggerFactory.getLogger(JobProducer.class);

    @Autowired
    private ManagementService managementService;

    @Override
    public void onMessage(JobMessage jobMessage) {
        log.info("Consumer job message {}", jobMessage);
        managementService.executeJob(jobMessage.getJobId());
    }
}
