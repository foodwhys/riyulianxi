package com.example.demo.mq;

import com.example.demo.extend.AsyncMongoHistoricVariableInstanceDataManagerImpl;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntityImpl;
import org.activiti.engine.impl.persistence.entity.data.HistoricVariableInstanceDataManager;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

@Component
@RocketMQMessageListener(
        topic = HistoricVariableProducer.HISTORIC_TOPIC,
        consumerGroup = "variable_consumer_group"
)
public class HistoricVariableConsumer implements RocketMQListener<HistoricVariableInstanceEntityMessage> {

    private Logger log = LoggerFactory.getLogger(JobProducer.class);

    @Autowired
    private ProcessEngineConfigurationImpl configuration;

    @Override
    public void onMessage(HistoricVariableInstanceEntityMessage entityMessage) {
        log.info("Consumer HistoricVariableInstanceEntityMessage={}", entityMessage);
        HistoricVariableInstanceDataManager historicVariableInstanceDataManager = configuration.getHistoricVariableInstanceDataManager();
        HistoricVariableInstanceEntity entity = historicVariableInstanceDataManager.findById(entityMessage.getEntity().getId());
        switch (entityMessage.getOpType()) {
            case INSERT:
                if (entity == null) {
                    historicVariableInstanceDataManager.insert(entityMessage.getEntity());
                }
                break;
            case UPDATE:
                if (entity != null && entity.getRevision() <= entityMessage.getEntity().getRevision()) {
                    historicVariableInstanceDataManager.update(entityMessage.getEntity());
                }
                break;
            case DELETE:
                if (entity != null && entity.getRevision() <= entityMessage.getEntity().getRevision()) {
                    historicVariableInstanceDataManager.delete(entityMessage.getEntity());
                }
                break;
            default:
                log.error("Unsupported opType, message={}", entityMessage);
        }
    }
}
