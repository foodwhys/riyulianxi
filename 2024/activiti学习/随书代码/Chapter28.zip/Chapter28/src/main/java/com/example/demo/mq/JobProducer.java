package com.example.demo.mq;

import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JobProducer {

    private Logger log = LoggerFactory.getLogger(JobProducer.class);

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    public static final String JOB_TOPIC = "job_mq_topic";

    public void sendJobMessage(String processInstanceId, String jobId) {
        JobMessage jobMessage = new JobMessage(processInstanceId, jobId);
        log.info("Producer job message,processInstanceId={},jobId={}", processInstanceId, jobId);
        rocketMQTemplate.syncSendOrderly(JOB_TOPIC, jobMessage, jobMessage.getProcessInstanceId());
    }
}
