package com.example.demo.config;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TraceConverter extends ClassicConverter {

    public static final String TRACEID = "traceid";
    public static final String SPANID = "spanid";
    public static final String ERRNO = "errno";
    public static final String ERRMSG = "errmsg";
    public static final String URI = "uri";

    @Override
    public String convert(ILoggingEvent loggingEvent) {
        Map<String, String> map = loggingEvent.getMDCPropertyMap();
        String msg = loggingEvent.getFormattedMessage();
        return formatLog(msg, map);
    }

    private String formatLog(String msg, Map<String, String> map) {
        String dltag = "_undef";
        String traceid = map.get(TRACEID) == null ? "" : map.get(TRACEID);
        String spanid = map.get(SPANID) == null ? "" : map.get(SPANID);
        String uri = map.get(URI) == null ? "" : map.get(URI);
        String errno = map.get(ERRNO) == null ? "" : map.get(ERRNO);
        String errmsg = map.get(ERRMSG) == null ? "" : map.get(ERRMSG);

        StringBuffer sb = new StringBuffer();
        //start 匹配dltag||traceid=xxx||spanid=xxx|| 防止打印日志重复打印这部分
        String regx = "(^_[a-z_]+)\\|\\|"
                + "traceid=([a-z0-9]+|[a-z0-9]{0})\\|\\|"
                + "spanid=([a-z0-9]+|[a-z0-9]{0})\\|\\|";
        Pattern pt = Pattern.compile(regx);
        Matcher matcher = pt.matcher(msg);
        if (matcher.find()) {
            dltag = matcher.group(1);
            return msg.replaceFirst(regx, sb.append(dltag).append("||traceid=").append(traceid)
                    .append("||spanid=").append(spanid)
                    .append("||").toString());
        }
        //end
        return sb.append(dltag).append("||traceid=").append(traceid)
                .append("||spanid=").append(spanid)
                .append("||uri=").append(uri)
                .append("||errno=").append(errno)
                .append("||errmsg=").append(errmsg)
                .append("||").append("_msg=").append(msg).toString();
    }
}
