package com.example.demo.mq;

public enum OpType {
    INSERT,
    UPDATE,
    DELETE
}
