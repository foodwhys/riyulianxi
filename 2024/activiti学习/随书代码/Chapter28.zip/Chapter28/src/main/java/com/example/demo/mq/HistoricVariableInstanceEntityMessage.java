package com.example.demo.mq;

import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;

public class HistoricVariableInstanceEntityMessage {
    private OpType opType;
    private HistoricVariableInstanceEntity entity;
    private long created;

    public HistoricVariableInstanceEntityMessage() {
    }

    public HistoricVariableInstanceEntityMessage(OpType opType, HistoricVariableInstanceEntity entity, long created) {
        this.opType = opType;
        this.entity = entity;
        this.created = created;
    }

    public OpType getOpType() {
        return opType;
    }

    public void setOpType(OpType opType) {
        this.opType = opType;
    }

    public HistoricVariableInstanceEntity getEntity() {
        return entity;
    }

    public void setEntity(HistoricVariableInstanceEntity entity) {
        this.entity = entity;
    }

    public long getCreated() {
        return created;
    }

    public void setCreated(long created) {
        this.created = created;
    }
}
