package com.example.demo.extend;

import com.example.demo.mq.HistoricVariableProducer;
import com.example.demo.mq.OpType;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.HistoricVariableInstanceQueryImpl;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.AbstractManager;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntityImpl;
import org.activiti.engine.impl.persistence.entity.data.HistoricVariableInstanceDataManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncMongoHistoricVariableInstanceDataManagerImpl extends AbstractManager implements HistoricVariableInstanceDataManager {

    private Logger log = LoggerFactory.getLogger(AsyncMongoHistoricVariableInstanceDataManagerImpl.class);
    //通过线程池来操作MongoDB
    private ExecutorService executorService = Executors.newFixedThreadPool(10);
    private MongoTemplate mongoTemplate;
    private HistoricVariableProducer historicVariableProducer;

    public AsyncMongoHistoricVariableInstanceDataManagerImpl(ProcessEngineConfigurationImpl processEngineConfiguration, MongoTemplate mongoTemplate) {
        super(processEngineConfiguration);
        this.mongoTemplate = mongoTemplate;
    }

    public AsyncMongoHistoricVariableInstanceDataManagerImpl(ProcessEngineConfigurationImpl processEngineConfiguration) {
        super(processEngineConfiguration);
    }

    @Override
    public HistoricVariableInstanceEntity create() {
        return new HistoricVariableInstanceEntityImpl();
    }

    //根据ID查询历史变量
    @Override
    public HistoricVariableInstanceEntity findById(String entityId) {
        return mongoTemplate.findById(entityId, HistoricVariableInstanceEntityImpl.class);
    }

    //插入历史变量
    @Override
    public void insert(HistoricVariableInstanceEntity entity) {
        executorService.submit(() -> {
            try {
                log.info("Async mongo insert {}", entity);
                mongoTemplate.insert(entity);
            } catch (Exception ex) {
                log.error("Exception ex", ex);
                historicVariableProducer.sendHistoricVariableMessage(OpType.INSERT, entity);
            }
        });
    }

    //更新历史变量
    @Override
    public HistoricVariableInstanceEntity update(HistoricVariableInstanceEntity entity) {
        executorService.submit(() -> {
                    try {
                        log.info("Async mongo update {}", entity);
                        Criteria criteria = Criteria.where("id").is(entity.getId());
                        Query query = new Query(criteria);
                        mongoTemplate.find(new Query(criteria), HistoricVariableInstanceEntity.class);
                        Update update = new Update();
                        mongoTemplate.updateFirst(query, update, HistoricVariableInstanceEntityImpl.class);
                    } catch (Exception ex) {
                        log.error("Exception ex", ex);
                        historicVariableProducer.sendHistoricVariableMessage(OpType.UPDATE, entity);
                    }
                }
        );
        return entity;
    }

    @Override
    public void delete(HistoricVariableInstanceEntity entity) {
        executorService.submit(() -> {
                    try {
                        log.info("Async mongo delete {}", entity);
                        mongoTemplate.remove(entity);
                    } catch (Exception ex) {
                        log.error("Exception ex", ex);
                        historicVariableProducer.sendHistoricVariableMessage(OpType.DELETE, entity);
                    }
                }
        );
    }

    @Override
    public void delete(String id) {
        HistoricVariableInstanceEntity historicVariableInstance = new HistoricVariableInstanceEntityImpl();
        historicVariableInstance.setId(id);
        delete(historicVariableInstance);
    }

    @Override
    public List<HistoricVariableInstanceEntity> findHistoricVariableInstancesByProcessInstanceId(String processInstanceId) {
        Criteria criteria = Criteria.where("processInstanceId").is(processInstanceId);
        List<HistoricVariableInstanceEntityImpl> entityList = mongoTemplate.find(new Query(criteria),
                HistoricVariableInstanceEntityImpl.class);
        List<HistoricVariableInstanceEntity> ret = new ArrayList<>();
        ret.addAll(entityList);
        return ret;
    }

    @Override
    public List<HistoricVariableInstanceEntity> findHistoricVariableInstancesByTaskId(String taskId) {
        Criteria criteria = Criteria.where("taskId").is(taskId);
        List<HistoricVariableInstanceEntityImpl> entityList = mongoTemplate.find(new Query(criteria),
                HistoricVariableInstanceEntityImpl.class);
        List<HistoricVariableInstanceEntity> ret = new ArrayList<>();
        ret.addAll(entityList);
        return ret;
    }

    @Override
    public long findHistoricVariableInstanceCountByQueryCriteria(HistoricVariableInstanceQueryImpl historicProcessVariableQuery) {
        Query query = new Query(createCriteria(historicProcessVariableQuery));
        return mongoTemplate.count(query, HistoricVariableInstanceEntityImpl.class);
    }

    @Override
    public List<HistoricVariableInstance> findHistoricVariableInstancesByQueryCriteria(HistoricVariableInstanceQueryImpl historicProcessVariableQuery, Page page) {
        Query query = new Query(createCriteria(historicProcessVariableQuery));
        query.skip(page.getFirstResult());
        query.limit(page.getMaxResults());
        List<HistoricVariableInstanceEntityImpl> entityList = mongoTemplate.find(query, HistoricVariableInstanceEntityImpl.class);
        List<HistoricVariableInstance> ret = new ArrayList<>();
        ret.addAll(entityList);
        return ret;
    }

    private Criteria createCriteria(HistoricVariableInstanceQueryImpl historicProcessVariableQuery) {
        Criteria criteria = new Criteria();
        if (StringUtils.isNotBlank(historicProcessVariableQuery.getProcessInstanceId())) {
            criteria.andOperator(Criteria.where("processInstanceId").is(historicProcessVariableQuery.getProcessInstanceId()));
        }
        if (StringUtils.isNotBlank(historicProcessVariableQuery.getTaskId())) {
            criteria.andOperator(Criteria.where("taskId").is(historicProcessVariableQuery.getTaskId()));
        }
        if (StringUtils.isNotBlank(historicProcessVariableQuery.getVariableName())) {
            criteria.andOperator(Criteria.where("variableName").is(historicProcessVariableQuery.getVariableName()));
        }
        return criteria;
    }

    @Override
    public HistoricVariableInstanceEntity findHistoricVariableInstanceByVariableInstanceId(String variableInstanceId) {
        return mongoTemplate.findById(variableInstanceId, HistoricVariableInstanceEntityImpl.class);
    }

    @Override
    public List<HistoricVariableInstance> findHistoricVariableInstancesByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults) {
        throw new RuntimeException("不支持的操作");
    }

    @Override
    public long findHistoricVariableInstanceCountByNativeQuery(Map<String, Object> parameterMap) {
        throw new RuntimeException("不支持的操作");
    }
}
