package com.example.demo.mq;

import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

@Component
public class HistoricVariableProducer {
    private Logger log = LoggerFactory.getLogger(HistoricVariableProducer.class);

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    public static final String HISTORIC_TOPIC = "historic_mq_topic";

    public void sendHistoricVariableMessage(OpType opType, HistoricVariableInstanceEntity entity) {
        log.info("Producer historic variable message,processInstanceId={},variable={}", entity.getProcessInstanceId(), entity);
        HistoricVariableInstanceEntityMessage entityMessage = new HistoricVariableInstanceEntityMessage(opType, entity, System.currentTimeMillis());
        Message<HistoricVariableInstanceEntityMessage> message = MessageBuilder.withPayload(entityMessage).build();
        rocketMQTemplate.syncSend(HISTORIC_TOPIC, message, 1000, 4);
    }
}
