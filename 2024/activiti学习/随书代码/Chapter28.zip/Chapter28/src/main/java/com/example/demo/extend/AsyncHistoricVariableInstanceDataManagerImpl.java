package com.example.demo.extend;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntityImpl;
import org.activiti.engine.impl.persistence.entity.data.impl.MybatisHistoricVariableInstanceDataManager;
import org.apache.ibatis.session.SqlSession;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
public class AsyncHistoricVariableInstanceDataManagerImpl extends MybatisHistoricVariableInstanceDataManager {

    private ExecutorService executorService = Executors.newFixedThreadPool(10);

    public AsyncHistoricVariableInstanceDataManagerImpl(ProcessEngineConfigurationImpl processEngineConfiguration) {
        super(processEngineConfiguration);
    }

    @Override
    public void insert(HistoricVariableInstanceEntity entity) {
        log.info("AsyncHistoricVariableInstanceDataManagerImpl insert {}", entity);
        executorService.submit(() -> {
                    SqlSession sqlSession = getProcessEngineConfiguration().getSqlSessionFactory().openSession();
                    sqlSession.insert("insertHistoricVariableInstance", entity);
                }
        );
    }

    @Override
    public HistoricVariableInstanceEntity update(HistoricVariableInstanceEntity entity) {
        log.info("AsyncHistoricVariableInstanceDataManagerImpl update {}", entity);
        executorService.submit(() -> {
                    SqlSession sqlSession = getProcessEngineConfiguration().getSqlSessionFactory().openSession();
                    sqlSession.update("updateVariableInstance", entity);
                }
        );
        return entity;
    }

    @Override
    public void delete(String id) {
        HistoricVariableInstanceEntity historicVariableInstance = new HistoricVariableInstanceEntityImpl();
        historicVariableInstance.setId(id);
        delete(historicVariableInstance);
        log.info("AsyncHistoricVariableInstanceDataManagerImpl delete {}", id);
    }

    @Override
    public void delete(HistoricVariableInstanceEntity entity) {
        log.info("AsyncHistoricVariableInstanceDataManagerImpl delete {}", entity);
        executorService.submit(() -> {
                    SqlSession sqlSession = getProcessEngineConfiguration().getSqlSessionFactory().openSession();
                    sqlSession.delete("deleteVariableInstance", entity);
                }
        );
    }
}
