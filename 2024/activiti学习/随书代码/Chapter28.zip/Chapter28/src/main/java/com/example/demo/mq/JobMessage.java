package com.example.demo.mq;

public class JobMessage {
    private String processInstanceId;
    private String jobId;

    public JobMessage() {
    }

    public JobMessage(String processInstanceId, String jobId) {
        this.processInstanceId = processInstanceId;
        this.jobId = jobId;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }
}
