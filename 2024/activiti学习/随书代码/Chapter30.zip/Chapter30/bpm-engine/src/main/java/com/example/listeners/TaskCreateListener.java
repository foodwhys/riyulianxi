package com.example.listeners;

import com.example.extend.IdRouterService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.impl.ActivitiEntityEventImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TaskCreateListener implements ActivitiEventListener {
    @Autowired
    private IdRouterService idRouterService;

    @Override
    public void onEvent(ActivitiEvent event) {
        TaskEntity taskEntity = (TaskEntity) ((ActivitiEntityEventImpl) event).getEntity();
        //事务提交成功后，将任务ID路由信息写入pika
        idRouterService.addTaskId(taskEntity.getId());
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }
}
