package com.example.listeners;

import com.example.es.TaskDoc;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.delegate.event.impl.ActivitiEntityEventImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class TaskToEsListener implements ActivitiEventListener {
    private Logger log = LoggerFactory.getLogger(TaskToEsListener.class);
    @Value("${bpm.engine-name}")
    private String engineName;
    @Value("${es.task-index:bpm_task}")
    private String taskIndex;
    @Autowired
    private RestHighLevelClient restHighLevelClient;

    ExecutorService executorService = Executors.newFixedThreadPool(20);

    @Override
    public void onEvent(ActivitiEvent event) {
        TaskEntity taskEntity = (TaskEntity) ((ActivitiEntityEventImpl) event).getEntity();
        //事务提交后再写入ElasticSearch
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                executorService.submit(() -> {
                    try {
                        if (event.getType() == ActivitiEventType.TASK_CREATED || event.getType() == ActivitiEventType.TASK_ASSIGNED) {
                            TaskDoc taskDoc = toTaskDoc(taskEntity);
                            IndexRequest request = new IndexRequest(taskIndex);
                            request.id(taskDoc.getId());
                            JsonMapper jsonMapper = new JsonMapper();
                            request.source(jsonMapper.writeValueAsString(taskDoc), XContentType.JSON);
                            restHighLevelClient.index(request, RequestOptions.DEFAULT);
                        } else if (event.getType() == ActivitiEventType.TASK_COMPLETED) {
                            UpdateRequest request = new UpdateRequest(taskIndex, taskEntity.getId());
                            Map<String, Object> map = new HashMap<>();
                            map.put("status", 2);
                            map.put("completeTime", new Date());
                            restHighLevelClient.update(request, RequestOptions.DEFAULT);
                        }
                    } catch (IOException e) {
                        log.info("写入失败，需要做数据补偿");
                    }
                });
            }
        });
    }

    private TaskDoc toTaskDoc(TaskEntity taskEntity) {
        TaskDoc doc = new TaskDoc();
        doc.setId(taskEntity.getId());
        doc.setName(taskEntity.getName());
        doc.setActivityId(taskEntity.getTaskDefinitionKey());
        doc.setAssignee(taskEntity.getAssignee());
        if (taskEntity.getAssignee() == null && taskEntity.getCandidates() != null) {
            String[] candidates = taskEntity.getCandidates().toArray(new String[taskEntity.getCandidates().size()]);
            doc.setCandidates(candidates);
        }
        doc.setProcessInstanceId(taskEntity.getProcessInstanceId());
        if (StringUtils.hasText(taskEntity.getProcessInstance().getName())) {
            doc.setProcessInstanceName(taskEntity.getProcessInstance().getName());
        } else {
            doc.setProcessInstanceName(taskEntity.getProcessInstance().getProcessDefinitionName());
        }
        doc.setEngine(engineName);
        doc.setStatus(1);
        doc.setCreateTime(taskEntity.getCreateTime());
        return doc;
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }
}
