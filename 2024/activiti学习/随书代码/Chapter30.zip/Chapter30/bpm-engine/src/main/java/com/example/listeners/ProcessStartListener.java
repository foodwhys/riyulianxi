package com.example.listeners;

import com.example.extend.IdRouterService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProcessStartListener implements ActivitiEventListener {

    @Autowired
    private IdRouterService idRouterService;

    @Override
    public void onEvent(ActivitiEvent event) {
        //将流程实例ID路由信息写入pika
        idRouterService.addProcessId(event.getProcessInstanceId());
    }

    @Override
    public boolean isFailOnException() {
        return true;
    }
}
