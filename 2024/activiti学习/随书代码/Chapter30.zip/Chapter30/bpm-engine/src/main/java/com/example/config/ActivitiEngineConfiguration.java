package com.example.config;

import com.example.cache.RedisProcessDefinitionCache;
import com.example.extend.CustomProcessDefinitionDataManagerImpl;
import com.example.extend.SnowFlakeIdGenerator;
import com.example.listeners.ProcessStartListener;
import com.example.listeners.TaskCreateListener;
import com.example.listeners.TaskToEsListener;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.activiti.engine.delegate.event.ActivitiEventType.PROCESS_STARTED;
import static org.activiti.engine.delegate.event.ActivitiEventType.TASK_ASSIGNED;
import static org.activiti.engine.delegate.event.ActivitiEventType.TASK_COMPLETED;
import static org.activiti.engine.delegate.event.ActivitiEventType.TASK_CREATED;

@Configuration
public class ActivitiEngineConfiguration {

    @Autowired
    private PlatformTransactionManager transactionManager;
    @Autowired
    private ProcessStartListener processStartListener;
    @Autowired
    private TaskCreateListener taskCreateListener;
    @Autowired
    private TaskToEsListener taskToEsListener;
    @Autowired
    private RedisProcessDefinitionCache processDefinitionCache;
    @Autowired
    private CustomProcessDefinitionDataManagerImpl processDefinitionDataManager;

    @Bean(name = "processEngineConfiguration")
    public ProcessEngineConfigurationImpl processEngineConfiguration(DataSource dataSource) {
        SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();
        configuration.setDataSource(dataSource);
        configuration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
        configuration.setTransactionManager(transactionManager);
        configuration.setProcessDefinitionCache(processDefinitionCache);
        configuration.setProcessDefinitionDataManager(processDefinitionDataManager);
        configuration.setIdGenerator(new SnowFlakeIdGenerator());

        Map<String, List<ActivitiEventListener>> eventListeners = new HashMap<>();
        eventListeners.put(PROCESS_STARTED.name(), Arrays.asList(processStartListener));
        eventListeners.put(TASK_CREATED.name(), Arrays.asList(taskCreateListener, taskToEsListener));
        eventListeners.put(TASK_COMPLETED.name(), Arrays.asList(taskToEsListener));
        eventListeners.put(TASK_ASSIGNED.name(), Arrays.asList(taskToEsListener));
        configuration.setTypedEventListeners(eventListeners);
        return configuration;
    }

    @Bean(name = "processEngine")
    public ProcessEngine processEngine(ProcessEngineConfiguration configuration) {
        return configuration.buildProcessEngine();
    }

    @Bean
    public TaskService taskService(ProcessEngine processEngine) {
        return processEngine.getTaskService();
    }

    @Bean
    public RuntimeService runtimeService(ProcessEngine processEngine) {
        return processEngine.getRuntimeService();
    }

    @Bean
    public RepositoryService repositoryService(ProcessEngine processEngine) {
        return processEngine.getRepositoryService();
    }

    @Bean
    public ManagementService managementService(ProcessEngine processEngine) {
        return processEngine.getManagementService();
    }
}
