package com.example.search.doc;

import lombok.Data;

import java.util.Date;

@Data
public class TaskDoc {
    private String id;
    private String engine;
    private String name;
    private String activityId;
    private String processInstanceId;
    private String processInstanceName;
    private String assignee;
    private String[] candidates;
    private int status;
    private Date createTime;
    private Date completeTime;
}
