package com.example.search.doc;

import lombok.Data;

@Data
public class BaseDoc {
    private String id;
    private String engine;
}
