package com.example.search.doc;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class ElasticSearchDocQuery {
    private Logger log = LoggerFactory.getLogger(ElasticSearchDocQuery.class);
    @Autowired
    private RestHighLevelClient restHighLevelClient;
    @Value("${es.task-index:bpm_task}")
    private String taskIndex;

    public List<TaskDoc> queryTasksByUserId(String userId) {
        List<TaskDoc> ret = new ArrayList<>();
        try {
            SearchRequest request = new SearchRequest(taskIndex);
            request.source().query(QueryBuilders.termQuery("assignee", userId));
            request.source().sort("createTime", SortOrder.DESC);
            SearchResponse search = restHighLevelClient.search(request, RequestOptions.DEFAULT);
            ObjectMapper mapper = new ObjectMapper();
            for (SearchHit hit : search.getHits()) {
                ret.add(mapper.readValue(hit.getSourceAsString(), TaskDoc.class));
            }
        } catch (Exception ex) {
            log.error("Exception ex", ex);
        }
        for (TaskDoc taskDoc : ret) {
            System.out.println("任务ID：" + taskDoc.getId() + ",流程引擎：" + taskDoc.getEngine());
        }
        return ret;
    }
}
