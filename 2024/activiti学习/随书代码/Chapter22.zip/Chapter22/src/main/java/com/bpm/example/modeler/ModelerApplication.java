package com.bpm.example.modeler;

import org.activiti.spring.boot.SecurityAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

//HibernateJpaAutoConfiguration.class,
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
//@ComponentScan(value = "org.activiti")
@EntityScan(basePackages = {"com.bpm.example.modeler"})
public class ModelerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelerApplication.class, args);
	}

}
