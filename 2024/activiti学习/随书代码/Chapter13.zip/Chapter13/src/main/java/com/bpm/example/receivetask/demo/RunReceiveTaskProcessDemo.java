package com.bpm.example.receivetask.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunReceiveTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runReceiveTaskProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ReceiveTaskProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("即将完成第一个任务，当前任务名称：{}", firstTask.getName());
        //完成第一个任务
        taskService.complete(firstTask.getId());
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("即将完成第二个任务，当前任务名称：{}", secondTask.getName());
        //完成第二个任务
        taskService.complete(secondTask.getId());
        //查询执行到此接收任务的执行实例
        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceId(processInstance.getId()) //使用流程实例ID查询
                .activityId("receiveTask1")  //当前活动的id，对应bpmn文件中类型为ReceiveTask的节点id
                .singleResult();
        //设置流程变量
        Map variables = new HashMap<>();
        variables.put("result", "账号成功激活！");
        //触发流程离开接收任务继续往下执行
        runtimeService.trigger(execution.getId(), variables);
        //查询历史流程实例
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        if (historicProcessInstance.getEndTime() != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            log.info("当前流程已结束，结束时间：{}", simpleDateFormat.format(historicProcessInstance.getEndTime()));
        }

        //关闭流程引擎
        closeEngine();
    }
}
