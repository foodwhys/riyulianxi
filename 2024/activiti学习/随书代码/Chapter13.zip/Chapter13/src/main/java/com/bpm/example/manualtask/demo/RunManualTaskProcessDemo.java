package com.bpm.example.manualtask.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.text.SimpleDateFormat;

@Slf4j
public class RunManualTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runManualTaskProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ManualTaskProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("即将完成第一个任务，当前任务名称：{}", firstTask.getName());
        //完成第一个任务
        taskService.complete(firstTask.getId());
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("即将完成第二个任务，当前任务名称：{}", secondTask.getName());
        //完成第二个任务
        taskService.complete(secondTask.getId());
        //查询历史流程实例
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        if (historicProcessInstance.getEndTime() != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            log.info("当前流程已结束，结束时间：{}", simpleDateFormat.format(historicProcessInstance.getEndTime()));
        }

        //关闭流程引擎
        closeEngine();
    }
}