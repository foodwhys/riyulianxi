package com.bpm.example.usertask.demo1;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunUserTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runUserTaskProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/UserTaskProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("第一个任务taskId：{}，taskName为：{}", firstTask.getId(), firstTask.getName());
        log.info("用户任务描述信息为：{}", firstTask.getDescription());
        log.info("用户任务创建时间为：{}", getStringDate(firstTask.getCreateTime()));

        //设置流程变量
        Map variables = new HashMap<>();
        variables.put("dayNum", 3);
        variables.put("applyReason", "休探亲假。");
        //办理第一个任务
        taskService.complete(firstTask.getId(), variables);
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("第二个任务taskId：{}，taskName为：{}", secondTask.getId(), secondTask.getName());
        log.info("用户任务描述信息为：{}", secondTask.getDescription());
        log.info("用户任务创建时间为：{}，过期时间为：{}", getStringDate(secondTask.getCreateTime()), getStringDate(secondTask.getDueDate()));

        //关闭流程引擎
        closeEngine();
    }

    /**
     * 转换时间为字符串
     * @param time
     * @return
     */
    private static String getStringDate(Date time) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = formatter.format(time);
        return dateString;
    }
}