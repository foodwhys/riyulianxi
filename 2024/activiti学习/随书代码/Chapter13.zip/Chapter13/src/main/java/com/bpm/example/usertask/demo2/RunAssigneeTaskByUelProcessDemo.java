package com.bpm.example.usertask.demo2;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.usertask.demo2.bean.TaskAssigneeBean;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunAssigneeTaskByUelProcessDemo extends ActivitiEngineUtil {

    static SimplePropertyPreFilter identityLinkFilter = new SimplePropertyPreFilter(IdentityLink.class,
            "type","userId","groupId");

    @Test
    public void runAssigneeTaskByUelProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/AssigneeTaskByUelProcess.bpmn20.xml");

        //初始化taskAssigneeBean
        TaskAssigneeBean taskAssigneeBean = new TaskAssigneeBean();
        //设置designatedUserName属性值
        taskAssigneeBean.setDesignatedUserName("wangjunlin");
        //设置流程变量
        Map variables = new HashMap();
        variables.put("taskAssigneeBean", taskAssigneeBean);
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables);
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("当前任务为：{}，办理人为：{}", firstTask.getTaskDefinitionKey(), firstTask.getAssignee());
        //完成第一个任务
        taskService.complete(firstTask.getId());
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        //查询任务的候选人信息
        List<IdentityLink> identityLinkList1 = taskService.getIdentityLinksForTask(secondTask.getId());
        log.info("当前任务为：{}，候选用户为：{}", secondTask.getTaskDefinitionKey(), JSON.toJSONString(identityLinkList1, identityLinkFilter));
        //候选人liuxiaopeng认领第二个任务
        taskService.claim(secondTask.getId(), "liuxiaopeng");
        //完成第二个任务
        taskService.complete(secondTask.getId());
        //查询第三个任务
        Task thirdTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        //查询任务的候选组信息
        List<IdentityLink> identityLinkList2 = taskService.getIdentityLinksForTask(thirdTask.getId());
        log.info("当前任务为：{}，候选用户组为：{}" ,thirdTask.getTaskDefinitionKey(), JSON.toJSONString(identityLinkList2, identityLinkFilter));
        //候选人xuqiangwei认领第三个任务（用户xuqiangwei是用户组group1的成员）
        taskService.claim(thirdTask.getId(), "huhaiqin");
        //完成第三个任务
        taskService.complete(thirdTask.getId());
        //查询第四个任务
        Task fourthTask = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        log.info("当前任务为：{}，办理人为：{}", fourthTask.getTaskDefinitionKey(), fourthTask.getAssignee());
        //完成第四个任务
        taskService.complete(fourthTask.getId());

        //关闭流程引擎
        closeEngine();
    }
}
