package com.bpm.example.demo1.listener;

import org.activiti.engine.RepositoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class AutoDeployInnerFormResourcesListener implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    RepositoryService repositoryService;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent evt) {
        if (evt.getApplicationContext().getParent() == null) {
            return;
        }
        //部署流程
        repositoryService.createDeployment()
                .addClasspathResource("processes/InnerFormProcess.bpmn20.xml").deploy();
    }
}
