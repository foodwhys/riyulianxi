package com.bpm.example.demo3.controller;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.ProcessDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping(value = "/outerform")
public class OuterFormInitFormController {

    @Autowired
    FormService formService;
    @Autowired
    TaskService taskService;
    @Autowired
    RepositoryService repositoryService;

    /**
     * 获取发起表单
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/startForm", method= RequestMethod.GET)
    public String initStartForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //根据processDefinitionKey查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey("OuterFormProcess").latestVersion().singleResult();
        //返回的纯文本的html代码
        Object renderedStartForm = formService.getRenderedStartForm(processDefinition.getId());
        request.setAttribute("renderedStartForm",renderedStartForm);
        request.setAttribute("processDefinitionId",processDefinition.getId());
        return "outerform-startform";
    }

    /**
     * 根据taskId获取表单
     * @param taskId
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/taskForm/{taskId}", method= RequestMethod.GET)
    public String initTaskForm(@PathVariable(value = "taskId") String taskId,
                                HttpServletRequest request, HttpServletResponse response) throws Exception {
        //根据taskId获取表单
        Object renderedTaskForm = formService.getRenderedTaskForm(taskId);
        request.setAttribute("renderedTaskForm",renderedTaskForm);
        request.setAttribute("taskId",taskId);
        return "outerform-taskform";
    }
}
