package com.bpm.example.demo1.controller;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.StartFormData;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.repository.ProcessDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping(value = "/innerform")
public class InnerFormInitFormController {

    @Autowired
    FormService formService;
    @Autowired
    TaskService taskService;
    @Autowired
    RepositoryService repositoryService;

    /**
     * 获取发起表单
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/startForm", method= RequestMethod.GET)
    public String initStartForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //根据processDefinitionKey查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey("InnerFormProcess").latestVersion().singleResult();
        //查询发起表单
        StartFormData startFormData = formService.getStartFormData(processDefinition.getId());
        //获取发起表单内容
        List<FormProperty> formProperties = startFormData.getFormProperties();
        request.setAttribute("formProperties",formProperties);
        request.setAttribute("processDefinitionId",processDefinition.getId());
        return "innerform-startform";
    }

    /**
     * 根据taskId获取表单
     * @param taskId
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/taskForm/{taskId}", method= RequestMethod.GET)
    public String initTaskForm(@PathVariable(value = "taskId") String taskId,
                                HttpServletRequest request, HttpServletResponse response) throws Exception {
        //根据taskId获取表单
        TaskFormData taskFormData = formService.getTaskFormData(taskId);
        //获取表单内容
        List<FormProperty> formProperties = taskFormData.getFormProperties();
        request.setAttribute("formProperties",formProperties);
        request.setAttribute("taskId",taskId);
        return "innerform-taskform";
    }
}
