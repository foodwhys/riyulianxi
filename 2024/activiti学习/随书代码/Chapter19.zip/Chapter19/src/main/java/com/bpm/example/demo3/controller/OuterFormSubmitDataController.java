package com.bpm.example.demo3.controller;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/outerform")
public class OuterFormSubmitDataController {

    @Autowired
    FormService formService;
    @Autowired
    TaskService taskService;
    @Autowired
    RepositoryService repositoryService;

    /**
     * 提交开始事件表单发起流程
     * @param processDefinitionId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/startProcess/{processDefinitionId}", method= RequestMethod.POST)
    public void startProcess(@PathVariable(value = "processDefinitionId") String processDefinitionId,
                            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        Map propertiesMap = new HashMap();
        //从request中读取参数然后转换
        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            String parameterName = parameterNames.nextElement();
            propertiesMap.put(parameterName, request.getParameter(parameterName));
        }
        //提交表单并发起流程
        ProcessInstance processInstance = formService.submitStartFormData(processDefinitionId, propertiesMap);
        //查询流程下一个用户任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        response.getWriter().print("流程发起成功！下一用户任务taskId：" + task.getId());
    }

    /**
     * 提交表单完成任务
     * @param taskId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/completeTask/{taskId}", method= RequestMethod.POST)
    public void completeTask(@PathVariable(value = "taskId") String taskId,
                             HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        Map propertiesMap = new HashMap();
        //从request中读取参数然后转换
        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            String parameterName = parameterNames.nextElement();
            propertiesMap.put(parameterName, request.getParameter(parameterName));
        }
        //提交表单并办理任务
        formService.submitTaskFormData(taskId, propertiesMap);
        response.getWriter().print("任务提交成功！");
    }
}
