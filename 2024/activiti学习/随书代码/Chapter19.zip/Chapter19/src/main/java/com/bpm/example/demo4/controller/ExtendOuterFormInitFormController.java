package com.bpm.example.demo4.controller;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

@Controller
@RequestMapping(value = "/outerform")
public class ExtendOuterFormInitFormController {

    @Autowired
    FormService formService;
    @Autowired
    TaskService taskService;
    @Autowired
    RepositoryService repositoryService;

    /**
     * 获取发起表单
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/startFormExt", method= RequestMethod.GET)
    public String initExtStartForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //根据processDefinitionKey查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey("OuterFormProcess").latestVersion().singleResult();
        //获取开始事件绑定的formKey，即文件路径
        String startFormKey = formService.getStartFormKey(processDefinition.getId());
        String renderedStartForm = readFormContent(startFormKey);
        request.setAttribute("renderedStartForm",renderedStartForm);
        request.setAttribute("processDefinitionId",processDefinition.getId());
        return "outerform-startform";
    }

    /**
     * 根据taskId获取表单
     * @param taskId
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/taskFormExt/{taskId}", method= RequestMethod.GET)
    public String initExtTaskForm(@PathVariable(value = "taskId") String taskId,
                               HttpServletRequest request, HttpServletResponse response) throws Exception {
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        //获取用户任务绑定的formKey，即文件路径
        String taskFormKey = formService.getTaskFormKey(task.getProcessDefinitionId(), task.getTaskDefinitionKey());
        String renderedTaskForm = readFormContent(taskFormKey);
        request.setAttribute("renderedTaskForm",renderedTaskForm);
        request.setAttribute("taskId",taskId);
        return "outerform-taskform";
    }

    /**
     * 根据formKey读取外部表单内容
     * @param formKey
     * @return
     * @throws Exception
     */
    private String readFormContent(String formKey) throws Exception {
        String path = this.getClass().getClassLoader().getResource("/").getPath() + "/";
        String renderedForm = "";
        //根据文件路径读取外置表单内容
        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(path + formKey), StandardCharsets.UTF_8);
        BufferedReader br = new BufferedReader(inputStreamReader);
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            renderedForm = sb.toString();
        } finally {
            br.close();
        }
        return renderedForm;
    }
}
