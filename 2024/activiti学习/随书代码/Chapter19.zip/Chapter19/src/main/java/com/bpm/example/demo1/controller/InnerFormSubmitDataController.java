package com.bpm.example.demo1.controller;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.StartFormData;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/innerform")
public class InnerFormSubmitDataController {

    @Autowired
    FormService formService;
    @Autowired
    TaskService taskService;
    @Autowired
    RepositoryService repositoryService;

    /**
     * 提交开始事件表单发起流程
     * @param processDefinitionId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/startProcess/{processDefinitionId}", method= RequestMethod.POST)
    public void startProcess(@PathVariable(value = "processDefinitionId") String processDefinitionId,
                            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        //根据processDefinitionId获取发起表单
        StartFormData startFormData = formService.getStartFormData(processDefinitionId);
        //获取表单元素
        List<FormProperty> formProperties = startFormData.getFormProperties();
        //获取所有可编辑表单元素的值
        Map propertiesMap = new HashMap();
        for (FormProperty formPropertie : formProperties) {
            if (formPropertie.isWritable()) {
                propertiesMap.put(formPropertie.getId(), request.getParameter(formPropertie.getId()));
            }
        }
        //提交表单并发起流程
        ProcessInstance processInstance = formService.submitStartFormData(processDefinitionId, propertiesMap);
        //查询流程下一个用户任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
        response.getWriter().print("流程发起成功！下一用户任务taskId：" + task.getId());
    }

    /**
     * 提交表单完成任务
     * @param taskId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/completeTask/{taskId}", method= RequestMethod.POST)
    public void completeTask(@PathVariable(value = "taskId") String taskId,
                             HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        //根据taskId获取用户任务表单
        TaskFormData taskFormData = formService.getTaskFormData(taskId);
        //获取表单元素
        List<FormProperty> formProperties = taskFormData.getFormProperties();
        Map propertiesMap = new HashMap();
        //获取所有可编辑表单元素的值
        for (FormProperty formPropertie : formProperties) {
            if (formPropertie.isWritable()) {
                propertiesMap.put(formPropertie.getId(), request.getParameter(formPropertie.getId()));
            }
        }
        //提交表单并办理任务
        formService.submitTaskFormData(taskId, propertiesMap);
        response.getWriter().print("任务提交成功！");
    }
}
