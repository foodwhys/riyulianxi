package com.bpm.example.demo2.formtype;

import com.alibaba.fastjson.JSONObject;
import org.activiti.engine.form.AbstractFormType;

public class JsonFormType extends AbstractFormType {

    /**
     * 定义表单类型的标识符
     *
     * @return
     */
    @Override
    public String getName() {
        return "json";
    }

    /**
     * 把表单中的值转换为实际的对象
     * @param propertyValue
     * @return
     */
    @Override
    public Object convertFormValueToModelValue(String propertyValue) {
        JSONObject jsonObject=JSONObject.parseObject(propertyValue);
        return jsonObject;
    }

    /**
     * 把实际对象的值转换为表单中的值
     * @param modelValue
     * @return
     */
    @Override
    public String convertModelValueToFormValue(Object modelValue) {
        return JSONObject.toJSONString(modelValue);
    }
}
