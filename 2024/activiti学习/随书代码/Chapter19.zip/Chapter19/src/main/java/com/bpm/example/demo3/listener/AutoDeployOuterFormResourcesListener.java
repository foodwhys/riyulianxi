package com.bpm.example.demo3.listener;

import org.activiti.engine.RepositoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import java.io.InputStream;

@Component
public class AutoDeployOuterFormResourcesListener implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    RepositoryService repositoryService;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent evt) {
        if (evt.getApplicationContext().getParent() == null) {
            return;
        }

        InputStream startFormInputStream = getClass().getClassLoader().getResourceAsStream("forms/start.form");
        InputStream taskFormInputStream = getClass().getClassLoader().getResourceAsStream("forms/task.form");
        //部署流程和外置表单
        repositoryService.createDeployment()
                .addInputStream("start.form",startFormInputStream)
                .addInputStream("task.form",taskFormInputStream)
                .addClasspathResource("processes/OuterFormProcess.bpmn20.xml").deploy();
    }
}
