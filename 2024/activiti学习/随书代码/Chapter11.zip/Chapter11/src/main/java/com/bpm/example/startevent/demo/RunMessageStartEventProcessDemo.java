package com.bpm.example.startevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunMessageStartEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runMessageStartEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/MessageStartEventProcess.bpmn20.xml");

        //通过API发起流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceByMessage("dataReportingMessage");
        log.info("流程实例数量：{}", runtimeService.createProcessInstanceQuery().processDefinitionId(processDefinition.getId()).count());
        //查询任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("当前任务名称为: {}", task.getName());
        //完成任务
        taskService.complete(task.getId());

        //关闭流程引擎
        closeEngine();
    }
}
