package com.bpm.example.startevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;

@Slf4j
public class RunErrorStartEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runErrorStartEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ErrorStartEventProcess.bpmn20.xml");

        //发起流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        log.info("流程实例id：{}", processInstance.getId());

        //关闭流程引擎
        closeEngine();
    }
}