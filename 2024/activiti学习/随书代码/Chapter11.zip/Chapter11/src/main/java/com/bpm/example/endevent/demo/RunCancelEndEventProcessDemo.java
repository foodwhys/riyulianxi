package com.bpm.example.endevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElementsContainer;
import org.activiti.bpmn.model.SubProcess;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunCancelEndEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runCancelEndEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/CancelEndEventProcess.bpmn20.xml");
        //获取流程定义对应的BpmnModel
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processDefinition.getId());

        //发起流程
        ProcessInstance mainProcessInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询子流程第一个任务
        Task firstTaskOfSubProcess = taskService.createTaskQuery().processInstanceId(mainProcessInstance.getId()).singleResult();
        log.info("发起流程后，当前流程所在用户任务为：{}", firstTaskOfSubProcess.getName());
        //查询当前用户任务所在的父容器
        FlowElementsContainer firstTaskOfSubProcessContainer = bpmnModel.getFlowElement(firstTaskOfSubProcess.getTaskDefinitionKey()).getParentContainer();
        log.info("用户任务{}处于{}中", firstTaskOfSubProcess.getName(), firstTaskOfSubProcessContainer instanceof SubProcess ? "子流程" : "主流程");
        //完成子流程第一个任务
        taskService.complete(firstTaskOfSubProcess.getId());
        //查询主流程第一个任务
        Task firstTaskOfMainProcess = taskService.createTaskQuery().singleResult();
        log.info("完成第一个用户任务后，当前流程所在用户任务为：{}", firstTaskOfMainProcess.getName());
        //查询当前用户任务所在的父容器
        FlowElementsContainer firstTaskOfMainProcessContainer = bpmnModel.getFlowElement(firstTaskOfMainProcess.getTaskDefinitionKey()).getParentContainer();
        log.info("用户任务{}处于{}中", firstTaskOfMainProcess.getName(), firstTaskOfMainProcessContainer instanceof SubProcess ? "子流程" : "主流程");
        //完成子流程第一个任务
        taskService.complete(firstTaskOfMainProcess.getId());

        //关闭流程引擎
        closeEngine();
    }
}
