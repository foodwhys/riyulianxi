package com.bpm.example.endevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunErrorEndEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runErrorEndEventProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ErrorEndEventProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询并完成下单服务
        Task orderTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        taskService.complete(orderTask.getId());
        //查询付款任务
        Task payTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //设置payResult变量值
        Map<String, Object> taskArgs = new HashMap<String, Object>();
        taskArgs.put("payResult", false);
        //完成付款任务
        taskService.complete(payTask.getId(), taskArgs);

        //查看到达的任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("当前流程到达的用户任务名称为:{}",task.getName());

        //关闭流程引擎
        closeEngine();
    }
}