package com.bpm.example.startevent.demo;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.junit.Test;

@Slf4j
public class RunTimerSatrtEventProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runTimerSatrtEventProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.job.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/TimerStartEventProcess.bpmn20.xml");

        // 暂停90秒
        Thread.sleep(1000 * 90);

        //查询任务个数
        TaskQuery taskQuery = taskService.createTaskQuery().processDefinitionId(processDefinition.getId());
        log.info("流程实例中任务个数为: {}", taskQuery.count());
        Task task = taskQuery.singleResult();
        log.info("当前任务名称为: {}", task.getName());
        //完成任务
        taskService.complete(task.getId());

        //关闭流程引擎
        closeEngine();
    }
}