package com.bpm.example.demo1.bpmn.behavior;

import com.alibaba.fastjson.JSON;
import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.impl.bpmn.behavior.AbstractBpmnActivityBehavior;
import org.activiti.engine.impl.bpmn.helper.ErrorPropagation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class RestCallTaskActivityBehavior extends AbstractBpmnActivityBehavior {

    private static final long serialVersionUID = 1L;
    //请求类型
    protected Expression requestMethod;
    //请求地址
    protected Expression requestUrl;
    //请求Header
    protected Expression requestHeaders;
    //请求体
    protected Expression requestBody;
    //是否忽略异常
    protected Expression ignoreException;
    //是否保存请求结果
    protected Expression saveResponseParameters;
    //保存请求结果的变量名
    protected Expression responseVariableName;

    @Override
    public void execute(DelegateExecution execution) {
        //获取各属性的值
        String requestMethodStr = getStringFromField(requestMethod, execution);
        String requestUrlStr = getStringFromField(requestUrl, execution);
        String requestHeadersStr = getStringFromField(requestHeaders, execution);
        String requestBodyStr = getStringFromField(requestBody, execution);
        String ignoreExceptionStr = getStringFromField(ignoreException, execution);
        String saveResponseParametersStr = getStringFromField(saveResponseParameters, execution);
        String responseVariableNameStr = getStringFromField(responseVariableName, execution);
        //执行Restful接口调用
        executeGetMethod(execution, requestUrlStr, requestMethodStr,
                (Map) JSON.parse(requestHeadersStr), (Map) JSON.parse(requestBodyStr),
                ignoreExceptionStr, saveResponseParametersStr, responseVariableNameStr);
        //离开当前节点
        leave(execution);
    }

    private void executeGetMethod(DelegateExecution execution, String requestUrl,
                                  String requestMethodStr, Map<String, String> headers, Map<String, String> params,
                                  String ignoreExceptionStr, String saveResponseParametersStr, String responseVariableNameStr) {
        //初始化RestTemplate
        RestTemplate restTemplate = new RestTemplate();
        //组装请求Header
        HttpHeaders restHeaders = new HttpHeaders();
        restHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        restHeaders.setContentType(MediaType.APPLICATION_JSON);
        for (String key : headers.keySet()) {
            restHeaders.add(key, headers.get(key));
        }
        //组装请求体
        Map<String, Object> requestBody = new HashMap<>();
        for (String key : params.keySet()) {
            requestBody.put(key, params.get(key));
        }
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(requestBody, restHeaders);
        try {
            //执行请求调用
            ResponseEntity<String> result = restTemplate.exchange(requestUrl, getHttpMethod(requestMethodStr), httpEntity, String.class);
            //保存执行结果到流程变量中
            if (saveResponseParametersStr.equals("true") && StringUtils.isNotBlank(responseVariableNameStr)) {
                execution.setVariable(responseVariableNameStr, result.getBody());
            }
        } catch (Exception e) {
            //抛出流程异常
            if (!ignoreExceptionStr.equals("true")){
                BpmnError error = new BpmnError("restCallError", e.getMessage());
                ErrorPropagation.propagateError(error, execution);
            }
        }
    }
    //查询表达式的值
    private String getStringFromField(Expression expression, DelegateExecution execution) {
        if (expression != null) {
            Object value = expression.getValue(execution);
            if (value != null) {
                return value.toString();
            }
        }
        return null;
    }
    //获取http请求类型
    private HttpMethod getHttpMethod(String requestMethod) {
        HttpMethod method = null;
        if (requestMethod.equalsIgnoreCase("get")) {
            method = HttpMethod.GET;
        } else if (requestMethod.equalsIgnoreCase("post")) {
            method = HttpMethod.POST;
        } else if (requestMethod.equalsIgnoreCase("put")) {
            method = HttpMethod.PUT;
        } else if (requestMethod.equalsIgnoreCase("delete")) {
            method = HttpMethod.DELETE;
        }
        return method;
    }
}