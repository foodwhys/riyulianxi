package com.bpm.example.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo3.handler.TimeoutReminderJobHandler;
import org.activiti.engine.impl.asyncexecutor.JobManager;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.JobEntity;
import org.activiti.engine.impl.persistence.entity.TimerJobEntity;
import org.activiti.engine.repository.ProcessDefinition;
import org.junit.Test;
import java.util.Date;

public class RunTimeoutReminderJobDemo extends ActivitiEngineUtil {

    @Test
    public void runTimeoutReminderJobDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.job.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/RedisCacheProcess.bpmn20.xml");

        //创建10个流程实例
        for (int i=0; i<10; i++) {
            runtimeService.startProcessInstanceById(processDefinition.getId());
        }

        //自定义命令
        Command customTimerJobCommand = new Command<Void>() {
            @Override
            public Void execute(CommandContext commandContext) {
                //创建时间任务对象
                TimerJobEntity timer = commandContext.getTimerJobEntityManager().create();
                //设置任务类型
                timer.setJobType(JobEntity.JOB_TYPE_TIMER);
                //设置任务处理类
                timer.setJobHandlerType(TimeoutReminderJobHandler.TYPE);
                //设置JobHandler配置
                timer.setJobHandlerConfiguration("{'calendarName':'cycle'}");
                //设置定时任务执行周期
                timer.setRepeat("R/PT2M");
                timer.setRetries(processEngineConfiguration.getAsyncExecutorNumberOfRetries());
                timer.setExclusive(true);

                //时间计算
                Date now = new Date();
                //delay为相较当前时间，延时的时间变量
                Date target = new Date(now.getTime() + 10 * 1000);
                //设置当前定时任务的触发时间
                timer.setDuedate(target);

                //保存并触发定时任务
                JobManager jobManager = commandContext.getJobManager();
                jobManager.scheduleTimerJob(timer);
                return null;
            }
        };
        //执行自定义命令
        managementService.executeCommand(customTimerJobCommand);
        //主线程暂停
        Thread.sleep(1000 * 60 * 10);
    }
}