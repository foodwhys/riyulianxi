package com.bpm.example.demo1;

import com.alibaba.fastjson.JSON;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunRestCallTaskDemo extends ActivitiEngineUtil {

    @Test
    public void runRestCallTaskDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.restcall.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/RestCallTaskProcess.bpmn20.xml");

        //设置流程变量
        Map variables = new HashMap<>();
        variables.put("ip", "114.247.88.20");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables);
        //查询第一个任务
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //办理第一个任务
        taskService.complete(task.getId());

        //查询历史变量
        List<HistoricVariableInstance> historicVariableInstances = historyService.createHistoricVariableInstanceQuery()
                .processInstanceId(processInstance.getProcessInstanceId()).list();
        historicVariableInstances.stream().forEach((historicVariableInstance) -> log.info("流程变量名：{}，变量值：{}", historicVariableInstance.getVariableName(), JSON.toJSONString(historicVariableInstance.getValue())));
    }
}