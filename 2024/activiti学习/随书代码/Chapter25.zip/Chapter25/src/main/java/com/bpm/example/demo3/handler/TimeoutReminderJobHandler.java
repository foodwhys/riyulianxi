package com.bpm.example.demo3.handler;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.jobexecutor.JobHandler;
import org.activiti.engine.impl.jobexecutor.TimerEventHandler;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.JobEntity;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
public class TimeoutReminderJobHandler extends TimerEventHandler implements JobHandler {

    public static final String TYPE = "timeout-reminder";

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public void execute(JobEntity job, String configuration, ExecutionEntity execution, CommandContext commandContext) {
        long taskNum = commandContext.getProcessEngineConfiguration().getTaskService().createTaskQuery().count();
        //获取年月日时分秒毫秒组成的时间戳
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String dataTime = sdf.format(new Date());
        log.info("截至{}，存在{}个未处理工作项！", dataTime, taskNum);
    }
}
