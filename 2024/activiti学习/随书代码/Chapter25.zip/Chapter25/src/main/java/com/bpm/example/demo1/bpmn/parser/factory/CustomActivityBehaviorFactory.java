package com.bpm.example.demo1.bpmn.parser.factory;

import com.bpm.example.demo1.bpmn.behavior.RestCallTaskActivityBehavior;
import org.activiti.bpmn.model.ServiceTask;
import org.activiti.engine.impl.bpmn.helper.ClassDelegate;
import org.activiti.engine.impl.bpmn.parser.FieldDeclaration;
import org.activiti.engine.impl.bpmn.parser.factory.DefaultActivityBehaviorFactory;
import java.util.List;

//自定义流程元素ActivityBehavior工厂
public class CustomActivityBehaviorFactory extends DefaultActivityBehaviorFactory {
    //创建自定义ActivityBehavior
    public RestCallTaskActivityBehavior createHttpActivityBehavior(ServiceTask serviceTask){
        List<FieldDeclaration> fieldDeclarations = super.createFieldDeclarations(serviceTask.getFieldExtensions());
        return (RestCallTaskActivityBehavior) ClassDelegate.defaultInstantiateDelegate(
                RestCallTaskActivityBehavior.class, fieldDeclarations);
    }
}
