package com.bpm.example.demo2;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.junit.Test;

@Slf4j
public class RunRedisProcessDeploymentCacheDemo extends ActivitiEngineUtil {

    @Test
    public void runRedisProcessDeploymentCacheDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.redis.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/RedisCacheProcess.bpmn20.xml");
        //查询流程定义
        ProcessDefinition cacheProcessDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinition.getId()).singleResult();
        log.info("流程定义key为：{}，流程定义编号为：{}", cacheProcessDefinition.getKey(), cacheProcessDefinition.getId());

        //关闭流程引擎
        engine.close();
    }
}