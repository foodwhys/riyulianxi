package com.bpm.example.demo2.cache;
import com.bpm.example.demo2.util.RedisClient;
import lombok.Setter;
import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
import org.activiti.engine.impl.persistence.deploy.ProcessDefinitionCacheEntry;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntityImpl;
import java.util.Objects;

public class RedisProcessDeploymentCache implements DeploymentCache<ProcessDefinitionCacheEntry> {
    //Redis客户端工具
    @Setter
    private RedisClient redisClient;
    //流程定义前缀标识
    @Setter
    private String processDefinitonCacheKeyPrefix;

    /**
     * 查询流程定义缓存
     * @param id 流程定义编号
     * @return 流程定义缓存对象
     */
    @Override
    public ProcessDefinitionCacheEntry get(String id) {
        ProcessDefinitionCacheEntry cacheEntry = null;
        try {
            cacheEntry = (ProcessDefinitionCacheEntry)redisClient.get(processDefinitonCacheKeyPrefix + id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Objects.isNull(cacheEntry)) {
            return null;
        }
        return new ProcessDefinitionCacheEntry(cacheEntry.getProcessDefinition(),
                cacheEntry.getBpmnModel(),
                cacheEntry.getProcess());
    }

    /**
     * 校验redis中是否存在以id为key的流程定义缓存
     * @param id 流程定义编号
     * @return
     */
    @Override
    public boolean contains(String id) {
        return redisClient.hasKey(processDefinitonCacheKeyPrefix + id);
    }

    /**
     * 添加流程定义缓存
     * @param id 流程定义编号
     *@param object 流程定义缓存对象
     * @return
     */
    @Override
    public void add(String id, ProcessDefinitionCacheEntry object) {
        ProcessDefinitionCacheEntry cacheEntry = new ProcessDefinitionCacheEntry(
                (ProcessDefinitionEntityImpl) object.getProcessDefinition(),
                object.getBpmnModel(), object.getProcess());
        try {
            redisClient.set(processDefinitonCacheKeyPrefix + id, cacheEntry);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除流程定义缓存
     * @param id 流程定义编号
     */
    @Override
    public void remove(String id) {
        redisClient.del(processDefinitonCacheKeyPrefix + id);
    }

    /**
     * 清除所有流程定义缓存
     */
    @Override
    public void clear() {
        redisClient.del((String[])redisClient.keys(processDefinitonCacheKeyPrefix + "*").toArray(new String[]{}));
    }
}