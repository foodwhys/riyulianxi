package com.bpm.example.demo1.validation.validator;

import org.activiti.bpmn.model.FieldExtension;
import org.activiti.bpmn.model.Process;
import org.activiti.bpmn.model.ServiceTask;
import org.activiti.bpmn.model.TaskWithFieldExtensions;
import org.activiti.validation.ValidationError;
import org.activiti.validation.validator.impl.ServiceTaskValidator;
import org.apache.commons.lang3.StringUtils;
import java.util.List;

public class CustomServiceTaskValidator extends ServiceTaskValidator {
    //校验服务任务
    @Override
    protected void verifyType(Process process, ServiceTask serviceTask, List<ValidationError> errors) {
        if (StringUtils.isNotEmpty(serviceTask.getType())) {
            if (serviceTask.getType().equalsIgnoreCase("rest")) {
                validateFieldDeclarationsForRest(process, serviceTask, serviceTask.getFieldExtensions(), errors);
            } else {
                super.verifyType(process, serviceTask, errors);
            }
        }
    }
    //校验rest类型的服务任务
    private void validateFieldDeclarationsForRest(org.activiti.bpmn.model.Process process, TaskWithFieldExtensions task, List<FieldExtension> fieldExtensions, List<ValidationError> errors) {
        boolean requestMethodDefined = false;
        boolean requestUrlDefined = false;

        for (FieldExtension fieldExtension : fieldExtensions) {
            if (fieldExtension.getFieldName().equals("requestMethod")) {
                requestMethodDefined = true;
            }
            if (fieldExtension.getFieldName().equals("requestUrl")) {
                requestUrlDefined = true;
            }
        }
        if (!requestMethodDefined) {
            addError(errors, "activiti-restcall-no-requestmethod", process, task, "RestCall节点没有配置requestMethod属性");
        }
        if (!requestUrlDefined) {
            addError(errors, "activiti-restcall-no-requesturl", process, task, "RestCall节点没有配置requestUrl属性");
        }
    }
}
