package com.bpm.example.demo1;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo1.dynamic.DynamicProcessCreateUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.EndEvent;
import org.activiti.bpmn.model.ExclusiveGateway;
import org.activiti.bpmn.model.StartEvent;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunDynamicProcessCreateDemo extends ActivitiEngineUtil {

    @Test
    public void runDynamicProcessCreateDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //初始化流程创建工具类
        DynamicProcessCreateUtil dynamicProcessCreateUtil = new DynamicProcessCreateUtil(repositoryService);
        //创建流程
        dynamicProcessCreateUtil.createProcess("loanProcess","借款流程");
        //创建开始节点
        StartEvent startEvent = dynamicProcessCreateUtil.createStartEvent("startEvent1", "开始节点");
        //创建"借款申请"用户任务
        UserTask userTask1 = dynamicProcessCreateUtil.createUserTask("userTask1", "借款申请", "employee");
        //创建开始节点到"借款申请"用户任务的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(startEvent.getId(), userTask1.getId());
        //创建分支网关
        ExclusiveGateway exclusiveGateway = dynamicProcessCreateUtil.createExclusiveGateway("exclusiveGateway1", "排他网关");
        //创建"借款申请"用户任务到分支网关的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(userTask1.getId(), exclusiveGateway.getId());
        //创建"直属上级审批"用户任务
        UserTask userTask2 = dynamicProcessCreateUtil.createUserTask("userTask2", "直属上级审批", "leader");
        //创建分支网关到"直属上级审批"用户任务的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(exclusiveGateway.getId(), userTask2.getId(),"${money<5000}");
        //创建"部门经理审批"用户任务
        UserTask userTask3 = dynamicProcessCreateUtil.createUserTask("userTask3", "部门经理审批", "manager");
        //创建分支网关到"部门经理审批"用户任务的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(exclusiveGateway.getId(), userTask3.getId(),"${money>=5000}");
        //创建结束任务
        EndEvent endEvent = dynamicProcessCreateUtil.createEndEvent("endEvent1", "结束任务");
        //创建"直属上级审批"用户任务到结束任务的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(userTask2.getId(), endEvent.getId());
        //创建"部门经理审批"用户任务到结束任务的顺序流
        dynamicProcessCreateUtil.createSequenceFlow(userTask3.getId(), endEvent.getId());
        //流程自动布局
        dynamicProcessCreateUtil.autoLayout();
        //部署流程
        ProcessDefinition processDefinition = dynamicProcessCreateUtil.deployProcess();
        //导出流程图
        dynamicProcessCreateUtil.exportProcessDiagram(processDefinition.getId());
        //导出流程BPMN 2.0 XML文件
        dynamicProcessCreateUtil.exportProcessDefinitionXml(processDefinition.getId());

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //设置流程变量
        Map variables = new HashMap<>();
        variables.put("money", 1000);
        //完成第一个任务
        taskService.complete(firstTask.getId(), variables);
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("第二个节点任务名称为：{}", secondTask.getName());
        //完成第二个任务
        taskService.complete(secondTask.getId());

        //关闭流程引擎
        engine.close();
    }
}
