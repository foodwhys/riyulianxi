package com.bpm.example.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo4.service.AddMultiInstanceUserTaskService;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunAddMultiInstanceUserTaskDemo extends ActivitiEngineUtil {

    @Test
    public void runAddMultiInstanceUserTaskDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/MultiInstanceUserTaskProcess.bpmn20.xml");

        //设置流程变量
        List<String> assigneeList = new ArrayList();
        assigneeList.add("huhaiqin");
        assigneeList.add("wangjunlin");
        Map variables = new HashMap();
        variables.put("assigneeList", assigneeList);
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables);
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成第一个任务
        taskService.complete(firstTask.getId());
        log.info("用户任务{}办理完成", firstTask.getName());

        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list().get(0);
        log.info("第二个任务taskId：{}，节点名称：{}，办理人：{}", secondTask.getId(), secondTask.getName(), secondTask.getAssignee());
        //执行加签操作
        AddMultiInstanceUserTaskService multiInstanceUserTaskService = new AddMultiInstanceUserTaskService(managementService);
        multiInstanceUserTaskService.addMultiInstanceUserTask(secondTask.getId(), "liuxiaopeng");
        //完成第二个任务
        taskService.complete(secondTask.getId());
        log.info("用户任务{}办理完成，办理人：{}", secondTask.getName(), secondTask.getAssignee());

        while (taskService.createTaskQuery().processInstanceId(processInstance.getId()).count() > 0) {
            List<Task> tasks = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
            for (Task task : tasks) {
                taskService.complete(task.getId());
                log.info("用户任务{}办理完成，办理人：{}", task.getName(), task.getAssignee());
            }
        }

        //关闭流程引擎
        engine.close();
    }
}
