package com.bpm.example.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunTaskSkipDemo extends ActivitiEngineUtil {

    @Test
    public void runTaskSkipDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/AutoSkipProcess.bpmn20.xml");

        //设置流程变量
        Map variables = new HashMap();
        variables.put("_ACTIVITI_SKIP_EXPRESSION_ENABLED", true);
        variables.put("employee", "liuxiaopeng");
        variables.put("leader", "hebo");
        variables.put("manager", "hebo");
        variables.put("hr", "huhaiqin");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables);
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成第一个任务
        taskService.complete(firstTask.getId());
        log.info("用户任务{}办理完成。", firstTask.getName());
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成第二个任务
        taskService.complete(secondTask.getId());
        log.info("用户任务{}办理完成。", secondTask.getName());
        //查询第三个任务
        Task thirdTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("当前流程所处节点名称为：{}，节点key为：{}", thirdTask.getName(), thirdTask.getTaskDefinitionKey());

        //关闭流程引擎
        engine.close();
    }
}
