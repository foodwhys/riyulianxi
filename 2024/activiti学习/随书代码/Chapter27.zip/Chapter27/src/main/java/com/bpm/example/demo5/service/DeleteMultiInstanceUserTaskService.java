package com.bpm.example.demo5.service;

import com.bpm.example.demo5.cmd.DeleteMultiInstanceUserTaskCmd;
import lombok.AllArgsConstructor;
import org.activiti.engine.ManagementService;

@AllArgsConstructor
public class DeleteMultiInstanceUserTaskService {

    protected ManagementService managementService;

    /**
     * 会签减签
     * @param taskId      当前操作taskId
     * @param assignee    待减签用户
     */
    public void deleteMultiInstanceUserTask(String taskId, String assignee) {
        //实例化自定义跳转Command类
        DeleteMultiInstanceUserTaskCmd deleteMultiInstanceUserTaskCmd = new DeleteMultiInstanceUserTaskCmd(taskId, assignee);
        //执行减签操作
        this.managementService.executeCommand(deleteMultiInstanceUserTaskCmd);
    }
}
