package com.bpm.example.demo5.cmd;

import org.activiti.bpmn.model.Activity;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.MultiInstanceLoopCharacteristics;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.impl.bpmn.behavior.ParallelMultiInstanceBehavior;
import org.activiti.engine.impl.bpmn.behavior.SequentialMultiInstanceBehavior;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.impl.persistence.entity.TaskEntityManager;
import org.activiti.engine.impl.util.ProcessDefinitionUtil;
import java.io.Serializable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeleteMultiInstanceUserTaskCmd implements Command, Serializable {

    //多实例总数
    protected static final String NUMBER_OF_INSTANCES = "nrOfInstances";
    //当前活动的实例数，即尚未完成的实例数。对于串行多实 例，这个值总是1。
    protected static final String NUMBER_OF_ACTIVE_INSTANCES = "nrOfActiveInstances";

    private String taskId;
    private String assignee;

    public DeleteMultiInstanceUserTaskCmd(String taskId, String assignee) {
        this.taskId = taskId;
        this.assignee = assignee;
    }

    public Void execute(CommandContext commandContext) {
        TaskEntityManager taskEntityManager = commandContext.getTaskEntityManager();
        //查询当前任务实例
        TaskEntity taskEntity = taskEntityManager.findById(this.taskId);
        if (taskEntity == null) {
            throw new ActivitiException("id为" + this.taskId + "的任务不存在");
        }
        ExecutionEntityManager executionEntityManager = commandContext.getExecutionEntityManager();
        //查询当前任务实例所对应的执行实例
        ExecutionEntity executionEntity = executionEntityManager.findById(taskEntity.getExecutionId());
        //查询多实例的根执行实例
        ExecutionEntity miExecution = executionEntityManager.findFirstMultiInstanceRoot(executionEntity);
        if (miExecution == null) {
            throw new ActivitiException("节点 " + taskEntity.getTaskDefinitionKey() + "不是多实例任务");
        }

        BpmnModel bpmnModel = ProcessDefinitionUtil.getBpmnModel(executionEntity.getProcessDefinitionId());
        Activity miActivityElement = (Activity) bpmnModel.getFlowElement(executionEntity.getActivityId());
        MultiInstanceLoopCharacteristics multiInstanceLoopCharacteristics = miActivityElement.getLoopCharacteristics();
        //解析多实例activiti:collection配置的表达式中的变量
        String collectionKey = getCollectionKey(multiInstanceLoopCharacteristics);
        //查询多实例activiti:collection配置的表达式中的变量的值
        List<String> collectionValue =  (List)miExecution.getVariable(collectionKey);
        if (!collectionValue.contains(assignee)) {
            throw new ActivitiException("减签用户 " + assignee + "不在审批名单中");
        }

        boolean canDelete = false;
        int currentLoopCounter = getCurrentLoopCounter(commandContext, taskEntity, miActivityElement, multiInstanceLoopCharacteristics.isSequential());
        if (multiInstanceLoopCharacteristics.isSequential()) {
            for (int i = currentLoopCounter; i < collectionValue.size(); i++) {
                if (collectionValue.get(i).equals(assignee)) {
                    canDelete = true;
                    break;
                }
            }
        } else {
            List<ExecutionEntity> childExecutions = executionEntityManager.findChildExecutionsByParentExecutionId(miExecution.getId());
            for (ExecutionEntity childExecution : childExecutions) {
                if (this.assignee.equals(childExecution.getVariableLocal(multiInstanceLoopCharacteristics.getElementVariable()))) {
                    //删除执行实例及相关数据
                    executionEntityManager.deleteChildExecutions(childExecution, "Delete MI execution", false);
                    executionEntityManager.deleteExecutionAndRelatedData(childExecution, "Delete MI execution", false);

                    //更新nrOfActiveInstances变量
                    Integer nrOfActiveInstances = (Integer) miExecution.getVariable(NUMBER_OF_ACTIVE_INSTANCES);
                    miExecution.setVariableLocal(NUMBER_OF_ACTIVE_INSTANCES, nrOfActiveInstances - 1);

                    canDelete = true;
                    break;
                }
            }
        }
        if (canDelete) {
            Integer currentNumberOfInstances = (Integer) miExecution.getVariable(NUMBER_OF_INSTANCES);
            miExecution.setVariableLocal(NUMBER_OF_INSTANCES, currentNumberOfInstances - 1);

            //从变量中移除减签用户
            collectionValue.remove(assignee);
            miExecution.setVariable(collectionKey, collectionValue);
        }
        return null;
    }

    //查询当前任务的LoopCounter值
    private int getCurrentLoopCounter(CommandContext commandContext, TaskEntity taskEntity, Activity miActivityElement, boolean isSequential) {
        String collectionElementIndexVariable = null;
        if (isSequential) {
            SequentialMultiInstanceBehavior miBehavior = (SequentialMultiInstanceBehavior) miActivityElement.getBehavior();
            collectionElementIndexVariable = miBehavior.getCollectionElementIndexVariable();
        } else {
            ParallelMultiInstanceBehavior miBehavior = (ParallelMultiInstanceBehavior) miActivityElement.getBehavior();
            collectionElementIndexVariable = miBehavior.getCollectionElementIndexVariable();
        }
        ExecutionEntityManager executionEntityManager = commandContext.getExecutionEntityManager();
        ExecutionEntity executionEntity = executionEntityManager.findById(taskEntity.getExecutionId());
        int loopCounter = (int) executionEntity.getVariableLocal(collectionElementIndexVariable);
        return loopCounter;
    }

    //解析出多实例activiti:collection配置的表达式中的变量
    protected String getCollectionKey(MultiInstanceLoopCharacteristics multiInstanceLoopCharacteristics) {
        String collectionKey = multiInstanceLoopCharacteristics.getInputDataItem();
        String regex = "\\$\\{(.*?)\\}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(collectionKey);
        if (matcher.find()) {
            collectionKey = matcher.group(1);
        }
        return collectionKey;
    }
}
