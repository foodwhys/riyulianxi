package com.bpm.example.demo2;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo2.service.InjectUserTaskInProcessInstanceService;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import java.io.File;
import java.io.InputStream;
import java.util.List;

@Slf4j
public class RunInjectUserTaskInProcessInstanceDemo extends ActivitiEngineUtil {

    @Test
    public void runInjectUserTaskInProcessInstanceDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/InjectUserTaskProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成第一个任务
        taskService.complete(firstTask.getId());
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("当前流程的流程定义id为：{}", processInstance.getProcessDefinitionId());

        BpmnModel bpmnModel = repositoryService.getBpmnModel(processInstance.getProcessDefinitionId());
        log.info("当前流程的用户任务数为：{}", bpmnModel.getMainProcess().findFlowElementsOfType(UserTask.class).size());

        exportProcessDiagram(repositoryService, processInstance.getProcessDefinitionId(), "加节点前图片");

        long num1 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).count();
        System.out.println("num1:" + num1);

        InjectUserTaskInProcessInstanceService injectUserTaskInProcessInstanceService = new InjectUserTaskInProcessInstanceService(managementService);
        injectUserTaskInProcessInstanceService.executeInjectUserTaskInProcessInstance(secondTask.getId(),"userTask4","部门经理审批","zhangsan");

        processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("加节点后流程的流程定义id为：{}", processInstance.getProcessDefinitionId());
        bpmnModel = repositoryService.getBpmnModel(processInstance.getProcessDefinitionId());
        log.info("加节点后流程的用户任务数为：{}", bpmnModel.getMainProcess().findFlowElementsOfType(UserTask.class).size());

        long num2 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).count();
        System.out.println("num2:" + num2);

        exportProcessDiagram(repositoryService, processInstance.getProcessDefinitionId(), "加节点后图片");
        exportProcessDefinitionXml(repositoryService, processInstance.getProcessDefinitionId());

        while (taskService.createTaskQuery().processInstanceId(processInstance.getId()).count() > 0) {
            List<Task> tasks = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
            for (Task task : tasks) {
                log.info("当前流程所处节点名称为：{}，节点key为：{}", task.getName(), task.getTaskDefinitionKey());
                taskService.complete(task.getId());
            }
        }

        long num3 = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).count();
        System.out.println("num3:" + num3);

        //关闭流程引擎
        engine.close();
    }

    //导出流程图片
    static private void exportProcessDiagram(RepositoryService repositoryService, String processDefinitionId, String photoName) throws Exception {
        InputStream processDiagram = repositoryService.getProcessDiagram(processDefinitionId);
        FileUtils.copyInputStreamToFile(processDiagram, new File(
                "d://" + photoName + ".png"));
    }

    //导出流程
    static private void exportProcessDefinitionXml(RepositoryService repositoryService, String processDefinitionId) throws Exception{
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId).singleResult();
        InputStream processBpmn = repositoryService
                .getProcessModel(processDefinitionId);
        FileUtils.copyInputStreamToFile(processBpmn, new File(
                "d://" + processDefinition.getKey() + ".bpmn20.xml"));
    }
}
