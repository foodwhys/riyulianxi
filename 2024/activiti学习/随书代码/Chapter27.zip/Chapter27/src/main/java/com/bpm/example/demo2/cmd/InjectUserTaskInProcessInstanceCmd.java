package com.bpm.example.demo2.cmd;

import com.bpm.example.demo2.builder.DynamicUserTaskBuilder;
import com.bpm.example.demo2.dynamic.BaseDynamicSubProcessInjectUtil;
import lombok.AllArgsConstructor;
import org.activiti.bpmn.BpmnAutoLayout;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.bpmn.model.FlowNode;
import org.activiti.bpmn.model.Process;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.task.Task;
import java.util.List;

@AllArgsConstructor
public class InjectUserTaskInProcessInstanceCmd extends AbstractDynamicInjectionCmd implements Command<Void> {

    protected String taskId;
    protected DynamicUserTaskBuilder dynamicUserTaskBuilder;

    @Override
    public Void execute(CommandContext commandContext) {
        Task task = commandContext.getTaskEntityManager().findById(taskId);
        createDerivedProcessDefinitionForProcessInstance(commandContext, task.getProcessInstanceId(), task.getTaskDefinitionKey());
        return null;
    }

    @Override
    protected void updateBpmnProcess(CommandContext commandContext, Process process, FlowElement currentFlowElement,
                                     BpmnModel bpmnModel, ProcessDefinitionEntity originalProcessDefinitionEntity, DeploymentEntity newDeploymentEntity) {
        //新建节点
        UserTask userTask = new UserTask();
        if (dynamicUserTaskBuilder.getId() != null) {
            userTask.setId(dynamicUserTaskBuilder.getId());
        } else {
            userTask.setId(dynamicUserTaskBuilder.nextTaskId(process.getFlowElementMap()));
        }
        dynamicUserTaskBuilder.setDynamicTaskId(userTask.getId());

        userTask.setName(dynamicUserTaskBuilder.getName());
        userTask.setAssignee(dynamicUserTaskBuilder.getAssignee());
        process.addFlowElement(userTask);

        //找到当前节点的出口
        List<SequenceFlow> outgoingFlows = ((FlowNode)currentFlowElement).getOutgoingFlows();
        //设置新增节点的出口
        for (SequenceFlow outgoingFlow : outgoingFlows) {
            process.removeFlowElement(outgoingFlow.getId());
            outgoingFlow.setSourceRef(userTask.getId());
            process.addFlowElement(outgoingFlow);
        }

        //创建当前节点与新建节点的连线
        SequenceFlow flowToUserTask = new SequenceFlow(currentFlowElement.getId(), userTask.getId());
        flowToUserTask.setId(dynamicUserTaskBuilder.nextFlowId(process.getFlowElementMap()));
        process.addFlowElement(flowToUserTask);

        //自动布局
        new BpmnAutoLayout(bpmnModel).execute();

        BaseDynamicSubProcessInjectUtil.processFlowElements(commandContext, process, bpmnModel, originalProcessDefinitionEntity, newDeploymentEntity);
    }
}
