package com.bpm.example.demo1.dynamic;

import org.activiti.bpmn.BpmnAutoLayout;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.EndEvent;
import org.activiti.bpmn.model.ExclusiveGateway;
import org.activiti.bpmn.model.Process;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.bpmn.model.StartEvent;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.InputStream;

public class DynamicProcessCreateUtil {

    private BpmnModel model;
    private Process process;
    private RepositoryService repositoryService;

    public DynamicProcessCreateUtil(RepositoryService repositoryService) {
        this.repositoryService = repositoryService;
        this.model = new BpmnModel();
        this.process = new Process();
    }

    /**
     * 创建流程
     * @param processKey  流程key
     * @param processName 流程名称
     */
    public void createProcess(String processKey, String processName) {
        this.model.addProcess(process);
        this.process.setId(processKey);
        this.process.setName(processName);
    }

    /**
     * 创建开始节点
     * @param id     节点编号
     * @param name   节点名称
     * @return
     */
    public StartEvent createStartEvent(String id, String name) {
        StartEvent startEvent = new StartEvent();
        startEvent.setId(id);
        startEvent.setName(name);
        this.process.addFlowElement(startEvent);
        return startEvent;
    }

    /**
     * 创建结束节点
     * @param id     节点编号
     * @param name   节点名称
     * @return
     */
    public EndEvent createEndEvent(String id, String name) {
        EndEvent endEvent = new EndEvent();
        endEvent.setId(id);
        endEvent.setName(name);
        this.process.addFlowElement(endEvent);
        return endEvent;
    }

    /**
     * 创建用户任务
     * @param id         节点编号
     * @param name       节点名称
     * @param assignee   办理人
     * @return
     */
    public UserTask createUserTask(String id, String name, String assignee) {
        UserTask userTask = new UserTask();
        userTask.setName(name);
        userTask.setId(id);
        userTask.setAssignee(assignee);
        this.process.addFlowElement(userTask);
        return userTask;
    }

    /**
     * 创建排它网关
     * @param id    节点编号
     * @param name  节点名称
     * @return
     */
    public ExclusiveGateway createExclusiveGateway(String id, String name) {
        ExclusiveGateway exclusiveGateway = new ExclusiveGateway();
        exclusiveGateway.setId(id);
        exclusiveGateway.setName(name);
        this.process.addFlowElement(exclusiveGateway);
        return exclusiveGateway;
    }

    /**
     * 创建顺序流
     * @param from  起始节点编号
     * @param to    目标节点编号
     * @return
     */
    public SequenceFlow createSequenceFlow(String from, String to) {
        SequenceFlow flow = new SequenceFlow();
        flow.setSourceRef(from);
        flow.setTargetRef(to);
        this.process.addFlowElement(flow);
        return flow;
    }

    /**
     * 创建带条件的顺序流
     * @param from                    起始节点编号
     * @param to                      目标节点编号
     * @param conditionExpression   条件
     * @return
     */
    public SequenceFlow createSequenceFlow(String from, String to, String conditionExpression) {
        SequenceFlow flow = new SequenceFlow();
        flow.setSourceRef(from);
        flow.setTargetRef(to);
        flow.setConditionExpression(conditionExpression);
        this.process.addFlowElement(flow);
        return flow;
    }

    /**
     * 生成BPMN自动布局
     */
    public void autoLayout() {
        new BpmnAutoLayout(model).execute();
    }

    /**
     * 部署流程
     * @return
     */
    public ProcessDefinition deployProcess() {
        Deployment deployment = repositoryService.createDeployment()
                .addBpmnModel(process.getId() + ".bpmn", model)
                .name(process.getName()).deploy();
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .deploymentId(deployment.getId()).singleResult();
        return processDefinition;
    }

    /**
     * 导出流程
     * @param processDefinitionId  流程定义编号
     * @throws Exception
     */
    public void exportProcessDefinitionXml(String processDefinitionId) throws Exception{
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId).singleResult();
        InputStream processBpmn = repositoryService.getProcessModel(processDefinition.getId());
        FileUtils.copyInputStreamToFile(processBpmn, new File(
                "d://" + processDefinition.getKey() + ".bpmn20.xml"));
    }

    /**
     * 导出流程图片
     * @param processDefinitionId  流程定义编号
     * @throws Exception
     */
    public void exportProcessDiagram(String processDefinitionId) throws Exception {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId).singleResult();
        InputStream processDiagram = repositoryService.getProcessDiagram(processDefinitionId);
        FileUtils.copyInputStreamToFile(processDiagram, new File(
                "d://" + processDefinition.getKey() + ".png"));
    }
}