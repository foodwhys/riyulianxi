package com.bpm.example.demo2.service;

import com.bpm.example.demo2.builder.DynamicUserTaskBuilder;
import com.bpm.example.demo2.cmd.InjectUserTaskInProcessInstanceCmd;
import lombok.AllArgsConstructor;
import org.activiti.engine.ManagementService;

@AllArgsConstructor
public class InjectUserTaskInProcessInstanceService {

    protected ManagementService managementService;

    public void executeInjectUserTaskInProcessInstance(String currentTaskId, String newTaskKey, String newTaskName, String newTaskAssignee) {
        DynamicUserTaskBuilder dynamicUserTaskBuilder = new DynamicUserTaskBuilder();
        dynamicUserTaskBuilder.setId(newTaskKey);
        dynamicUserTaskBuilder.setName(newTaskName);
        dynamicUserTaskBuilder.setAssignee(newTaskAssignee);
        //Command类
        InjectUserTaskInProcessInstanceCmd injectUserTaskInProcessInstanceCmd = new InjectUserTaskInProcessInstanceCmd(currentTaskId, dynamicUserTaskBuilder);
        //通过ManagementService管理服务执行撤回Command类
        managementService.executeCommand(injectUserTaskInProcessInstanceCmd);
    }

}
