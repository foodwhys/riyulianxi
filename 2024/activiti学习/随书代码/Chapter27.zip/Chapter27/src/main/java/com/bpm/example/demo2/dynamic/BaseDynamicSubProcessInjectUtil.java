package com.bpm.example.demo2.dynamic;

import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.bpmn.model.FlowElementsContainer;
import org.activiti.bpmn.model.SubProcess;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.DeploymentEntity;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.persistence.entity.ResourceEntity;
import org.activiti.engine.impl.persistence.entity.ResourceEntityManager;
import org.activiti.engine.impl.util.IoUtil;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.form.api.FormDeployment;
import org.activiti.form.api.FormRepositoryService;
import org.activiti.form.model.FormDefinition;
import org.apache.commons.lang3.StringUtils;

import java.io.InputStream;
import java.util.List;

public class BaseDynamicSubProcessInjectUtil {
    public static void processFlowElements(CommandContext commandContext, FlowElementsContainer process, BpmnModel bpmnModel, ProcessDefinitionEntity originalProcessDefinitionEntity, DeploymentEntity newDeploymentEntity) {
        for (FlowElement flowElement : process.getFlowElements()) {
            processUserTask(flowElement, originalProcessDefinitionEntity, newDeploymentEntity, commandContext);
            if ((flowElement instanceof SubProcess)) {
                processFlowElements(commandContext, (SubProcess)flowElement, bpmnModel, originalProcessDefinitionEntity, newDeploymentEntity);
            }
        }
    }

    protected static void processUserTask(FlowElement flowElement, ProcessDefinition originalProcessDefinitionEntity, DeploymentEntity newDeploymentEntity, CommandContext commandContext) {
        if ((flowElement instanceof UserTask)) {
            FormRepositoryService formRepositoryService = commandContext.getProcessEngineConfiguration().getFormEngineRepositoryService();
            if (formRepositoryService != null) {
                UserTask userTask = (UserTask)flowElement;
                if (StringUtils.isNotEmpty(userTask.getFormKey())) {
                    Deployment deployment = (Deployment)commandContext.getDeploymentEntityManager().findById(originalProcessDefinitionEntity.getDeploymentId());
                    List<FormDeployment> formDeployments = formRepositoryService.createDeploymentQuery().parentDeploymentId(deployment.getId()).list();
                    if ((formDeployments != null) && (formDeployments.size() > 0)) {
                        FormDefinition formDefinition = (FormDefinition)formRepositoryService.createDeploymentQuery().formDefinitionKey(userTask.getFormKey()).deploymentId(((FormDeployment)formDeployments.get(0)).getId()).singleResult();
                        if (formDefinition != null) {
                            String name = formDefinition.getName();
                            InputStream inputStream = formRepositoryService.getFormResource(formDefinition.getId());
                            addResource(commandContext, newDeploymentEntity, name, IoUtil.readInputStream(inputStream, name));
                            IoUtil.closeSilently(inputStream);
                        }
                    }
                }
            }
        }
    }

    public static void addResource(CommandContext commandContext, DeploymentEntity deploymentEntity, String resourceName, byte[] bytes) {
        if (!deploymentEntity.getResources().containsKey(resourceName)) {
            ResourceEntityManager resourceEntityManager = commandContext.getResourceEntityManager();
            ResourceEntity resourceEntity = (ResourceEntity)resourceEntityManager.create();
            resourceEntity.setDeploymentId(deploymentEntity.getId());
            resourceEntity.setName(resourceName);
            resourceEntity.setBytes(bytes);
            resourceEntityManager.insert(resourceEntity);
            deploymentEntity.addResource(resourceEntity);
        }
    }
}
