package com.bpm.example.demo1.cmd;

import lombok.AllArgsConstructor;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.ActivitiIllegalArgumentException;
import org.activiti.engine.impl.context.Context;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
import org.activiti.engine.impl.util.ProcessDefinitionUtil;
import java.util.List;

@AllArgsConstructor
public class DynamicJumpCmd implements Command<Void> {
    //流程实例编号
    protected String processInstanceId;
    //跳转起始节点
    protected String fromActivityId;
    //跳转目标节点
    protected String toActivityId;

    public Void execute(CommandContext commandContext) {
        //processInstanceId参数不能为空
        if (this.processInstanceId == null) {
            throw new ActivitiIllegalArgumentException("Process instance id is required");
        }
        //获取执行实例管理类
        ExecutionEntityManager executionEntityManager = commandContext.getExecutionEntityManager();
        //获取执行实例
        ExecutionEntity execution = (ExecutionEntity)executionEntityManager.findById(this.processInstanceId);
        if (execution == null) {
            throw new ActivitiException("Execution could not be found with id " + this.processInstanceId);
        }
        if (!execution.isProcessInstanceType()) {
            throw new ActivitiException("Execution is not a process instance type execution for id " + this.processInstanceId);
        }
        ExecutionEntity activeExecutionEntity = null;
        //获取所有子执行实例
        List<ExecutionEntity> childExecutions = executionEntityManager.findChildExecutionsByProcessInstanceId(execution.getId());
        for (ExecutionEntity childExecution : childExecutions) {
            if (childExecution.getCurrentActivityId().equals(this.fromActivityId)) {
                activeExecutionEntity = childExecution;
            }
        }
        if (activeExecutionEntity == null) {
            throw new ActivitiException("Active execution could not be found with activity id " + this.fromActivityId);
        }
        //获取流程模型
        BpmnModel bpmnModel = ProcessDefinitionUtil.getBpmnModel(execution.getProcessDefinitionId());
        //获取当前节点
        FlowElement fromActivityElement = bpmnModel.getFlowElement(this.fromActivityId);
        //获取目标节点
        FlowElement toActivityElement = bpmnModel.getFlowElement(this.toActivityId);
        //校验id为fromActivityId的节点是否存在
        if (fromActivityElement == null) {
            throw new ActivitiException("Activity could not be found in process definition for id " + this.fromActivityId);
        }
        //校验id为toActivityId的节点是否存在
        if (toActivityElement == null) {
            throw new ActivitiException("Activity could not be found in process definition for id " + this.toActivityId);
        }
        boolean deleteParentExecution = false;
        ExecutionEntity parentExecution = activeExecutionEntity.getParent();
        //兼容子流程节点的场景
        if ((fromActivityElement.getSubProcess() != null) && (
                (toActivityElement.getSubProcess() == null) ||
                        (!toActivityElement.getSubProcess().getId().equals(parentExecution.getActivityId())))) {
            deleteParentExecution = true;
        }
        //删除当前节点所在的执行实例及相关数据
        executionEntityManager.deleteExecutionAndRelatedData(activeExecutionEntity, "Change activity to " + this.toActivityId, false);
        //如果是子流程节点，删除其所在的执行实例及相关数据
        if (deleteParentExecution) {
            executionEntityManager.deleteExecutionAndRelatedData(parentExecution, "Change activity to " + this.toActivityId, false);
        }
        //创建当前流程实例的子执行实例
        ExecutionEntity newChildExecution = executionEntityManager.createChildExecution(execution);
        //设置执行实例的当前活动节点为目标节点
        newChildExecution.setCurrentFlowElement(toActivityElement);
        //向operations中压入继续流程的操作类
        Context.getAgenda().planContinueProcessOperation(newChildExecution);

        return null;
    }
}