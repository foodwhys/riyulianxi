package com.bpm.example.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo3.service.RevokeProcessInstanceService;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class RunRevokeProcessInstanceDemo extends ActivitiEngineUtil {

    @Test
    public void runRevokeProcessInstanceDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.revoke.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/RevokeProcessInstanceProcess.bpmn20.xml");

        //设置流程发起人
        Authentication.setAuthenticatedUserId("huhaiqin");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询特殊借款申请用户任务的task
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成特殊借款申请用户任务的task
        taskService.complete(firstTask.getId());

        List<Task> taskList1 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
        String taskNames1 = taskList1.stream().map(Task::getName).collect(Collectors.joining(","));
        log.info("用户任务：{}提交后，当前流程所处节点：{}", firstTask.getName(), taskNames1);
        taskList1.stream().forEach(task -> {
            log.info("完成用户任务：{}", task.getName());
            taskService.complete(task.getId());
        });
        List<Task> taskList2 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
        String taskNames2 = taskList2.stream().map(Task::getName).collect(Collectors.joining(","));
        log.info("流程撤销前，流程实例编号为：{}，当前流程所处节点：{}", processInstance.getProcessInstanceId(), taskNames2);

        //执行流程撤销操作
        RevokeProcessInstanceService revokeProcessService = new RevokeProcessInstanceService(runtimeService, historyService, managementService);
        ProcessInstance newProcessInstance = revokeProcessService.revokeProcess(processInstance.getProcessInstanceId());

        List<Task> taskList3 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
        String taskNames3 = taskList3.stream().map(Task::getName).collect(Collectors.joining(","));
        log.info("流程撤销后，新创建流程实例编号为：{}，当前流程所处节点：{}", newProcessInstance.getProcessInstanceId(), taskNames3);

        //关闭流程引擎
        engine.close();
    }
}