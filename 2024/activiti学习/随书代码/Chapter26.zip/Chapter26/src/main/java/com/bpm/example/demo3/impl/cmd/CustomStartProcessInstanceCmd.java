package com.bpm.example.demo3.impl.cmd;

import com.bpm.example.demo3.impl.util.CustomProcessInstanceHelper;
import org.activiti.engine.ActivitiIllegalArgumentException;
import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.impl.cmd.StartProcessInstanceCmd;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.deploy.DeploymentManager;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.apache.commons.lang3.StringUtils;
import java.util.Map;

public class CustomStartProcessInstanceCmd<T> extends StartProcessInstanceCmd<T> {

    //流程实例编号
    protected String processInstanceId;

    public CustomStartProcessInstanceCmd(String processDefinitionKey, String processDefinitionId, String processInstanceId, String businessKey, Map variables, String tenantId) {
        super(processDefinitionKey, processDefinitionId, businessKey, variables, tenantId);
        this.processInstanceId = processInstanceId;
    }

    @Override
    public ProcessInstance execute(CommandContext commandContext) {
        DeploymentManager deploymentCache = commandContext.getProcessEngineConfiguration().getDeploymentManager();
        //查询流程定义
        ProcessDefinition processDefinition = null;
        if (processDefinitionId != null) {
            processDefinition = deploymentCache.findDeployedProcessDefinitionById(processDefinitionId);
            if (processDefinition == null) {
                throw new ActivitiObjectNotFoundException("编号为" + processDefinitionId + "的流程定义不存在。", ProcessDefinition.class);
            }
        } else if (processDefinitionKey != null && (tenantId == null || ProcessEngineConfiguration.NO_TENANT_ID.equals(tenantId))) {
            processDefinition = deploymentCache.findDeployedLatestProcessDefinitionByKey(processDefinitionKey);
            if (processDefinition == null) {
                throw new ActivitiObjectNotFoundException("流程定义key为" + processDefinitionKey + "的流程定义不存在。", ProcessDefinition.class);
            }
        } else if (processDefinitionKey != null && tenantId != null && !ProcessEngineConfiguration.NO_TENANT_ID.equals(tenantId)) {
            processDefinition = deploymentCache.findDeployedLatestProcessDefinitionByKeyAndTenantId(processDefinitionKey, tenantId);
            if (processDefinition == null) {
                throw new ActivitiObjectNotFoundException("流程定义key为" + processDefinitionKey + "的流程定义在租户" + tenantId + "下不存在。", ProcessDefinition.class);
            }
        } else {
            throw new ActivitiIllegalArgumentException("processDefinitionKey和processDefinitionId不能同时为空。");
        }

        processInstanceHelper = commandContext.getProcessEngineConfiguration().getProcessInstanceHelper();
        ProcessInstance processInstance = null;
        if (StringUtils.isNoneBlank(processInstanceId)) {
            processInstance = this.createAndStartProcessInstance(processDefinition, processInstanceId, businessKey, processInstanceName, variables, transientVariables);
        } else {
            processInstance = super.createAndStartProcessInstance(processDefinition, businessKey, processInstanceName, variables, transientVariables);
        }
        return processInstance;
    }

    protected ProcessInstance createAndStartProcessInstance(ProcessDefinition processDefinition, String processInstanceId, String businessKey, String processInstanceName,
                                                            Map<String,Object> variables, Map<String, Object> transientVariables) {
        return ((CustomProcessInstanceHelper)processInstanceHelper).createAndStartProcessInstance(processDefinition, processInstanceId, businessKey, processInstanceName, variables, transientVariables, true);
    }
}