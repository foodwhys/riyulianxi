package com.bpm.example.demo3.service;

import com.bpm.example.demo3.impl.cmd.CustomStartProcessInstanceCmd;
import lombok.AllArgsConstructor;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.runtime.ProcessInstance;
import java.util.Map;

@AllArgsConstructor
public class RevokeProcessInstanceService {

    RuntimeService runtimeService;
    HistoryService historyService;
    ManagementService managementService;

    /**
     * 流程撤销
     * @param processInstanceId
     */
    public ProcessInstance revokeProcess(String processInstanceId) {
        //根据processInstanceId查询流程实例
        ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        if (processInstance == null) {
            throw new ActivitiObjectNotFoundException("编号为" + processInstanceId + "的流程实例不存在。", ProcessInstance.class);
        }
        //不是流程发起者不能撤销流程
        String authenticatedUserId = Authentication.getAuthenticatedUserId();
        if (!processInstance.getStartUserId().equals(authenticatedUserId)) {
            throw new ActivitiException("非流程发起者不能撤销流程。");
        }

        //查询流程变量
        Map variables = runtimeService.getVariables(processInstanceId);
        //删除流程实例
        runtimeService.deleteProcessInstance(processInstanceId, "");
        //删除历史流程实例
        historyService.deleteHistoricProcessInstance(processInstanceId);
        //重建流程
        ProcessInstance newProcessInstance = managementService.executeCommand(new CustomStartProcessInstanceCmd<ProcessInstance>(processInstance.getProcessDefinitionKey(),processInstance.getProcessDefinitionId(),processInstance.getProcessInstanceId(), processInstance.getBusinessKey(), variables, processInstance.getTenantId()));
        return newProcessInstance;
    }
}