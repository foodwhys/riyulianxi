package com.bpm.example.demo1;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo1.service.DynamicJumpService;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;

@Slf4j
public class RunDynamicJumpDemo extends ActivitiEngineUtil {

    @Test
    public void runDynamicJumpDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/DynamicJumpProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询特殊借款申请用户任务的task
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成特殊借款申请用户任务的task
        taskService.complete(firstTask.getId());
        //查询直属上级审批用户任务的task
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("跳转前，当前流程所处节点名称为：{}，节点key为：{}", secondTask.getName(), secondTask.getTaskDefinitionKey());
        //执行跳转操作
        DynamicJumpService dynamicJumpService = new DynamicJumpService(managementService);
        dynamicJumpService.executeJump(processInstance.getId(), secondTask.getTaskDefinitionKey(), "fourthNode");
        //查询执行跳转操作后流程所在的用户任务的task
        Task fourthTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("跳转后，当前流程所处节点名称为：{}，节点key为：{}", fourthTask.getName(), fourthTask.getTaskDefinitionKey());

        //关闭流程引擎
        engine.close();
    }
}