package com.bpm.example.demo2.cmd;

import com.bpm.example.demo2.dynamic.DynamicStateManager;
import lombok.AllArgsConstructor;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.bpmn.model.FlowNode;
import org.activiti.bpmn.model.Gateway;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.ActivitiIllegalArgumentException;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.util.ProcessDefinitionUtil;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
public class TaskRecallCmd implements Command<Void> {
    //任务编号
    protected final String taskId;

    public Void execute(CommandContext commandContext) {
        //taskId参数不能为空
        if (this.taskId == null) {
            throw new ActivitiIllegalArgumentException("Task id is required");
        }
        //获取历史服务
        HistoryService historyService = commandContext.getProcessEngineConfiguration().getHistoryService();
        //根据taskId查询历史任务
        HistoricTaskInstance taskInstance = historyService.createHistoricTaskInstanceQuery().taskId(this.taskId).singleResult();
        //进行一系列任务和流程校验
        basicCheck(commandContext, taskInstance);

        //获取流程模型
        BpmnModel bpmnModel = ProcessDefinitionUtil.getBpmnModel(taskInstance.getProcessDefinitionId());
        FlowElement flowElement = bpmnModel.getFlowElement(taskInstance.getTaskDefinitionKey());
        List<String> nextElementIdList = new ArrayList();
        List<UserTask> nextUserTaskList = new ArrayList();
        //获取后续节点信息
        getNextElementInfo(bpmnModel, flowElement, nextElementIdList, nextUserTaskList);
        //再校验是否后续节点任务是否已经办理完成
        existNextFinishedTaskCheck(commandContext, taskInstance, nextUserTaskList);

        //流程相关数据准备
        DynamicStateManager dynamicStateManager = new DynamicStateManager();
        List<String> recallElementIdList = getRecallElementIdList(commandContext, taskInstance, nextElementIdList);
        List<ExecutionEntity> executions = new ArrayList<>();
        for (String activityId : recallElementIdList) {
            //查询后续节点对应的执行实例
            ExecutionEntity execution = dynamicStateManager.resolveActiveExecution(taskInstance.getProcessInstanceId(), activityId, commandContext);
            executions.add(execution);
        }
        //执行撤回操作
        dynamicStateManager.moveExecutionState(executions, taskInstance.getTaskDefinitionKey(), commandContext);
        return null;
    }

    /**
     * 任务校验
     * @param commandContext
     * @param taskInstance
     */
    private void basicCheck(CommandContext commandContext, HistoricTaskInstance taskInstance) {
        if (taskInstance == null) {
            String msg = "任务不存在";
            throw new RuntimeException(msg);
        }
        if (taskInstance.getEndTime() == null) {
            String msg = "任务正在执行,不需要回退";
            throw new RuntimeException(msg);
        }
        RuntimeService runtimeService = commandContext.getProcessEngineConfiguration().getRuntimeService();
        ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(taskInstance.getProcessInstanceId()).singleResult();
        if (processInstance == null) {
            String msg = "该流程已经完成，无法进行任务回退。";
            throw new RuntimeException(msg);
        }
    }

    /**
     * 获取后续节点信息
     * @param bpmnModel             流程模型
     * @param currentFlowElement   当前节点
     * @param nextElementIdList    后续节点Id列表
     * @param nextUserTaskList     后续用户任务节点列表
     */
    private void getNextElementInfo(BpmnModel bpmnModel, FlowElement currentFlowElement, List<String> nextElementIdList, List<UserTask> nextUserTaskList) {
        //查询当前节点所有流出顺序流
        List<SequenceFlow> outgoingFlows = ((FlowNode)currentFlowElement).getOutgoingFlows();
        for (SequenceFlow flow : outgoingFlows) {
            //后续节点
            FlowElement targetFlowElement = bpmnModel.getFlowElement(flow.getTargetRef());
            nextElementIdList.add(targetFlowElement.getId());
            if (targetFlowElement instanceof UserTask) {
                nextUserTaskList.add((UserTask)targetFlowElement);
            } else if (targetFlowElement instanceof Gateway) {
                Gateway gateway = ((Gateway) targetFlowElement);
                //网关节点执行递归操作
                getNextElementInfo(bpmnModel, gateway,nextElementIdList,nextUserTaskList);
            } else {
                //其它类型节点暂未实现
            }
        }
    }

    /**
     * 校验是否后续节点任务是否已经办理完成
     * @param commandContext        上下文CommandContext
     * @param currentTaskInstance   当前任务实例
     * @param nextUserTaskList      后续用户
     */
    private void existNextFinishedTaskCheck(CommandContext commandContext, HistoricTaskInstance currentTaskInstance, List<UserTask> nextUserTaskList) {
        List<HistoricTaskInstance> hisTaskList = commandContext.getProcessEngineConfiguration().getHistoryService().createHistoricTaskInstanceQuery()
                .processInstanceId(currentTaskInstance.getProcessInstanceId())
                .taskCompletedAfter(currentTaskInstance.getEndTime())
                .list();
        List<String> nextUserTaskIdList = nextUserTaskList.stream().map(UserTask::getId).collect(Collectors.toList());
        if (!hisTaskList.isEmpty()) {
            hisTaskList.forEach(obj -> {
                if (nextUserTaskIdList.contains(obj.getTaskDefinitionKey())) {
                    String msg = "存在已完成下一节点任务";
                    throw new RuntimeException(msg);
                }
            });
        }
    }

    /**
     * 获取可撤回的节点列表
     * @param commandContext       上下文CommandContext
     * @param currentTaskInstance  任务实例
     * @param nextElementIdList    后续节点列表
     * @return
     */
    private List<String> getRecallElementIdList(CommandContext commandContext, HistoricTaskInstance currentTaskInstance, List<String> nextElementIdList) {
        List<String> recallElementIdList = new ArrayList();
        List<Execution> executions = commandContext.getProcessEngineConfiguration().getRuntimeService()
                .createExecutionQuery().processInstanceId(currentTaskInstance.getProcessInstanceId()).onlyChildExecutions().list();
        if (!executions.isEmpty()) {
            executions.forEach(obj -> {
                if (nextElementIdList.contains(obj.getActivityId())) {
                    recallElementIdList.add(obj.getActivityId());
                }
            });
        }
        return recallElementIdList;
    }
}
