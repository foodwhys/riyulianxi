package com.bpm.example.demo2;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo2.service.TaskRecallService;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class RunTaskRecallDemo extends ActivitiEngineUtil {

    @Test
    public void runTaskRecallDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/TaskRecallProcess.bpmn20.xml");

        //发起流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询借款申请用户任务的task
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //完成借款申请用户任务的task
        taskService.complete(firstTask.getId());

        //查询执行撤回操作前所处的流程节点
        List<Task> taskList1 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
        String taskNames1 = taskList1.stream().map(Task::getName).collect(Collectors.joining(","));
        log.info("撤回前，当前流程所处节点名称为：{}", taskNames1);

        //执行撤回操作
        TaskRecallService taskRecallService = new TaskRecallService(managementService);
        taskRecallService.executeRecall(firstTask.getId());

        //查询执行撤回操作后所处的流程节点
        List<Task> taskList2 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).list();
        String taskNames2 = taskList2.stream().map(Task::getName).collect(Collectors.joining(","));
        log.info("撤回后，当前流程所处节点名称为：{}", taskNames2);

        //关闭流程引擎
        engine.close();
    }
}
