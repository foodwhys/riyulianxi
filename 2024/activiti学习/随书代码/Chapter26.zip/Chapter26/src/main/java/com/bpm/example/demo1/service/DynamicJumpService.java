package com.bpm.example.demo1.service;

import com.bpm.example.demo1.cmd.DynamicJumpCmd;
import lombok.AllArgsConstructor;
import org.activiti.engine.ManagementService;

@AllArgsConstructor
public class DynamicJumpService {

    protected ManagementService managementService;

    public void executeJump(String processInstanceId, String fromActivityId, String toActivityId) {
        //实例化自定义跳转Command类
        DynamicJumpCmd dynamicJumpCmd = new DynamicJumpCmd(processInstanceId, fromActivityId, toActivityId);
        //通过ManagementService管理服务执行自定义跳转Command类
        managementService.executeCommand(dynamicJumpCmd);
    }
}