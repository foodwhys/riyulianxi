package com.bpm.example.demo3.persistence.entity;

import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
import org.activiti.engine.repository.ProcessDefinition;

public interface CustomExecutionEntityManager extends ExecutionEntityManager {

    ExecutionEntity createProcessInstanceExecution(ProcessDefinition processDefinition, String processInstanceId, String businessKey, String tenantId, String initiatorVariableName);

}