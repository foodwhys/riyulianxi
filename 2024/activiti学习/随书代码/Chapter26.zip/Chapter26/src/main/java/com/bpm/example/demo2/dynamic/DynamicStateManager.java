package com.bpm.example.demo2.dynamic;

import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.impl.context.Context;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityManager;
import org.activiti.engine.impl.util.ProcessDefinitionUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DynamicStateManager {

    /**
     * 查询节点对应的执行实例
     * @param processInstanceId   流程实例编号
     * @param activityId           节点编号
     * @param commandContext       上下文CommandContext
     * @return
     */
    public ExecutionEntity resolveActiveExecution(String processInstanceId, String activityId, CommandContext commandContext) {
        //获取执行实例实体管理器
        ExecutionEntityManager executionEntityManager = commandContext.getExecutionEntityManager();
        //查询当前流程实例
        ExecutionEntity processExecution = (ExecutionEntity)executionEntityManager.findById(processInstanceId);
        if (processExecution == null) {
            throw new ActivitiException("Execution could not be found with id " + processInstanceId);
        }
        if (!processExecution.isProcessInstanceType()) {
            throw new ActivitiException("Execution is not a process instance type execution for id " + processInstanceId);
        }

        ExecutionEntity activeExecutionEntity = null;
        //查询所有子执行实例
        List<ExecutionEntity> childExecutions = executionEntityManager.findChildExecutionsByProcessInstanceId(processExecution.getId());
        for (ExecutionEntity childExecution : childExecutions) {
            if (childExecution.getCurrentActivityId().equals(activityId)) {
                activeExecutionEntity = childExecution;
            }
        }
        if (activeExecutionEntity == null) {
            throw new ActivitiException("Active execution could not be found with activity id " + activityId);
        }
        return activeExecutionEntity;
    }

    /**
     * 执行流程状态迁移操作
     * @param currentExecutions  当前的执行实例列表
     * @param moveToActivityId   要撤回到的目标节点
     * @param commandContext     上下文CommandContext
     */
    public void moveExecutionState(List<ExecutionEntity> currentExecutions, String moveToActivityId, CommandContext commandContext) {
        ExecutionEntityManager executionEntityManager = commandContext.getExecutionEntityManager();
        ExecutionEntity firstExecution = currentExecutions.get(0);
        //获取流程模型
        BpmnModel bpmnModel = ProcessDefinitionUtil.getBpmnModel(firstExecution.getProcessDefinitionId());
        FlowElement moveToFlowElement = bpmnModel.getFlowElement(moveToActivityId);
        if (moveToFlowElement == null) {
            throw new ActivitiException("Activity could not be found in process definition for id " + moveToActivityId);
        }

        //汇聚待撤回的执行实例的父执行实例
        Map<String, ExecutionEntity> continueParentExecutionMap = new HashMap();
        for (ExecutionEntity execution : currentExecutions) {
            if (execution.getParentId() == null) {
                throw new ActivitiException("Execution has no parent execution " + execution.getParentId());
            }
            ExecutionEntity continueParentExecution = executionEntityManager.findById(execution.getParentId());
            continueParentExecutionMap.put(execution.getId(), continueParentExecution);
        }
        //删除当前节点所在的执行实例及相关数据
        for (ExecutionEntity execution : currentExecutions) {
            executionEntityManager.deleteExecutionAndRelatedData(execution, "Change activity to " + moveToFlowElement.getId(),false);
        }
        ExecutionEntity defaultContinueParentExecution = continueParentExecutionMap.get(currentExecutions.get(0).getId());
        //创建子执行实例
        ExecutionEntity newChildExecution = executionEntityManager.createChildExecution(defaultContinueParentExecution);
        //设置子执行实例的当前活动节点为撤回的目标节点
        newChildExecution.setCurrentFlowElement(moveToFlowElement);
        //向operations中压入继续流程的操作类
        Context.getAgenda().planContinueProcessOperation(newChildExecution);
    }
}