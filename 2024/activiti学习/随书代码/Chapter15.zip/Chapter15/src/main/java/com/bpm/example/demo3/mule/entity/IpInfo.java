package com.bpm.example.demo3.mule.entity;

import lombok.Data;
import java.io.Serializable;

@Data
public class IpInfo implements Serializable {
    //国家
    private String country;
    //省份
    private String regionName;
    //城市
    private String city;
    //互联网服务提供商
    private String isp;
}
