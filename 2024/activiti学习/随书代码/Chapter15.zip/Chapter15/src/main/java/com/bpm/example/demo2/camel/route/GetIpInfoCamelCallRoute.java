package com.bpm.example.demo2.camel.route;

import com.bpm.example.demo2.camel.processor.ResultProcessor;
import org.apache.camel.builder.RouteBuilder;

public class GetIpInfoCamelCallRoute extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        from("activiti:CamelTaskProcess:camelTask1?copyVariablesToProperties=true")
                .toD("http://ip-api.com/json/${property.ip}?lang=zh-CN&bridgeEndpoint=true")
                .process(new ResultProcessor());
    }
}

