package com.bpm.example.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class RunShellTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runShellTaskProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/ShellTaskProcess.bpmn20.xml");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询用户任务
        Task userTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        //设置流程变量
        Map variables = new HashMap();
        variables.put("browserLocation","C:\\Program Files (x86)\\GoogleChrome\\App\\Chrome\\chrome.exe");
        variables.put("webUrl","https://www.epubit.com/");
        //完成第一个任务
        taskService.complete(userTask.getId(), variables);

        //关闭流程引擎
        closeEngine();
    }
}