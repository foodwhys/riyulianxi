package com.bpm.example.demo2;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunCamelTaskProcessDemo {

    @Test
    public void runCamelTaskProcessDemo() {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("activiti.camel.xml");
        //创建流程引擎配置
        ProcessEngineConfigurationImpl processEngineConfiguration
                = (ProcessEngineConfigurationImpl)applicationContext.getBean("processEngineConfiguration");
        //创建流程引擎
        ProcessEngine engine = processEngineConfiguration.buildProcessEngine();
        //获取流程存储服务
        RepositoryService repositoryService = engine.getRepositoryService();
        //获取运行时服务
        RuntimeService runtimeService = engine.getRuntimeService();
        //获取历史服务
        HistoryService historyService = engine.getHistoryService();
        //部署流程
        repositoryService.createDeployment().addClasspathResource("processes/CamelTaskProcess.bpmn20.xml").deploy();

        //设置流程变量
        Map variables = new HashMap();
        variables.put("userName", "诗雨花魂");
        variables.put("userMail", "#########@qq.com");
        variables.put("ip", "39.156.66.14");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("CamelTaskProcess", variables);
        //查询并打印流程变量
        List<HistoricVariableInstance> historicVariableInstances
                = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).list();
        historicVariableInstances.stream().forEach((historicVariableInstance) -> log.info("流程变量名：{}，变量值：{}", historicVariableInstance.getVariableName(), JSON.toJSONString(historicVariableInstance.getValue())));

        //关闭流程引擎
        engine.close();
    }
}