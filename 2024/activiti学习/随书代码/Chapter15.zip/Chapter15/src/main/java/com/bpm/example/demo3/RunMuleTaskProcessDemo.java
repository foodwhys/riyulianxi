package com.bpm.example.demo3;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunMuleTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runMuleTaskProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.mule.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/MuleTaskProcess.bpmn20.xml");

        //设置流程变量
        Map variables = new HashMap();
        variables.put("userName", "诗雨花魂");
        variables.put("userMail", "#########@qq.com");
        variables.put("ip", "39.156.66.14");
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), variables);
        //查询并打印流程变量
        List<HistoricVariableInstance> historicVariableInstances = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).list();
        historicVariableInstances.stream().forEach((historicVariableInstance) -> log.info("流程变量名：{}，变量值：{}", historicVariableInstance.getVariableName(), historicVariableInstance.getValue()));

        //关闭流程引擎
        closeEngine();
    }
}