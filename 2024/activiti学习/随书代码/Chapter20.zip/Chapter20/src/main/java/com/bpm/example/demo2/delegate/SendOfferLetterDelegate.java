package com.bpm.example.demo2.delegate;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

@Slf4j
public class SendOfferLetterDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        int loopCounter = (Integer) execution.getVariable("loopCounter");
        String userId = (String)execution.getVariable("userId");
        log.info("第{}位录取人员{}的录用通知发送成功！", (loopCounter + 1), userId);
    }
}