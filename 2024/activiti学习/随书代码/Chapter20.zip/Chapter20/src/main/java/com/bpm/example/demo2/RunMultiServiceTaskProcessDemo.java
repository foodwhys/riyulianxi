package com.bpm.example.demo2;

import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RunMultiServiceTaskProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runMultiServiceTaskProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/MultiServiceTaskProcess.bpmn20.xml");

        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        //查询第一个任务
        Task userTask1 = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        log.info("即将完成第一个任务，当前任务名称：{}", userTask1.getName());

        Map variables  = new HashMap();
        List<String> userIdList = Arrays.asList("huhaiqin","liuxiaopeng","hebo");
        variables.put("userIdList", userIdList);
        //完成第一个任务
        taskService.complete(userTask1.getId(), variables);

        //关闭流程引擎
        engine.close();
    }
}
