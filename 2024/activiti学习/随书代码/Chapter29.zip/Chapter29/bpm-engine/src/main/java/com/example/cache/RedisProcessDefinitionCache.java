package com.example.cache;

import com.example.client.ProcessDefinitionClient;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.impl.persistence.deploy.DeploymentCache;
import org.activiti.engine.impl.persistence.deploy.ProcessDefinitionCacheEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
public class RedisProcessDefinitionCache implements DeploymentCache<ProcessDefinitionCacheEntry> {

    private Logger log = LoggerFactory.getLogger(RedisProcessDefinitionCache.class);

    @Resource(name = "processDefinitionCacheRedisTemplate")
    private RedisTemplate<String, ProcessDefinitionCacheEntry> redisTemplate;

    @Value("${activiti.process-definitions.cache.key}")
    private String processDefinitionCacheKey;

    @Autowired
    private ProcessDefinitionClient processDefinitionClient;

    @Override
    public ProcessDefinitionCacheEntry get(String id) {
        log.info("Query cache from redis: id={}", id);
        Object obj = redisTemplate.opsForHash().get(processDefinitionCacheKey, id);
        if (obj == null) {
            log.info("Sync cache to redis. id={}", id);
            processDefinitionClient.syncProcessDefinition(id);
            obj = redisTemplate.opsForHash().get(processDefinitionCacheKey, id);
        }
        if (obj == null) {
            throw new ActivitiObjectNotFoundException("流程定义ID：" + id + "；不存在");
        }
        return (ProcessDefinitionCacheEntry) obj;
    }

    @Override
    public boolean contains(String id) {
        return redisTemplate.opsForHash().hasKey(processDefinitionCacheKey, id);
    }

    @Override
    public void add(String id, ProcessDefinitionCacheEntry object) {
        throw new ActivitiException("不支持的操作");
    }

    @Override
    public void remove(String id) {
        throw new ActivitiException("不支持的操作");
    }

    @Override
    public void clear() {
        throw new ActivitiException("不支持的操作");
    }
}
