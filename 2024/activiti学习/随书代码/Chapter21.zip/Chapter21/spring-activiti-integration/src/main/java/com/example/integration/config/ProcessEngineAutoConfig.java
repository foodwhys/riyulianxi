package com.example.integration.config;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

//@Configuration
public class ProcessEngineAutoConfig {

    @Value("${activiti.jdbcUrl}")
    private String jdbcUrl;
    @Value("${activiti.jdbcDriver}")
    private String jdbcDriver;
    @Value("${activiti.jdbcUsername}")
    private String jdbcUsername;
    @Value("${activiti.jdbcPassword}")
    private String jdbcPassword;
    @Value("${activiti.databaseSchemaUpdate}")
    private String databaseSchemaUpdate;
    @Value("${activiti.processEngineName}")
    private String processEngineName;

    //@Bean
    public ProcessEngine createProcessEngine(){
        ProcessEngineConfiguration configuration = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
        configuration.setJdbcDriver(jdbcDriver );
        configuration.setJdbcPassword(jdbcPassword);
        configuration.setJdbcUrl(jdbcUrl);
        configuration.setJdbcUsername(jdbcUsername);
        configuration.setDatabaseSchemaUpdate(databaseSchemaUpdate);
        configuration.setProcessEngineName(processEngineName);
        ProcessEngine engine = configuration.buildProcessEngine();
        System.out.println(engine.getName());
        return engine;
    }

    //@Bean
    public ProcessEngineConfiguration createProcessEngineConfiguration(){
        ProcessEngineConfiguration configuration = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
        configuration.setJdbcDriver("org.h2.Driver" );
        configuration.setJdbcPassword("");
        configuration.setJdbcUrl("jdbc:h2:mem:activiti;DB_CLOSE_DELAY=1000");
        configuration.setJdbcUsername("sa");
        configuration.setDatabaseSchemaUpdate("true");
        configuration.setProcessEngineName("code-config-engine");
        return configuration;
    }

}
