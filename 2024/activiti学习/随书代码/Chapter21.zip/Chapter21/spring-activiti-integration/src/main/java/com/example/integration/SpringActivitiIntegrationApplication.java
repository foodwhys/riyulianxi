package com.example.integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringActivitiIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringActivitiIntegrationApplication.class, args);
    }
}
