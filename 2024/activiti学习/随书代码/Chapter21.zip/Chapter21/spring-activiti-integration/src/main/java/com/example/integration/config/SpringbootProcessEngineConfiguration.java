package com.example.integration.config;

import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.interceptor.CommandInterceptor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "activiti")
public class SpringbootProcessEngineConfiguration extends ProcessEngineConfigurationImpl {

    @Override
    public CommandInterceptor createTransactionInterceptor() {
        return null;
    }
}
