package com.bpm.example.demo1.identity.membership;

import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.entity.AbstractEntityManager;
import org.activiti.engine.impl.persistence.entity.MembershipEntity;
import org.activiti.engine.impl.persistence.entity.MembershipEntityManager;
import org.activiti.engine.impl.persistence.entity.data.DataManager;
import org.activiti.engine.impl.persistence.entity.data.MembershipDataManager;

public class CustomMembershipEntityManager extends AbstractEntityManager<MembershipEntity> implements MembershipEntityManager {

    protected MembershipDataManager membershipDataManager;

    public CustomMembershipEntityManager(ProcessEngineConfigurationImpl processEngineConfiguration, MembershipDataManager membershipDataManager) {
        super(processEngineConfiguration);
        this.membershipDataManager = membershipDataManager;
    }

    @Override
    protected DataManager<MembershipEntity> getDataManager() {
        return membershipDataManager;
    }

    /**
     * 创建用户和用户组的关联关系
     * @param userId
     * @param groupId
     */
    @Override
    public void createMembership(String userId, String groupId) {
        MembershipEntity membershipEntity = membershipDataManager.create();
        membershipEntity.setUserId(userId);
        membershipEntity.setGroupId(groupId);
        membershipDataManager.insert(membershipEntity);
    }

    /**
     * 删除用户和用户组的关联关系
     * @param userId
     * @param groupId
     */
    @Override
    public void deleteMembership(String userId, String groupId) {
        membershipDataManager.deleteMembership(userId, groupId);
    }

    /**
     * 删除用户组的所有组员
     * @param groupId
     */
    @Override
    public void deleteMembershipByGroupId(String groupId) {
        membershipDataManager.deleteMembershipByGroupId(groupId);
    }

    /**
     * 删除用户与所有用户组的关联关系
     * @param userId
     */
    @Override
    public void deleteMembershipByUserId(String userId) {
        membershipDataManager.deleteMembershipByUserId(userId);
    }
}
