package com.bpm.example.demo1.identity;

import com.bpm.example.demo1.identity.group.entity.CustomGroupEntity;
import com.bpm.example.demo1.identity.membership.entity.CustomMembershipEntity;
import com.bpm.example.demo1.identity.user.entity.CustomUserEntity;
import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.persistence.entity.GroupEntityImpl;
import org.activiti.engine.impl.persistence.entity.MembershipEntity;
import org.activiti.engine.impl.persistence.entity.MembershipEntityImpl;
import org.activiti.engine.impl.persistence.entity.UserEntityImpl;

/**
 * 实现自己定义的用户、用户组实体与Activiti中的user、group互转
 */
public class ActivitiIdentityUtils {

    /**
     * 将自定义用户实体转换为Activiti的User
     * @param user
     * @return
     */
    public static User toActivitiUser(CustomUserEntity user) {
        if (user != null) {
            User userEntity=new UserEntityImpl();
            userEntity.setId(user.getUserName());
            if (user.getRealName() != null) {
                userEntity.setFirstName(user.getRealName().substring(0,1));
                userEntity.setLastName(user.getRealName().substring(1));
            }
            userEntity.setEmail(user.getEmail());
            userEntity.setPassword(user.getPassword());
            return userEntity;
        }
        return null;
    }

    /**
     * 将Activiti的User转换为将自定义用户实体
     * @param user
     * @return
     */
    public static CustomUserEntity toCustomUser(User user) {
        if (user != null) {
            CustomUserEntity customUserEntity = new CustomUserEntity();
            customUserEntity.setUserName(user.getId());
            customUserEntity.setRealName(user.getFirstName() + user.getLastName());
            customUserEntity.setEmail(user.getEmail());
            customUserEntity.setPassword(user.getPassword());
            return customUserEntity;
        }
        return null;
    }

    /**
     * 将自定义用户组实体转换为Activiti的Group
     * @param group
     * @return
     */
    public static Group toActivitiGroup(CustomGroupEntity group) {
        if (group != null) {
            Group groupEntity=new GroupEntityImpl();
            groupEntity.setId(group.getGroupId());
            groupEntity.setType("CustomGroup");
            groupEntity.setName(group.getGroupName());
            return groupEntity;
        }
        return null;
    }

    /**
     * 将Activiti的Group转换为自定义用户组实体
     * @param group
     * @return
     */
    public static CustomGroupEntity toCustomGroup(Group group) {
        if (group != null) {
            CustomGroupEntity customGroupEntity = new CustomGroupEntity();
            customGroupEntity.setGroupId(group.getId());
            customGroupEntity.setGroupName(group.getName());
            return customGroupEntity;
        }
        return null;
    }

    /**
     * 将自定义关系实体转换为Activiti的MembershipEntity
     * @param customMembershipEntity
     * @return
     */
    public static MembershipEntity toActivitiMembershipEntity(CustomMembershipEntity customMembershipEntity) {
        if (customMembershipEntity != null) {
            MembershipEntity membershipEntity=new MembershipEntityImpl();
            membershipEntity.setUserId(customMembershipEntity.getUserName());
            membershipEntity.setGroupId(customMembershipEntity.getGroupId());
            return membershipEntity;
        }
        return null;
    }

    /**
     * 将Activiti的MembershipEntity转换为自定义关系实体
     * @param membershipEntity
     * @return
     */
    public static CustomMembershipEntity toCustomMembershipEntity(MembershipEntity membershipEntity) {
        if (membershipEntity != null) {
            CustomMembershipEntity customMembershipEntity = new CustomMembershipEntity();
            customMembershipEntity.setGroupId(membershipEntity.getGroupId());
            customMembershipEntity.setUserName(membershipEntity.getUserId());
            return customMembershipEntity;
        }
        return null;
    }
}