package com.bpm.example.demo1.identity.user;

import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.Picture;
import org.activiti.engine.identity.User;
import org.activiti.engine.identity.UserQuery;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.UserQueryImpl;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.entity.AbstractEntityManager;
import org.activiti.engine.impl.persistence.entity.UserEntity;
import org.activiti.engine.impl.persistence.entity.UserEntityManager;
import org.activiti.engine.impl.persistence.entity.data.DataManager;
import org.activiti.engine.impl.persistence.entity.data.UserDataManager;
import java.util.List;
import java.util.Map;

public class CustomUserEntityManager extends AbstractEntityManager<UserEntity> implements UserEntityManager {

    protected UserDataManager userDataManager;

    public CustomUserEntityManager(ProcessEngineConfigurationImpl processEngineConfiguration, UserDataManager userDataManager) {
        super(processEngineConfiguration);
        this.userDataManager = userDataManager;
    }

    @Override
    protected DataManager<UserEntity> getDataManager() {
        return userDataManager;
    }

    /**
     * 创建一个用户对象
     * @param userId
     * @return
     */
    @Override
    public User createNewUser(String userId) {
        UserEntity userEntity = create();
        userEntity.setId(userId);
        userEntity.setRevision(0);
        return userEntity;
    }

    /**
     * 修改用户信息
     * @param updatedUser
     */
    @Override
    public void updateUser(User updatedUser) {
        super.update((UserEntity) updatedUser);
    }

    /**
     * 根据用户编号查询所在的用户组
     * @param userId
     * @return
     */
    @Override
    public List<Group> findGroupsByUser(String userId) {
        return userDataManager.findGroupsByUser(userId);
    }

    @Override
    public boolean isNewUser(User user) {
        return ((UserEntity) user).getRevision() == 0;
    }

    @Override
    public Boolean checkPassword(String userId, String password) {
        User user = null;
        if (userId != null) {
            user = findById(userId);
        }
        if ((user != null) && (password != null) && (password.equals(user.getPassword()))) {
            return true;
        }
        return false;
    }

    @Override
    public List<User> findUserByQueryCriteria(UserQueryImpl query, Page page) {
        return userDataManager.findUserByQueryCriteria(query, page);
    }

    @Override
    public long findUserCountByQueryCriteria(UserQueryImpl query) {
        return userDataManager.findUserCountByQueryCriteria(query);
    }

    @Override
    public UserQuery createNewUserQuery() {
        return new UserQueryImpl(getCommandExecutor());
    }

    @Override
    public List<User> findUsersByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults) {
        return userDataManager.findUsersByNativeQuery(parameterMap, firstResult, maxResults);
    }

    @Override
    public long findUserCountByNativeQuery(Map<String, Object> parameterMap) {
        return userDataManager.findUserCountByNativeQuery(parameterMap);
    }

    @Override
    public Picture getUserPicture(String userId) {
        UserEntity user = findById(userId);
        if (user == null) {
            throw new ActivitiObjectNotFoundException("user " + userId + " doesn't exist", User.class);
        }
        return user.getPicture();
    }

    @Override
    public void setUserPicture(String userId, Picture picture) {
        UserEntity user = findById(userId);
        if (user == null) {
            throw new ActivitiObjectNotFoundException("user " + userId + " doesn't exist", User.class);
        }
        user.setPicture(picture);
    }

    @Override
    public void deletePicture(User user) {
        //为节省篇幅，本方法并未实现
    }
}