package com.bpm.example.demo1.identity.group.data;

import com.alibaba.fastjson.JSON;
import com.bpm.example.demo1.identity.ActivitiIdentityUtils;
import com.bpm.example.demo1.identity.group.entity.CustomGroupEntity;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.identity.Group;
import org.activiti.engine.impl.GroupQueryImpl;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.persistence.entity.GroupEntity;
import org.activiti.engine.impl.persistence.entity.GroupEntityImpl;
import org.activiti.engine.impl.persistence.entity.data.GroupDataManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class CustomGroupDataManager implements GroupDataManager {

    /**
     * 创建一个用户组对象
     * @return
     */
    @Override
    public GroupEntity create() {
        return new GroupEntityImpl();
    }

    /**
     * 调用外部身份模块接口根据用户组主键查询用户组信息
     * @param entityId
     * @return
     */
    @Override
    public GroupEntity findById(String entityId) {
        CustomGroupEntity groupEntity = new CustomGroupEntity();
        groupEntity.setGroupId(entityId);
        //为了节省篇幅，此处省略调用外部身份模块接口根据用户组主键查询用户组信息代码，仅用打印日志替代
        log.info("调用外部身份模块接口根据用户组主键{}查询用户组信息", entityId);
        return (GroupEntity) ActivitiIdentityUtils.toActivitiGroup(groupEntity);
    }

    /**
     * 调用外部身份模块接口新建用户组
     * @param entity
     */
    @Override
    public void insert(GroupEntity entity) {
        CustomGroupEntity groupEntity = ActivitiIdentityUtils.toCustomGroup(entity);
        //为了节省篇幅，此处省略调用外部身份模块接口新建用户组代码，仅用打印日志替代
        log.info("调用外部身份模块接口新建用户组：{}", JSON.toJSONString(groupEntity));
    }

    /**
     * 调用外部身份模块接口修改用户组
     * @param entity
     * @return
     */
    @Override
    public GroupEntity update(GroupEntity entity) {
        CustomGroupEntity customGroupEntity = ActivitiIdentityUtils.toCustomGroup(entity);
        //为了节省篇幅，此处省略调用外部身份模块接口修改用户组代码，仅用打印日志替代
        log.info("调用外部身份模块接口修改用户组：{}", JSON.toJSONString(customGroupEntity));
        return (GroupEntity)ActivitiIdentityUtils.toActivitiGroup(customGroupEntity);
    } 

    /**
     * 调用外部身份模块接口删除用户组
     * @param id
     */
    @Override
    public void delete(String id) {
        //为节省篇幅，此处省略调用外部身份模块接口删除用户组代码，仅用打印日志替代
        log.info("调用外部身份模块接口删除主键为{}的用户组", id);
    }

    /**
     * 调用外部身份模块接口删除用户
     * @param entity
     */
    @Override
    public void delete(GroupEntity entity) {
        delete(entity.getId());
    }

    /**
     * 用外部身份模块接口根据用户主键查询所在的用户组
     * @param userId
     * @return
     */
    @Override
    public List<Group> findGroupsByUser(String userId) {
        List<CustomGroupEntity> groupEntities = new ArrayList<>();
        //为节省篇幅，此处省略调用外部身份模块接口根据用户主键查询所在组的代码，仅用打印日志替代
        List<Group> groups = new ArrayList<>();
        for (CustomGroupEntity customGroupEntity : groupEntities) {
            Group group = ActivitiIdentityUtils.toActivitiGroup(customGroupEntity);
            groups.add(group);
        }
        log.info("调用外部身份模块接口查询主键为{}的用户所在的用户组：{}", userId, JSON.toJSONString(groups));
        return groups;
    }

    @Override
    public List<Group> findGroupByQueryCriteria(GroupQueryImpl query, Page page) {
        //为节省篇幅，本方法并未实现
        return null;
    }

    @Override
    public long findGroupCountByQueryCriteria(GroupQueryImpl query) {
        //为节省篇幅，本方法并未实现
        return 0;
    }

    @Override
    public List<Group> findGroupsByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults) {
        //为节省篇幅，本方法并未实现
        return null;
    }

    @Override
    public long findGroupCountByNativeQuery(Map<String, Object> parameterMap) {
        //为节省篇幅，本方法并未实现
        return 0;
    }
}