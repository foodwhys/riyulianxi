package com.bpm.example.demo1.identity.group;

import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.GroupQuery;
import org.activiti.engine.impl.GroupQueryImpl;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.persistence.entity.AbstractEntityManager;
import org.activiti.engine.impl.persistence.entity.GroupEntity;
import org.activiti.engine.impl.persistence.entity.GroupEntityManager;
import org.activiti.engine.impl.persistence.entity.data.DataManager;
import org.activiti.engine.impl.persistence.entity.data.GroupDataManager;
import java.util.List;
import java.util.Map;

public class CustomGroupEntityManager extends AbstractEntityManager<GroupEntity> implements GroupEntityManager {

    protected GroupDataManager groupDataManager;

    public CustomGroupEntityManager(ProcessEngineConfigurationImpl processEngineConfiguration, GroupDataManager groupDataManager) {
        super(processEngineConfiguration);
        this.groupDataManager = groupDataManager;
    }

    @Override
    protected DataManager<GroupEntity> getDataManager() {
        return groupDataManager;
    }

    /**
     * 创建一个用户组对象
     * @param groupId
     * @return
     */
    @Override
    public Group createNewGroup(String groupId) {
        GroupEntity groupEntity = groupDataManager.create();
        groupEntity.setId(groupId);
        groupEntity.setRevision(0);
        return groupEntity;
    }

    /**
     * 根据用户编号查询所在的用户组
     * @param userId
     * @return
     */
    @Override
    public List<Group> findGroupsByUser(String userId) {
        return groupDataManager.findGroupsByUser(userId);
    }

    @Override
    public boolean isNewGroup(Group group) {
        return ((GroupEntity) group).getRevision() == 0;
    }

    @Override
    public GroupQuery createNewGroupQuery() {
        return new GroupQueryImpl(getCommandExecutor());
    }

    @Override
    public List<Group> findGroupByQueryCriteria(GroupQueryImpl query, Page page) {
        return groupDataManager.findGroupByQueryCriteria(query, page);
    }

    @Override
    public long findGroupCountByQueryCriteria(GroupQueryImpl query) {
        return groupDataManager.findGroupCountByQueryCriteria(query);
    }

    @Override
    public List<Group> findGroupsByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults) {
        return groupDataManager.findGroupsByNativeQuery(parameterMap, firstResult, maxResults);
    }

    @Override
    public long findGroupCountByNativeQuery(Map<String, Object> parameterMap) {
        return groupDataManager.findGroupCountByNativeQuery(parameterMap);
    }
}