package com.bpm.example.demo3;

import com.alibaba.fastjson.JSON;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.db.DbSqlSession;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.repository.ProcessDefinition;
import org.junit.Test;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class RunCustomSqlProcessDemo extends ActivitiEngineUtil {

    @Test
    public void runCustomSqlProcessDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.custom-mybatis-xml-mapper.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/CustomSqlProcess.bpmn20.xml");

        //启动流程
        String businessKey = UUID.randomUUID().toString();
        runtimeService.startProcessInstanceById(processDefinition.getId(), businessKey);

        //自定义命令
        Command customSqlCommand = new Command<Void>() {
            @Override
            public Void execute(CommandContext commandContext) {
                //从上下文commandContext中获取DbSqlSession对象
                DbSqlSession dbSqlSession = commandContext.getDbSqlSession();
                //通过dbSqlSession的selectOne方法调用自定义MyBatis XML中定义的customSelectProcessInstanceByBusinessKey查询单个结果
                Map<String,String> processInstanceMap = (Map) dbSqlSession.selectOne("customSelectProcessInstanceByBusinessKey",businessKey);
                log.info("流程实例信息为：{}", JSON.toJSONString(processInstanceMap));
                //通过dbSqlSession的selectList方法调用自定义MyBatis XML中定义的customSelectTasksByProcessId查询结果集
                List<TaskEntity> tasks = dbSqlSession.selectList("customSelectTasksByProcessInstanceId",processInstanceMap.get("id"));
                log.info("流程中的待办任务个数有：{}", tasks.size());
                TaskEntity taskEntity = tasks.get(0);
                //通过dbSqlSession的selectList方法调用自定义MyBatis XML中定义的customSelectIdentityLinkByTaskId查询结果集
                List<Map> identityLinks = dbSqlSession.selectList("customSelectIdentityLinkByTaskId",taskEntity.getId());
                log.info("流程任务及候选人信息为：{}", JSON.toJSONString(identityLinks));
                return null;
            }
        };
        //执行自定义命令
        managementService.executeCommand(customSqlCommand);

        //关闭流程引擎
        engine.close();
    }
}