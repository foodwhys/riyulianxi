package com.bpm.example.demo1.identity.membership.data;

import com.alibaba.fastjson.JSON;
import com.bpm.example.demo1.identity.ActivitiIdentityUtils;
import com.bpm.example.demo1.identity.membership.entity.CustomMembershipEntity;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.impl.persistence.entity.MembershipEntity;
import org.activiti.engine.impl.persistence.entity.MembershipEntityImpl;
import org.activiti.engine.impl.persistence.entity.data.MembershipDataManager;

@Slf4j
public class CustomMembershipDataManager implements MembershipDataManager {

    /**
     * 创建一个关联关系
     * @return
     */
    @Override
    public MembershipEntity create() {
        return new MembershipEntityImpl();
    }

    /**
     * 调用外部身份模块接口根据关联关系主键查询关联关系对象
     * @param entityId
     * @return
     */
    @Override
    public MembershipEntity findById(String entityId) {
        CustomMembershipEntity customMembershipEntity = new CustomMembershipEntity();
        customMembershipEntity.setId(entityId);
        /*
            为了节省篇幅，此处省略调用外部身份模块接口根据关联关系主键查询关联关系对象的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口根据关联关系主键{}查询关联关系信息", entityId);
        return (MembershipEntity) ActivitiIdentityUtils.toActivitiMembershipEntity(customMembershipEntity);
    }

    /**
     * 调用外部身份模块接口新建关联关系
     * @param entity
     */
    @Override
    public void insert(MembershipEntity entity) {
        CustomMembershipEntity customMembershipEntity = ActivitiIdentityUtils.toCustomMembershipEntity(entity);
        /*
            为了节省篇幅，此处省略调用外部身份模块接口新建关联关系的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口新建关联关系：{}", JSON.toJSONString(customMembershipEntity));
    }

    /**
     * 调用外部身份模块接口修改关联关系
     * @param entity
     * @return
     */
    @Override
    public MembershipEntity update(MembershipEntity entity) {
        CustomMembershipEntity customMembershipEntity = ActivitiIdentityUtils.toCustomMembershipEntity(entity);
        /*
            为了节省篇幅，此处省略调用外部身份模块接口修改关联关系的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口修改关联关系：{}", JSON.toJSONString(customMembershipEntity));
        return (MembershipEntity)ActivitiIdentityUtils.toActivitiMembershipEntity(customMembershipEntity);
    }

    /**
     * 调用外部身份模块接口删除关联关系
     * @param userId
     * @param groupId
     */
    @Override
    public void deleteMembership(String userId, String groupId) {
        /*
            为节省篇幅，此处省略调用外部身份模块接口删除管理关系的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口删除userId为{}、groupId为{}的关联关系", userId, groupId);
    }

    /**
     * 删除用户组的所有组员
     * @param groupId
     */
    @Override
    public void deleteMembershipByGroupId(String groupId) {
        /*
            为节省篇幅，此处省略调用外部身份模块接口删除用户组所有组员的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口删除groupId为{}的用户组的所有组员", groupId);
    }

    /**
     * 将用户从所有用户组中移除
     * @param userId
     */
    @Override
    public void deleteMembershipByUserId(String userId) {
        /*
            为节省篇幅，此处省略调用外部身份模块接口将用户从所有用户组中移除的代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口将用户{}从所有用户组中移除", userId);
    }

    /**
     * 调用外部身份模块接口删除关联关系
     * @param id
     */
    @Override
    public void delete(String id) {
       /*
            为节省篇幅，此处省略调用外部身份模块接口删除关联关系代码，仅用打印日志替代
         */
        log.info("调用外部身份模块接口删除主键为{}的关联关系", id);
    }

    /**
     * 用外部身份模块接口删除关联关系
     * @param entity
     */
    @Override
    public void delete(MembershipEntity entity) {
        delete(entity.getId());
    }
}
