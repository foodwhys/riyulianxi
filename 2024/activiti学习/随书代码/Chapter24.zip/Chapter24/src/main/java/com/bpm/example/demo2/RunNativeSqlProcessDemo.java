package com.bpm.example.demo2;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.bpm.common.util.ActivitiEngineUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.List;
import java.util.UUID;

@Slf4j
public class RunNativeSqlProcessDemo extends ActivitiEngineUtil {

    SimplePropertyPreFilter processInstanceFilter = new SimplePropertyPreFilter(ProcessInstance.class,
            "id","revision","parentId","businessKey","processInstanceId","processDefinitionKey",
            "processDefinitionId","rootProcessInstanceId","startTime","scope","activityId");
    SimplePropertyPreFilter taskFilter = new SimplePropertyPreFilter(Task.class,
            "id","revision","name","parentTaskId","description","priority","createTime","owner",
            "assignee","delegationStateString","executionId","processInstanceId","processDefinitionId",
            "taskDefinitionKey","dueDate","category","suspensionState","tenantId","formKey","claimTime");

    @Test
    public void runNativeSqlProcessDemo() throws Exception {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/NativeSqlProcess.bpmn20.xml");

        //启动流程
        String businessKey = UUID.randomUUID().toString();
        runtimeService.startProcessInstanceById(processDefinition.getId(), businessKey);

        //通过NativeSql查询单个ProcessInstance对象
        ProcessInstance processInstance = runtimeService.createNativeProcessInstanceQuery()
                .sql("select * from ACT_RU_EXECUTION where BUSINESS_KEY_ = #{businessKey}")
                .parameter("businessKey", businessKey)
                .singleResult();
        log.info("流程实例信息为：{}", JSON.toJSONString(processInstance, processInstanceFilter));

        //通过NativeSql查询任务列表
        List<Task> tasks = taskService.createNativeTaskQuery()
                .sql("select ID_ as id, REV_ as revision, NAME_ as name, PARENT_TASK_ID_ as parentTaskId,"
                        + " DESCRIPTION_ as description, PRIORITY_ as priority, CREATE_TIME_ as createTime,"
                        + " OWNER_ as owner, ASSIGNEE_ as assignee, DELEGATION_ as delegationStateString,"
                        + " EXECUTION_ID_ as executionId, PROC_INST_ID_ as processInstanceId, PROC_DEF_ID_ as processDefinitionId,"
                        + " TASK_DEF_KEY_ as taskDefinitionKey, DUE_DATE_ as dueDate, CATEGORY_ as category,"
                        + " SUSPENSION_STATE_ as suspensionState, TENANT_ID_ as tenantId, FORM_KEY_ as formKey, CLAIM_TIME_ as claimTime"
                        + " from ACT_RU_TASK where PROC_INST_ID_ = #{processInstanceId}")
                .parameter("processInstanceId",processInstance.getId())
                .list();
        log.info("流程中的待办任务有：{}", JSON.toJSONString(tasks, taskFilter));

        //通过NativeSql查询任务个数
        long num = taskService.createNativeTaskQuery()
                .sql("select count(0) from ACT_RU_TASK as t1" +
                        " join ACT_RU_IDENTITYLINK as t2 on t1.ID_ = t2.TASK_ID_" +
                        " where t1.ASSIGNEE_ is null and t2.USER_ID_ = #{userId}")
                .parameter("userId", "huhaiqin")
                .count();
        log.info("用户huhaiqin的待办任务数为：{}", num);

        //关闭流程引擎
        engine.close();
    }
}