package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.junit.Test;

public class RunAddUserToGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runAddUserToGroupDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //新建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo@activiti.org", "******");
        //新建用户组
        GroupUtil.addGroup(identityService,"process_platform_department", "流程平台部", "department");
        //将用户加入用户组
        identityService.createMembership("hebo", "process_platform_department");
    }
}