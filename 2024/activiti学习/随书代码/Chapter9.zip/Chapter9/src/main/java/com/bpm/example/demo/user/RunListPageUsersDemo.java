package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.activiti.engine.identity.UserQuery;
import org.junit.Test;

public class RunListPageUsersDemo extends ActivitiEngineUtil {

    @Test
    public void runListPageUsersDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        UserUtil.addUser(identityService, "tonyhebo", "贺", "博", "tonyhebo@activiti.org", "******");
        UserUtil.addUser(identityService, "zhanghe", "张", "禾", "zhanghe@qq.com", "******");
        UserUtil.addUser(identityService, "liheng", "李", "横", "liheng@qq.com", "******");
        UserUtil.addUser(identityService, "liuxiaopeng", "刘", "晓鹏", "lxpcnic@163.com", "******");
        UserUtil.addUser(identityService, "huhaiqin", "胡", "海琴", "aiqinhai_hu@163.com", "******");
        //分页查询用户并打印
        UserQuery userQuery = identityService.createUserQuery()
                .userEmailLike("%he%")
                .orderByUserId()
                .desc();
        UserUtil.executeListPage(userQuery, 1, 3);
    }
}