package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.junit.Test;

public class RunUpdateGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runUpdateGroupTest() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //修改用户组信息
        GroupUtil.updateGroup(identityService,"process_platform_department","BPM平台部", "department");
    }
}