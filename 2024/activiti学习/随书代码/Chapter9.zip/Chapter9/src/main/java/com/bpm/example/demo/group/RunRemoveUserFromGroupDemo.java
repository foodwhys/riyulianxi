package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.junit.Test;

public class RunRemoveUserFromGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runRemoveUserFromGroupDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //将用户从用户组中移除
        GroupUtil.removeUserFromGroup(identityService, "zhangsan", "testgroup");
    }
}
