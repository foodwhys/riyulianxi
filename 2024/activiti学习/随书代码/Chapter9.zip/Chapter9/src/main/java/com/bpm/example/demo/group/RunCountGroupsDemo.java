package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.activiti.engine.identity.GroupQuery;
import org.junit.Test;

public class RunCountGroupsDemo extends ActivitiEngineUtil {

    @Test
    public void runCountGroupsDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建GroupQuery
        GroupQuery groupQuery  = identityService.createGroupQuery()
                .groupType("department");
        //统计用户组数量
        GroupUtil.executeCount(groupQuery);
    }
}