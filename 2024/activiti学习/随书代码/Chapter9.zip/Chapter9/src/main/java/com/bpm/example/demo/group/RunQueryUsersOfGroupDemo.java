package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.activiti.engine.identity.UserQuery;
import org.junit.Test;

public class RunQueryUsersOfGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runQueryUsersOfGroupDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //新建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        UserUtil.addUser(identityService, "liuxiaopeng", "刘", "晓鹏", "lxpcnic@163.com", "******");
        UserUtil.addUser(identityService, "huhaiqin", "胡", "海琴", "aiqinhai_hu@163.com", "******");
        UserUtil.addUser(identityService, "wangjunlin", "王", "俊林", "wangjunlin@163.com", "******");
        //新建用户组
        GroupUtil.addGroup(identityService, "process_platform_department", "流程平台部", "department");
        //将用户加入用户组
        GroupUtil.addUserToGroup(identityService, "hebo", "process_platform_department");
        GroupUtil.addUserToGroup(identityService, "liuxiaopeng", "process_platform_department");
        GroupUtil.addUserToGroup(identityService, "huhaiqin", "process_platform_department");
        GroupUtil.addUserToGroup(identityService, "wangjunlin", "process_platform_department");
        //查询用户组中的用户
        UserQuery userQuery = identityService.createUserQuery()
                .memberOfGroup("process_platform_department")
                .orderByUserId()
                .asc();
        UserUtil.executeList(userQuery);
    }
}