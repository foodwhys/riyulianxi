package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.activiti.engine.identity.UserQuery;
import org.junit.Test;

public class RunListAllUsersDemo extends ActivitiEngineUtil {

    @Test
    public void runListAllUsersDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        UserUtil.addUser(identityService, "liuxiaopeng", "刘", "晓鹏", "lxpcnic@163.com", "******");
        UserUtil.addUser(identityService, "huhaiqin", "胡", "海琴", "aiqinhai_hu@163.com", "******");
        //初始化UserQuery
        UserQuery userQuery = identityService.createUserQuery();
        //查询所有用户
        UserUtil.executeList(userQuery);
    }
}