package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.identity.User;
import org.activiti.engine.identity.UserQuery;
import org.junit.Test;

@Slf4j
public class RunSingleResultUsersDemo extends ActivitiEngineUtil {

    @Test
    public void runSingleResultUsersDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        UserUtil.addUser(identityService, "liuxiaopeng", "刘", "晓鹏", "lxpcnic@163.com", "******");
        UserUtil.addUser(identityService, "huhaiqin", "胡", "海琴", "aiqinhai_hu@163.com", "******");
        //获查询符合条件的单个用户
        UserQuery userQuery = identityService.createUserQuery()
                .userLastName("贺")
                .userFirstName("波");
        User user = UserUtil.executeSingleResult(userQuery);
        if (user != null) {
            log.info("用户编号：{}，姓名：{}，邮箱：{}", user.getId(), user.getFirstName() + user.getLastName(), user.getEmail());
        }
    }
}
