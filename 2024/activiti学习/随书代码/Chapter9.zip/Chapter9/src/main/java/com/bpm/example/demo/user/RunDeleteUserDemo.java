package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.identity.User;
import org.junit.Test;

@Slf4j
public class RunDeleteUserDemo extends ActivitiEngineUtil {

    @Test
    public void runDeleteUserDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //新建用户
        UserUtil.addUser(identityService, "zhangsan", "张", "三", "zhangsan@qq.com", "******");
        //查询用户信息
        User user = UserUtil.executeSingleResult(identityService.createUserQuery().userId("zhangsan"));
        log.info("用户编号：{}，姓名：{}，邮箱：{}", user.getId(), user.getLastName() + user.getFirstName(), user.getEmail());
        //删除用户
        UserUtil.deleteUser(identityService,"zhangsan");
        //再次查询用户信息
        user = UserUtil.executeSingleResult(identityService.createUserQuery().userId("zhangsan"));
        if (user == null) {
            log.error("用户编号为{}的用户不存在", "zhangsan");
        }
    }
}