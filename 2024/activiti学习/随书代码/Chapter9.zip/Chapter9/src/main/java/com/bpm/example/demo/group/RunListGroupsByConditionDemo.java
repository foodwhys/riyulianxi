package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.activiti.engine.identity.GroupQuery;
import org.junit.Test;

public class RunListGroupsByConditionDemo extends ActivitiEngineUtil {

    @Test
    public void runListGroupsByConditionDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //根据查询匹配的用户组并打印
        GroupQuery groupQuery = identityService.createGroupQuery()
                .groupType("department")
                .orderByGroupId()
                .asc();
        GroupUtil.executeList(groupQuery);
    }
}