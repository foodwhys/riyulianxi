package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.junit.Test;

public class RunDeleteGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runDeleteGroupDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //删除用户组
        GroupUtil.deleteGroup(identityService,"testGroup");
    }
}
