package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.activiti.engine.identity.GroupQuery;
import org.junit.Test;

public class RunSingleResultGroupsDemo extends ActivitiEngineUtil {

    @Test
    public void runSingleResultGroupsDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建GroupQuery
        GroupQuery groupQuery = identityService
                .createGroupQuery()
                .groupId("process_platform_department")
                .groupType("department");
        //查询单个用户组
        GroupUtil.executeSingleResult(groupQuery);
    }
}