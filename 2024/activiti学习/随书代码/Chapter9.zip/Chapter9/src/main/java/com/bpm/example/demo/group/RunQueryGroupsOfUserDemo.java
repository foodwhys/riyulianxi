package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.activiti.engine.identity.GroupQuery;
import org.junit.Test;

public class RunQueryGroupsOfUserDemo extends ActivitiEngineUtil {

    @Test
    public void runQueryGroupsOfUserDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //查询用户所在的用户组列表
        GroupQuery groupQuery = identityService.createGroupQuery()
                .groupMember("hebo")
                .orderByGroupId()
                .asc();
        GroupUtil.executeList(groupQuery);
    }
}
