package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.activiti.engine.identity.UserQuery;
import org.junit.Test;

public class RunListUsersByMultiOrdersDemo extends ActivitiEngineUtil {

    @Test
    public void runListUsersByMultiOrdersDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        UserUtil.addUser(identityService, "tonyhebo", "贺", "博", "tonyhebo@163.com", "******");
        UserUtil.addUser(identityService, "liuxiaopeng", "刘", "晓鹏", "lxpcnic@163.com", "******");
        UserUtil.addUser(identityService, "huhaiqin", "胡", "海琴", "aiqinhai_hu@163.com", "******");
        //根据查询条件查询用户并输出用户信息
        UserQuery userQuery = identityService.createUserQuery()
                .orderByUserLastName()//.desc()
                .orderByUserId().asc();
        UserUtil.executeList(userQuery);
    }
}