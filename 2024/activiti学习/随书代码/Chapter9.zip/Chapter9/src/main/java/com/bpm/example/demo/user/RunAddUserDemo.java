package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import org.junit.Test;

public class RunAddUserDemo extends ActivitiEngineUtil {

    @Test
    public void runAddUserDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        UserUtil.addUser(identityService,"hebo", "贺", "波", "hebo824@163.com", "******");
    }
}