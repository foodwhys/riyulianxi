package com.bpm.example.demo.group;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.group.util.GroupUtil;
import org.junit.Test;

public class RunAddGroupDemo extends ActivitiEngineUtil {

    @Test
    public void runAddGroupDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        GroupUtil.addGroup(identityService,"process_platform_department", "流程平台部", "department");
    }
}