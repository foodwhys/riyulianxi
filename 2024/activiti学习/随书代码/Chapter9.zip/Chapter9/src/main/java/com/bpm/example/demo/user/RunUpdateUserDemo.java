package com.bpm.example.demo.user;

import com.bpm.common.util.ActivitiEngineUtil;
import com.bpm.example.demo.user.util.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.identity.User;
import org.junit.Test;

@Slf4j
public class RunUpdateUserDemo extends ActivitiEngineUtil {

    @Test
    public void runUpdateUserDemo() {
        //加载Activiti配置文件并初始化流程引擎及服务
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //新建用户
        UserUtil.addUser(identityService, "hebo", "贺", "波", "hebo824@163.com", "******");
        //查询用户信息
        User oldUser = UserUtil.executeSingleResult(identityService.createUserQuery().userId("hebo"));
        //打印原始用户信息
        log.info("修改前：id：{}，email：{}，password：{}", oldUser.getId(), oldUser.getEmail(), oldUser.getPassword());
        //修改用户邮箱和密码
        UserUtil.updateUser(identityService, "hebo", oldUser.getFirstName(), oldUser.getLastName(), "hebo@activiti.org", "######");
        //再次查询用户信息
        User newUser = UserUtil.executeSingleResult(identityService.createUserQuery().userId("hebo"));
        log.info("修改后：id：{}，email：{}，password：{}", newUser.getId(), newUser.getEmail(), newUser.getPassword());
    }
}