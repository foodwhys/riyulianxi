package com.bpm.example.demo6;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

import java.text.SimpleDateFormat;

public class RunDemo6 extends ActivitiEngineUtil {
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    public static void main(String[] args) {
        RunDemo6 demo = new RunDemo6();
        demo.runDemo();
    }

    private void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SimpleProcess2.bpmn20.xml");
        System.out.println("流程定义ID为：" + processDefinition.getId() + "，流程key为：" + processDefinition.getKey());
        //根据流程定义id发起流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        System.out.println("流程实例的ID为：" + processInstance.getId());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        System.out.println("第一个任务ID为：" + firstTask.getId() + "，任务名称为：" + firstTask.getName());
        taskService.setAssignee(firstTask.getId(), "huhaiqin");
        //完成第一个任务
        taskService.complete(firstTask.getId());
        System.out.println("第一个任务办理完成！");

        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceId(processInstance.getId()).onlyChildExecutions().singleResult();
        System.out.println("当前执行实例ID：" + execution.getId());
        runtimeService.trigger(execution.getId());
        System.out.println("触发机器节点，继续流转！");
        //查询流程执行历史
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstance.getId())
                .singleResult();
        System.out.println("流程实例开始时间：" + dateFormat.format(historicProcessInstance.getStartTime())
                + ",结束时间：" + dateFormat.format(historicProcessInstance.getEndTime()));
        //关闭流程引擎
        closeEngine();
    }
}
