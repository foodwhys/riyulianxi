package com.bpm.example.demo5;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;

public class RunDemo5 extends ActivitiEngineUtil {
    public static void main(String[] args) {
        RunDemo5 demo = new RunDemo5();
        demo.runDemo();
    }

    private void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SimpleProcess.bpmn20.xml");
        System.out.println("流程定义ID为：" + processDefinition.getId() + "，流程key为：" + processDefinition.getKey());
        //根据流程定义id发起流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        queryProcessInstance(processInstance.getId());
        //根据流程key发起流程
        ProcessInstance processInstance2 = runtimeService.createProcessInstanceBuilder()
                .processDefinitionKey(processDefinition.getKey())
                .name("SimpleProcessInstance")
                .start();
        queryProcessInstance(processInstance2.getId());
        //关闭流程引擎
        closeEngine();
    }

    private void queryProcessInstance(String processInstanceId) {
        ProcessInstance processInstance = runtimeService.createProcessInstanceQuery()
                .processInstanceId(processInstanceId)
                .singleResult();
        System.out.println("流程实例ID为：" + processInstance.getId()
                + "，流程定义id为：" + processInstance.getProcessDefinitionId()
                + "，流程实例名称为：" + processInstance.getName()
        );
    }
}
