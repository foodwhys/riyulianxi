package com.bpm.example.demo14;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RunDemo14bak {

    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    public static void main(String[] args) {
        //创建流程引擎配置
        ProcessEngineConfigurationImpl processEngineConfiguration
                = (ProcessEngineConfigurationImpl) ProcessEngineConfiguration
                .createProcessEngineConfigurationFromResource("activiti.cfg.xml");
        //创建流程引擎
        ProcessEngine engine = processEngineConfiguration.buildProcessEngine();
        //获取流程存储服务
        RepositoryService repositoryService = engine.getRepositoryService();
        //获取历史服务
        HistoryService historyService = engine.getHistoryService();
        //获取运行时服务
        RuntimeService runtimeService = engine.getRuntimeService();
        //获取流程任务服务
        TaskService taskService = engine.getTaskService();
        //部署流程
        Deployment deployment = repositoryService.createDeployment()
                .addClasspathResource("processes/SimpleProcess.bpmn20.xml")
                .deploy();
        //查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .deploymentId(deployment.getId()).singleResult();
        System.out.println("流程定义ID为：" + processDefinition.getId() + "，流程名称为：" + processDefinition.getName());
        //启动流程
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        System.out.println("流程实例ID为：" + processInstance.getId()
                + "，流程key为：" + processInstance.getProcessDefinitionKey());
        //查询第一个任务
        Task firstTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        System.out.println("第一个任务ID为：" + firstTask.getId() + "，任务名称为：" + firstTask.getName());
        taskService.setAssignee(firstTask.getId(), "huhaiqin");
        //完成第一个任务
        taskService.complete(firstTask.getId());
        System.out.println("第一个任务办理完成！");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //查询第二个任务
        Task secondTask = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        System.out.println("第二个任务ID为：" + secondTask.getId() + "，任务名称为：" + secondTask.getName());
        taskService.setAssignee(secondTask.getId(), "hebo");
        //设置审批意见
        Map<String, Object> variables = new HashMap<>();
        variables.put("task_审批_outcome", "agree");
        //完成第二个任务
        taskService.complete(secondTask.getId(), variables);
        System.out.println("第二个任务办理完成！");

        //查询流程执行历史
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstance.getId())
                .singleResult();
        System.out.println("流程实例开始时间：" + dateFormat.format(historicProcessInstance.getStartTime())
                + ",结束时间：" + dateFormat.format(historicProcessInstance.getEndTime()));
        //查询活动实例
        List<HistoricActivityInstance> historicActivityInstances = historyService.createHistoricActivityInstanceQuery()
                .processInstanceId(processInstance.getId())
                .orderByHistoricActivityInstanceStartTime().asc()
                .list();
        for (HistoricActivityInstance historicActivityInstance : historicActivityInstances) {
            System.out.println("活动实例[" + historicActivityInstance.getActivityName() +
                    "],开始时间：" + dateFormat.format(historicActivityInstance.getStartTime())
                    + ",结束时间：" + dateFormat.format(historicActivityInstance.getEndTime()));
        }
        //查询任务实例
        List<HistoricTaskInstance> historicTaskInstances = historyService.createHistoricTaskInstanceQuery()
                .processInstanceId(processInstance.getId())
                .orderByHistoricTaskInstanceStartTime().asc()
                .list();
        for (HistoricTaskInstance historicTaskInstance : historicTaskInstances) {
            System.out.println("任务实例[" + historicTaskInstance.getName() +
                    "]的办理人为：" + historicTaskInstance.getAssignee()
            );
        }
        //查询流程变量
        List<HistoricVariableInstance> historicVariableInstances = historyService.createHistoricVariableInstanceQuery()
                .processInstanceId(processInstance.getId())
                .list();
        for (HistoricVariableInstance historicVariableInstance : historicVariableInstances) {
            System.out.println("流程变量[" + historicVariableInstance.getVariableName() +
                    "]的值为：" + historicVariableInstance.getValue()
            );
        }
        //关闭流程引擎
        engine.close();
    }
}