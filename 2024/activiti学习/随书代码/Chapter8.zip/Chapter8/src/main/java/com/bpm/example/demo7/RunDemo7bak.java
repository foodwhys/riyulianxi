package com.bpm.example.demo7;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.impl.persistence.entity.TaskEntityImpl;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

import java.util.List;

public class RunDemo7bak extends ActivitiEngineUtil {
    public static void main(String[] args) {
        RunDemo7bak demo = new RunDemo7bak();
        demo.runDemo();
    }

    private void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SimpleProcess4.bpmn20.xml");
        System.out.println("流程定义ID为：" + processDefinition.getId() + "，流程key为：" + processDefinition.getKey());
        //发起流程实例
        ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinition.getId());
        System.out.println("发起流程实例成功！流程实例ID为：" + processInstance.getId()
                + "，流程定义id为：" + processInstance.getProcessDefinitionId());
        List<Task> task1 = queryTasks(taskService, processInstance.getId());
        //完成第一个节点任务
        for (Task task : task1) {
            taskService.complete(task.getId());
            System.out.println("完成1个任务，ID=" + task.getId());
        }
        List<Task> task2 = queryTasks(taskService, processInstance.getId());
        Task task2_0 = task2.get(0);
        //新建任务
        Task newTask = taskService.newTask();
        if (newTask instanceof TaskEntity) {
            TaskEntity newTaskEntity = (TaskEntityImpl) newTask;
            newTaskEntity.setName("新审批");
            newTaskEntity.setAssignee("liuxiaopeng");
            newTaskEntity.setProcessDefinitionId(processDefinition.getId());
            newTaskEntity.setProcessInstanceId(processInstance.getId());
            newTaskEntity.setExecutionId(task2_0.getExecutionId());
            newTaskEntity.setTaskDefinitionKey(task2_0.getTaskDefinitionKey());
        }
        taskService.saveTask(newTask);
        System.out.println("新建1个任务,ID=" + newTask.getId());
        List<Task> task3 = queryTasks(taskService, processInstance.getId());
        //删除任务
        if (task2_0 instanceof TaskEntity) {
            TaskEntity taskEntity = (TaskEntity) task2_0;
            taskEntity.setExecutionId(null);
            taskService.saveTask(taskEntity);
        }
        taskService.deleteTask(task2_0.getId());
        System.out.println("删除1个任务,ID=" + task2_0.getId());
        List<Task> task4 = queryTasks(taskService, processInstance.getId());
        //完成第2个节点的任务
        for (Task tsk : task4) {
            taskService.complete(tsk.getId());
            System.out.println("完成1个任务，ID=" + tsk.getId());
        }

        //查询任务实例
        List<Task> task5 = queryTasks(taskService, processInstance.getId());
        //关闭流程引擎
        closeEngine();
    }

    //查询历史任务实例
    private static List<Task> queryTasks(TaskService taskService, String processInstanceId) {
        System.out.println("=====查询流程实例当前任务");
        List<Task> taskList = taskService.createTaskQuery().processInstanceId(processInstanceId).list();
        if (taskList != null && taskList.size() > 0) {
            for (Task task : taskList) {
                System.out.println("任务[" + task.getName() + "](ID=" + task.getId() + ")"
                        + "的办理人为：" + task.getAssignee()
                );
            }
        } else {
            System.out.println("没有运行状态的任务");
        }
        return taskList;
    }
}
