package com.bpm.example.demo13;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;

import java.util.List;

public class RunDemo13 extends ActivitiEngineUtil {
    public static void main(String[] args) {
        RunDemo13 demo = new RunDemo13();
        demo.runDemo();
    }

    private void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //创建用户1
        User user1 = identityService.newUser("huhaiqin");
        user1.setFirstName("胡");
        user1.setLastName("海琴");
        user1.setEmail("huhaiqin@activiti.org");
        //保存用户1
        identityService.saveUser(user1);
        //创建用户2
        User user2 = identityService.newUser("liuxiaopeng");
        user2.setFirstName("刘");
        user2.setLastName("晓鹏");
        user2.setEmail("liuxiaopeng@activiti.org");
        //保存用户2
        identityService.saveUser(user2);
        //创建用户3
        User user3 = identityService.newUser("hebo");
        user3.setFirstName("贺");
        user3.setLastName("波");
        user3.setEmail("hebo@activiti.org");
        //保存用户3
        identityService.saveUser(user3);

        //创建组1
        Group group1 = identityService.newGroup("group1");
        group1.setName("Group1");
        //保存组1
        identityService.saveGroup(group1);
        //创建组2
        Group group2 = identityService.newGroup("group2");
        group2.setName("Group2");
        //保存组2
        identityService.saveGroup(group2);

        //创建用户与组的关系
        identityService.createMembership("huhaiqin", "group1");
        identityService.createMembership("liuxiaopeng", "group1");
        identityService.createMembership("hebo", "group2");

        //查询组和用户
        List<Group> groups = identityService.createGroupQuery().list();
        for (Group group : groups) {
            System.out.println("组名：" + group.getName() + "，组ID：" + group.getId());
            String groupId = group.getId();
            List<User> users = identityService.createUserQuery().memberOfGroup(groupId).list();
            for (User user : users) {
                System.out.println("--成员ID：" + user.getId()
                        + "，姓名：" + user.getFirstName() + user.getLastName()
                        + "，邮箱：" + user.getEmail());
            }
        }
        //关闭流程引擎
        closeEngine();
    }
}
