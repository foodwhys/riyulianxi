package com.bpm.example.demo3;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;

public class RunDemo3 extends ActivitiEngineUtil {
    public static void main(String[] args) {
        RunDemo3 demo = new RunDemo3();
        demo.runDemo();
    }

    private void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SimpleProcess.bpmn20.xml");
        //查询流程定义状态
        queryProcessDefinition(processDefinition.getId());
        //发起流程实例
        startProcessInstance(processDefinition.getId());
        //挂起流程定义
        repositoryService.suspendProcessDefinitionById(processDefinition.getId());
        System.out.println("挂起流程定义！流程定义ID=" + processDefinition.getId());
        //再次查询流程定义状态
        queryProcessDefinition(processDefinition.getId());
        //再次发起流程实例
        startProcessInstance(processDefinition.getId());
        //关闭流程引擎
        engine.close();
    }

    //查询流程定义状态
    private void queryProcessDefinition(String processDefinitionId) {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId)
                .singleResult();
        System.out.println("***流程定义ID=" + processDefinition.getId()
                + " , 流程Key=" + processDefinition.getKey()
                + " , 是否挂起=" + processDefinition.isSuspended());
    }

    //根据流程定义id发起流程
    private void startProcessInstance(String processDefinitionId) {
        try {
            ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinitionId);
            System.out.println("发起流程实例成功。流程实例ID为：" + processInstance.getId()
                    + "，流程定义id为：" + processInstance.getProcessDefinitionId()
                    + "，流程key为：" + processInstance.getProcessDefinitionKey());
        } catch (Exception e) {
            System.out.println("发起流程实例失败。" + e.getMessage());
        }
    }
}
