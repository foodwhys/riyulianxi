package com.bpm.example.demo1;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;

public class RunDemo1 {
    public static void main(String[] args) {
        //创建流程引擎配置
        ProcessEngineConfigurationImpl processEngineConfiguration
                = (ProcessEngineConfigurationImpl) ProcessEngineConfiguration
                .createProcessEngineConfigurationFromResource("activiti.cfg.xml");
        //创建流程引擎
        ProcessEngine engine = processEngineConfiguration.buildProcessEngine();
        //获取流程存储服务
        RepositoryService repositoryService = engine.getRepositoryService();
        //部署流程
        Deployment deployment = repositoryService.createDeployment()
                .addClasspathResource("processes/SimpleProcess.bpmn20.xml")
                .deploy();
        //查询流程定义
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .deploymentId(deployment.getId()).singleResult();
        System.out.println("流程定义ID为：" + processDefinition.getId() + "，流程名称为：" + processDefinition.getName()
                + "，版本号：" + processDefinition.getVersion());
        //再次部署流程
        Deployment deployment2 = repositoryService.createDeployment()
                .addClasspathResource("processes/SimpleProcess.bpmn20.xml")
                .deploy();
        //再次查询流程定义
        ProcessDefinition processDefinition2 = repositoryService.createProcessDefinitionQuery()
                .deploymentId(deployment2.getId()).singleResult();
        System.out.println("流程定义ID为：" + processDefinition2.getId() + "，流程名称为：" + processDefinition2.getName()
                + "，版本号：" + processDefinition2.getVersion());
        //关闭流程引擎
        engine.close();
    }
}
