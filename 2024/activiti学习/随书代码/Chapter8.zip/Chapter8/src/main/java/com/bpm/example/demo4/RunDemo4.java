package com.bpm.example.demo4;

import com.bpm.common.util.ActivitiEngineUtil;
import org.activiti.engine.repository.ProcessDefinition;

public class RunDemo4 extends ActivitiEngineUtil {
    public static void main(String[] args) {
        RunDemo4 demo = new RunDemo4();
        demo.runDemo();
    }

    public void runDemo() {
        //初始化流程引擎
        loadActivitiConfigAndInitEngine("activiti.cfg.xml");
        //部署流程
        ProcessDefinition processDefinition = deployByClasspathResource("processes/SimpleProcess.bpmn20.xml");
        //查询流程定义状态
        queryProcessDefinition(processDefinition.getId());
        //挂起流程定义
        repositoryService.suspendProcessDefinitionById(processDefinition.getId());
        System.out.println("挂起流程定义！流程定义ID=" + processDefinition.getId());
        //再次查询流程定义状态
        queryProcessDefinition(processDefinition.getId());
        //激活流程定义
        repositoryService.activateProcessDefinitionById(processDefinition.getId());
        System.out.println("激活流程定义！流程定义ID=" + processDefinition.getId());
        //再次查询流程定义状态
        queryProcessDefinition(processDefinition.getId());
        //关闭流程引擎
        closeEngine();
    }

    private void queryProcessDefinition(String processDefinitionId) {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId)
                .singleResult();
        System.out.println("***流程定义ID=" + processDefinition.getId()
                + " , 流程Key=" + processDefinition.getKey()
                + " , 是否挂起=" + processDefinition.isSuspended());
    }
}
