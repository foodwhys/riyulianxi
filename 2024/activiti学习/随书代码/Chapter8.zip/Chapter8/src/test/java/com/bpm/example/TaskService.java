package com.bpm.example;

import org.activiti.engine.impl.persistence.entity.VariableInstance;
import org.activiti.engine.query.NativeQuery;
import org.activiti.engine.runtime.DataObject;
import org.activiti.engine.task.Attachment;
import org.activiti.engine.task.Comment;
import org.activiti.engine.task.DelegationState;
import org.activiti.engine.task.Event;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.NativeTaskQuery;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;

import java.io.InputStream;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;


public interface TaskService {
    //任务新建、保存、删除
    Task newTask();
    Task newTask(String taskId);
    void saveTask(Task task);
    void deleteTask(String taskId);
    void deleteTasks(Collection<String> taskIds);
    void deleteTask(String taskId, boolean cascade);
    void deleteTasks(Collection<String> taskIds, boolean cascade);
    void deleteTask(String taskId, String deleteReason);
    void deleteTasks(Collection<String> taskIds, String deleteReason);

    //任务办理相关
    void claim(String taskId, String userId);
    void unclaim(String taskId);
    void delegateTask(String taskId, String userId);
    void resolveTask(String taskId);
    void resolveTask(String taskId, Map<String, Object> variables);
    void resolveTask(String taskId, Map<String, Object> variables, Map<String, Object> transientVariables);
    void complete(String taskId);
    void complete(String taskId, Map<String, Object> variables);
    void complete(String taskId, Map<String, Object> variables, Map<String, Object> transientVariables);
    void complete(String taskId, Map<String, Object> variables, boolean localScope);

    //人员与任务关系，如办理人、候选人、候选组等
    void setAssignee(String taskId, String userId);
    void setOwner(String taskId, String userId);
    void addCandidateUser(String taskId, String userId);
    void addCandidateGroup(String taskId, String groupId);
    void addUserIdentityLink(String taskId, String userId, String identityLinkType);
    void addGroupIdentityLink(String taskId, String groupId, String identityLinkType);
    void deleteCandidateUser(String taskId, String userId);
    void deleteCandidateGroup(String taskId, String groupId);
    void deleteUserIdentityLink(String taskId, String userId, String identityLinkType);
    void deleteGroupIdentityLink(String taskId, String groupId, String identityLinkType);
    List<IdentityLink> getIdentityLinksForTask(String taskId);

    //任务优先级、到期时间
    void setPriority(String taskId, int priority);
    void setDueDate(String taskId, Date dueDate);

    //任务查询相关
    TaskQuery createTaskQuery();
    NativeTaskQuery createNativeTaskQuery();

    //任务变量相关
    void setVariable(String taskId, String variableName, Object value);
    void setVariables(String taskId, Map<String, ? extends Object> variables);
    void setVariableLocal(String taskId, String variableName, Object value);
    void setVariablesLocal(String taskId, Map<String, ? extends Object> variables);
    Object getVariable(String taskId, String variableName);
    <T> T getVariable(String taskId, String variableName, Class<T> variableClass);
    VariableInstance getVariableInstance(String taskId, String variableName);
    boolean hasVariable(String taskId, String variableName);
    Object getVariableLocal(String taskId, String variableName);
    <T> T getVariableLocal(String taskId, String variableName, Class<T> variableClass);
    VariableInstance getVariableInstanceLocal(String taskId, String variableName);
    boolean hasVariableLocal(String taskId, String variableName);
    Map<String, Object> getVariables(String taskId);
    Map<String, VariableInstance> getVariableInstances(String taskId);
    Map<String, VariableInstance> getVariableInstances(String taskId, Collection<String> variableNames);
    Map<String, Object> getVariablesLocal(String taskId);
    Map<String, Object> getVariables(String taskId, Collection<String> variableNames);
    Map<String, Object> getVariablesLocal(String taskId, Collection<String> variableNames);
    List<VariableInstance> getVariableInstancesLocalByTaskIds(Set<String> taskIds);
    Map<String, VariableInstance> getVariableInstancesLocal(String taskId);
    Map<String, VariableInstance> getVariableInstancesLocal(String taskId, Collection<String> variableNames);
    void removeVariable(String taskId, String variableName);
    void removeVariableLocal(String taskId, String variableName);
    void removeVariables(String taskId, Collection<String> variableNames);
    void removeVariablesLocal(String taskId, Collection<String> variableNames);

    //DataObject相关
    Map<String, DataObject> getDataObjects(String taskId);
    Map<String, DataObject> getDataObjects(String taskId, String locale, boolean withLocalizationFallback);
    Map<String, DataObject> getDataObjects(String taskId, Collection<String> dataObjectNames);
    Map<String, DataObject> getDataObjects(String taskId, Collection<String> dataObjectNames, String locale, boolean withLocalizationFallback);
    DataObject getDataObject(String taskId, String dataObject);
    DataObject getDataObject(String taskId, String dataObjectName, String locale, boolean withLocalizationFallback);

    //任务评论相关
    Comment addComment(String taskId, String processInstanceId, String message);
    Comment addComment(String taskId, String processInstanceId, String type, String message);
    Comment getComment(String commentId);
    void deleteComments(String taskId, String processInstanceId);
    void deleteComment(String commentId);
    List<Comment> getTaskComments(String taskId);
    List<Comment> getTaskComments(String taskId, String type);
    List<Comment> getCommentsByType(String type);
    List<Comment> getProcessInstanceComments(String processInstanceId);
    List<Comment> getProcessInstanceComments(String processInstanceId, String type);

    //任务事件相关
    List<Event> getTaskEvents(String taskId);
    Event getEvent(String eventId);

    //附件相关
    Attachment createAttachment(String attachmentType, String taskId, String processInstanceId, String attachmentName, String attachmentDescription, InputStream content);
    Attachment createAttachment(String attachmentType, String taskId, String processInstanceId, String attachmentName, String attachmentDescription, String url);
    void saveAttachment(Attachment attachment);
    Attachment getAttachment(String attachmentId);
    InputStream getAttachmentContent(String attachmentId);
    List<Attachment> getTaskAttachments(String taskId);
    List<Attachment> getProcessInstanceAttachments(String processInstanceId);
    void deleteAttachment(String attachmentId);

    //子任务
    List<Task> getSubTasks(String parentTaskId);
}
