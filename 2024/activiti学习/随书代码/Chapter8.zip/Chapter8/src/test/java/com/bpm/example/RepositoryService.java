package com.bpm.example;

import org.activiti.bpmn.model.BpmnModel;
import org.activiti.engine.repository.DeploymentBuilder;
import org.activiti.engine.repository.DeploymentQuery;
import org.activiti.engine.repository.DiagramLayout;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ModelQuery;
import org.activiti.engine.repository.NativeDeploymentQuery;
import org.activiti.engine.repository.NativeModelQuery;
import org.activiti.engine.repository.NativeProcessDefinitionQuery;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.repository.ProcessDefinitionQuery;
import org.activiti.engine.task.IdentityLink;
import org.activiti.validation.ValidationError;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

public interface RepositoryService {
    /*****流程部署管理*****/
    DeploymentBuilder createDeployment();
    void deleteDeployment(String deploymentId);
    void deleteDeployment(String deploymentId, boolean cascade);
    void setDeploymentCategory(String deploymentId, String category);
    void setDeploymentKey(String deploymentId, String key);
    List<String> getDeploymentResourceNames(String deploymentId);
    InputStream getResourceAsStream(String deploymentId, String resourceName);
    void changeDeploymentTenantId(String deploymentId, String newTenantId);
    DeploymentQuery createDeploymentQuery();
    NativeDeploymentQuery createNativeDeploymentQuery();

    /*****流程定义管理*****/
    ProcessDefinitionQuery createProcessDefinitionQuery();
    NativeProcessDefinitionQuery createNativeProcessDefinitionQuery();
    //挂起流程定义
    void suspendProcessDefinitionById(String processDefinitionId);
    void suspendProcessDefinitionById(String processDefinitionId, boolean suspendProcessInstances, Date suspensionDate);
    void suspendProcessDefinitionByKey(String processDefinitionKey);
    void suspendProcessDefinitionByKey(String processDefinitionKey, boolean suspendProcessInstances, Date suspensionDate);
    void suspendProcessDefinitionByKey(String processDefinitionKey, String tenantId);
    void suspendProcessDefinitionByKey(String processDefinitionKey, boolean suspendProcessInstances, Date suspensionDate, String tenantId);
    //激活流程定义
    void activateProcessDefinitionById(String processDefinitionId);
    void activateProcessDefinitionById(String processDefinitionId, boolean activateProcessInstances, Date activationDate);
    void activateProcessDefinitionByKey(String processDefinitionKey);
    void activateProcessDefinitionByKey(String processDefinitionKey, boolean activateProcessInstances, Date activationDate);
    void activateProcessDefinitionByKey(String processDefinitionKey, String tenantId);
    void activateProcessDefinitionByKey(String processDefinitionKey, boolean activateProcessInstances, Date activationDate, String tenantId);
    //设置流程定义分类
    void setProcessDefinitionCategory(String processDefinitionId, String category);
    //获取流程定义xml
    InputStream getProcessModel(String processDefinitionId);
    //获取流程定义图片
    InputStream getProcessDiagram(String processDefinitionId);
    //获取流程定义
    ProcessDefinition getProcessDefinition(String processDefinitionId);
    //是否Activiti5版本
    Boolean isActiviti5ProcessDefinition(String processDefinitionId);
    //是否挂起
    boolean isProcessDefinitionSuspended(String processDefinitionId);
    //获取BpmnModel
    BpmnModel getBpmnModel(String processDefinitionId);
    //获取流程定义布局
    DiagramLayout getProcessDiagramLayout(String processDefinitionId);

    /*****流程模型管理*****/
    public Model newModel();
    public void saveModel(Model model);
    public void deleteModel(String modelId);
    public void addModelEditorSource(String modelId, byte[] bytes);
    public void addModelEditorSourceExtra(String modelId, byte[] bytes);
    public ModelQuery createModelQuery();
    NativeModelQuery createNativeModelQuery();
    public Model getModel(String modelId);
    public byte[] getModelEditorSource(String modelId);
    public byte[] getModelEditorSourceExtra(String modelId);

    /*****流程定义与人员关系管理*****/
    void addCandidateStarterUser(String processDefinitionId, String userId);
    void addCandidateStarterGroup(String processDefinitionId, String groupId);
    void deleteCandidateStarterUser(String processDefinitionId, String userId);
    void deleteCandidateStarterGroup(String processDefinitionId, String groupId);
    List<IdentityLink> getIdentityLinksForProcessDefinition(String processDefinitionId);

    //校验流程
    List<ValidationError> validateProcess(BpmnModel bpmnModel);
}